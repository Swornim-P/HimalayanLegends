﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





extern void GridLayout_DoNothing_mA280987BF98D257023D46C2C01902FC82EE6A00A (void);
static Il2CppMethodPointer s_methodPointers[1] = 
{
	GridLayout_DoNothing_mA280987BF98D257023D46C2C01902FC82EE6A00A,
};
static const int32_t s_InvokerIndices[1] = 
{
	5391,
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_UnityEngine_GridModule_CodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_GridModule_CodeGenModule = 
{
	"UnityEngine.GridModule.dll",
	1,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
};
