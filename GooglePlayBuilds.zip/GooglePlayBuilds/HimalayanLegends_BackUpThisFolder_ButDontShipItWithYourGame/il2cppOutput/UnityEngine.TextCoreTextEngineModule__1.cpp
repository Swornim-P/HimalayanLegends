﻿#include "pch-cpp.hpp"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <limits>



struct Dictionary_2_tC20B3D6AE4370C892734F670EF4D1FB9CE91F371;
struct Dictionary_2_tABE19B9C5C52F1DE14F0D3287B2696E7D7419180;
struct Dictionary_2_tA9740D661997C74C20CD0D9D1ADDC534F2DB0A1F;
struct Dictionary_2_t93CDF0F4011A5A3024EB73A492F9512E3046EACB;
struct Dictionary_2_tC61348D10610A6B3D7B65102D82AC3467D59EAA7;
struct Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0;
struct Dictionary_2_t1A4804CA9724B6CE01D6ECABE81CE0848CBA80B4;
struct Dictionary_2_tC58BED428F0C45B2320DCA085F781540D1CC3A26;
struct Dictionary_2_t3B281EAA0FCAF1D0DED857932C74644D3F02E6D0;
struct Dictionary_2_tC8FA8E0C06C3A9584490723EC95DC65E5AFFF71A;
struct Dictionary_2_tD4154357CA320908C5A7A35ED81FA2A9856C28D9;
struct Dictionary_2_tDC0461D8CBB2E6B52DD2C421114EDE7C1C70DE73;
struct HashSet_1_t4A2F2B74276D0AD3ED0F873045BD61E9504ECAE2;
struct HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A;
struct IEqualityComparer_1_t0BB8211419723EB61BF19007AC9D62365E50500E;
struct KeyCollection_tC77517EE58666366824AEC6674ED44B430ED2D67;
struct KeyCollection_tF62DA58D084558E31E5A09537D460287D59B1A89;
struct KeyCollection_tAD453AF815DCCCF044626BE66BABEEA3916E9440;
struct KeyCollection_t3ABB637C6EFD1A1CF0CAA35D9D2067269088043D;
struct List_1_tFED0F30EE65D995591571D3CD2C10F22439CB317;
struct List_1_t55B85B981AC5FD6A5358491F90FE354F78BB97DE;
struct List_1_t95DB74B8EE315F8F92B7B96D93C901C8C3F6FE2C;
struct List_1_t3CA8EA3609B406A4099002CBD02BB599F3B1D5DB;
struct List_1_t425D3A455811E316D2DF73E46CF9CD90A4341C1B;
struct List_1_t420B17163897A4DF994BA698744548CD81961E70;
struct List_1_t8837CD02A40CED632406E449B6D76FF9AB3E4468;
struct List_1_tF7A39AE542CF9A5C63B48726F173FA38571D52C3;
struct List_1_tD497C1314C02F6E7345D74565C2424A939B46AA7;
struct List_1_t3EE59C28A34FCD5060EF6B6BAFA85F2C9D01D320;
struct List_1_t7DA088250C54C07AF1211AE132355AD2D343EE51;
struct List_1_t063B87D3CFDC3AEE80E33EFBDA1410C697D71AD6;
struct List_1_t0F231C3F13EBA1FF9081BD61489D01AA3CBE59D4;
struct List_1_t9B68833848E4C4D7F623C05F6B77F0449396354A;
struct List_1_tA1547550E5FBA50050B20DA74245C38434654EE8;
struct ValueCollection_tA5B63968FCBE6FB42208B53C99AD12395688A1E8;
struct ValueCollection_tB99ECE94AB57EE9AB1FAC3276CC7108B468367C9;
struct ValueCollection_tA12155C30BE5F793F28A11A75C457F57030DE798;
struct ValueCollection_tDF43C5BC65DBEA56CA159EA97CD240756ABECB32;
struct EntryU5BU5D_t0847BDFA02D0C07032D1677F21C95174F778FC60;
struct EntryU5BU5D_t68A3C3C2FF61504922EC13C363BED0E17D474FA8;
struct EntryU5BU5D_t18E2846B028F7F1F3FB655F30FA14F00DA8F16AD;
struct EntryU5BU5D_tFDD3ED397689A7E87D3CD5A24AB952D32BADDDD4;
struct SlotU5BU5D_tBF418274114DA8D3D070D784415BF0500C1960C6;
struct TextProcessingStack_1U5BU5D_t2552082EA18234192F7BABAE183356A81363BB6F;
struct ByteU5BU5D_tA6237BF417AE52AD70CFB4EF24A7A82613DF9031;
struct CharU5BU5D_t799905CF001DD5F13F7DBB310181FC4D8B7D0AAB;
struct Color32U5BU5D_t38116C3E91765C4C5726CE12C77FAD7F9F737259;
struct FontWeightPairU5BU5D_t76E8DB55C81EEBEFA2E6D1D3E3B3EA1FB4C4954F;
struct HighlightStateU5BU5D_tCF5677B4773947CE4C64B938B12AC50DDA347435;
struct Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C;
struct Int32EnumU5BU5D_t87B7DB802810C38016332669039EF42C487A081F;
struct LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D;
struct LinkInfoU5BU5D_tB7EB23E47AF29CCBEC884F9D0DB95BC97F62AE51;
struct MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E;
struct MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6;
struct ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918;
struct PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4;
struct RichTextTagAttributeU5BU5D_tEE9D071B3246F23742DBF4226567620BCBB24A14;
struct SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C;
struct TextAlignmentU5BU5D_t756DC2D672145699CB9718DDBA5982ED51A95F49;
struct TextColorGradientU5BU5D_tA27A5E49640CF01334A10DBDBC959903AFBD941A;
struct TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E;
struct TextFontWeightU5BU5D_t3DE32809AEE657255C8333897D61F2EA5279D43F;
struct TextProcessingElementU5BU5D_t24A1E4C8745577D794FE856B4236875595E7FD22;
struct Texture2DU5BU5D_t05332F1E3F7D4493E304C702201F9BE4F9236191;
struct UInt32U5BU5D_t02FBD658AD156A17574ECE6106CF1FBFCC9807FA;
struct Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA;
struct Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C;
struct Vector4U5BU5D_tC0F3A7115F85007510F6D173968200CD31BCF7AD;
struct WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B;
struct WordWrapStateU5BU5D_t4AA4AAC14B38359416C63A57A1ADDD9C2004EAC8;
struct Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC;
struct Font_tC95270EA3198038970422D78B74A7F2E218A96B6;
struct FontAsset_t61A6446D934E582651044E33D250EA8D306AB958;
struct FontFeatureTable_t992E0493CD7E9D7834DF204E0198237F0D25B3B7;
struct Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F;
struct Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3;
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C;
struct SerializationInfo_t3C47F63E24BEB9FCE2DC6309E027F238DC5C5E37;
struct Shader_tADC867D36B7876EE22427FAA2CE485105F4EE692;
struct SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313;
struct SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5;
struct String_t;
struct TextAsset_t2C64E93DA366D9DE5A8209E1802FA4884AC1BD69;
struct TextAsset_tB28F1843A877CCA74B89DC4F63EA532618B049B8;
struct TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70;
struct TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA;
struct TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2;
struct TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366;
struct TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09;
struct TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64;
struct TextStyleSheet_t86A0FA5523897465F371A2ABC17DFA3558C8D15E;
struct Texture_t791CBB51219779964E0E8A2ED7C1AA5F92A4A700;
struct Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4;
struct UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E;
struct Void_t4861ACF8F4594C3437BB48B6E56783494B843915;
struct MissingCharacterEventCallback_t26E0AD04BD27B7E35AD648D0B549D13330921DED;

IL2CPP_EXTERN_C RuntimeClass* Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Debug_t8394C7EEAECA3689C2C9B9DE9C7166D73596276F_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C String_t* _stringLiteral41BB69D2BDF9A4541A716BE07E74D1ED0DEADD05;
IL2CPP_EXTERN_C String_t* _stringLiteral4D24EAAEA041EAFA17400A5C3BEA644DA7F8067F;
IL2CPP_EXTERN_C String_t* _stringLiteral6EFD426731423F3C40A7DA0D6CAECBFB816A8F61;
IL2CPP_EXTERN_C String_t* _stringLiteral94B946B03625197025E6D70053ADE0256BC25DD1;
IL2CPP_EXTERN_C String_t* _stringLiteralAFB91D1DF3A99213A5F62F37EB0B31E6121411C4;
IL2CPP_EXTERN_C String_t* _stringLiteralFE37C361B118D899F298E7DBBEDF126B8808060D;
IL2CPP_EXTERN_C const RuntimeMethod* Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Dictionary_2_TryGetValue_mE41304D9F16D4065AEA94463AE53A68A4F4F6395_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Dictionary_2_TryGetValue_mF32BD44799A9D5626676B55AEE98449663C70D33_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Dictionary_2_get_Item_mFA05B9BB2D2D3E43B23F6C859A051759E7C1C75D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextInfo_Resize_TisPageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909_m356AAB6CAA9298FF4C0E067A3ACE9A0AD2D78DE8_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_Clear_m3684329CF566CB94C981B1EAB3F1F3C74D42D0CD_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_Clear_m78D739A4A3B093B4CA2AD9D95578D2B4BB9909C3_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_Clear_m857C80F9AFD9507FE4784DB5DE79109E16C8EAA3_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_Pop_mBDDB87E018CFAAA932187B334ABB0237AB9D73B8_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_Push_mD1A26596D8C31C64D82246093BF86E91410DD8BC_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_SetDefault_m11524F3861DE3F60DE2BAB47DF333011E27E5C2C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_SetDefault_m2C394C84507BCA030509AC6708DCBC3F26E112B7_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_SetDefault_m2DBB41C08A4CB7F71156ED5965850C2A0570F230_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_SetDefault_mDAFD4911B5A8BEE57351A37415ADF348F0A6B54C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_SetDefault_mDD0BF36ABFBF0DBA2D289C08F9862374CE18A0F9_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_SetDefault_mDF71503A7E4F1891305CDCC7AE245CA66A713E79_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_get_Count_m019E4780B26C3C62C2C3E1BA49A5B47266DC65AC_RuntimeMethod_var;
struct Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B;
struct Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F_marshaled_com;
struct Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7;
struct Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2;
struct Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3;

struct LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D;
struct MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E;
struct MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6;
struct PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4;
struct TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E;
struct TextProcessingElementU5BU5D_t24A1E4C8745577D794FE856B4236875595E7FD22;
struct Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C;
struct WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B;

IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
struct Dictionary_2_t93CDF0F4011A5A3024EB73A492F9512E3046EACB  : public RuntimeObject
{
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ____buckets;
	EntryU5BU5D_t0847BDFA02D0C07032D1677F21C95174F778FC60* ____entries;
	int32_t ____count;
	int32_t ____freeList;
	int32_t ____freeCount;
	int32_t ____version;
	RuntimeObject* ____comparer;
	KeyCollection_tC77517EE58666366824AEC6674ED44B430ED2D67* ____keys;
	ValueCollection_tA5B63968FCBE6FB42208B53C99AD12395688A1E8* ____values;
	RuntimeObject* ____syncRoot;
};
struct Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0  : public RuntimeObject
{
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ____buckets;
	EntryU5BU5D_t68A3C3C2FF61504922EC13C363BED0E17D474FA8* ____entries;
	int32_t ____count;
	int32_t ____freeList;
	int32_t ____freeCount;
	int32_t ____version;
	RuntimeObject* ____comparer;
	KeyCollection_tF62DA58D084558E31E5A09537D460287D59B1A89* ____keys;
	ValueCollection_tB99ECE94AB57EE9AB1FAC3276CC7108B468367C9* ____values;
	RuntimeObject* ____syncRoot;
};
struct Dictionary_2_tC58BED428F0C45B2320DCA085F781540D1CC3A26  : public RuntimeObject
{
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ____buckets;
	EntryU5BU5D_t18E2846B028F7F1F3FB655F30FA14F00DA8F16AD* ____entries;
	int32_t ____count;
	int32_t ____freeList;
	int32_t ____freeCount;
	int32_t ____version;
	RuntimeObject* ____comparer;
	KeyCollection_tAD453AF815DCCCF044626BE66BABEEA3916E9440* ____keys;
	ValueCollection_tA12155C30BE5F793F28A11A75C457F57030DE798* ____values;
	RuntimeObject* ____syncRoot;
};
struct Dictionary_2_t3B281EAA0FCAF1D0DED857932C74644D3F02E6D0  : public RuntimeObject
{
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ____buckets;
	EntryU5BU5D_tFDD3ED397689A7E87D3CD5A24AB952D32BADDDD4* ____entries;
	int32_t ____count;
	int32_t ____freeList;
	int32_t ____freeCount;
	int32_t ____version;
	RuntimeObject* ____comparer;
	KeyCollection_t3ABB637C6EFD1A1CF0CAA35D9D2067269088043D* ____keys;
	ValueCollection_tDF43C5BC65DBEA56CA159EA97CD240756ABECB32* ____values;
	RuntimeObject* ____syncRoot;
};
struct HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A  : public RuntimeObject
{
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ____buckets;
	SlotU5BU5D_tBF418274114DA8D3D070D784415BF0500C1960C6* ____slots;
	int32_t ____count;
	int32_t ____lastIndex;
	int32_t ____freeList;
	RuntimeObject* ____comparer;
	int32_t ____version;
	SerializationInfo_t3C47F63E24BEB9FCE2DC6309E027F238DC5C5E37* ____siInfo;
};
struct FontFeatureTable_t992E0493CD7E9D7834DF204E0198237F0D25B3B7  : public RuntimeObject
{
	List_1_tD497C1314C02F6E7345D74565C2424A939B46AA7* ___m_MultipleSubstitutionRecords;
	List_1_t420B17163897A4DF994BA698744548CD81961E70* ___m_LigatureSubstitutionRecords;
	List_1_t3CA8EA3609B406A4099002CBD02BB599F3B1D5DB* ___m_GlyphPairAdjustmentRecords;
	List_1_t8837CD02A40CED632406E449B6D76FF9AB3E4468* ___m_MarkToBaseAdjustmentRecords;
	List_1_tF7A39AE542CF9A5C63B48726F173FA38571D52C3* ___m_MarkToMarkAdjustmentRecords;
	Dictionary_2_tA9740D661997C74C20CD0D9D1ADDC534F2DB0A1F* ___m_LigatureSubstitutionRecordLookup;
	Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0* ___m_GlyphPairAdjustmentRecordLookup;
	Dictionary_2_tC58BED428F0C45B2320DCA085F781540D1CC3A26* ___m_MarkToBaseAdjustmentRecordLookup;
	Dictionary_2_t3B281EAA0FCAF1D0DED857932C74644D3F02E6D0* ___m_MarkToMarkAdjustmentRecordLookup;
};
struct String_t  : public RuntimeObject
{
	int32_t ____stringLength;
	Il2CppChar ____firstChar;
};
struct TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53  : public RuntimeObject
{
};
struct TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09  : public RuntimeObject
{
	int32_t ___characterCount;
	int32_t ___spriteCount;
	int32_t ___spaceCount;
	int32_t ___wordCount;
	int32_t ___linkCount;
	int32_t ___lineCount;
	int32_t ___pageCount;
	int32_t ___materialCount;
	TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* ___textElementInfo;
	WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* ___wordInfo;
	LinkInfoU5BU5D_tB7EB23E47AF29CCBEC884F9D0DB95BC97F62AE51* ___linkInfo;
	LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* ___lineInfo;
	PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* ___pageInfo;
	MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6* ___meshInfo;
	bool ___isDirty;
	bool ___hasMultipleColors;
};
struct TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692  : public RuntimeObject
{
};
struct UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E  : public RuntimeObject
{
	TextAsset_t2C64E93DA366D9DE5A8209E1802FA4884AC1BD69* ___m_UnicodeLineBreakingRules;
	TextAsset_t2C64E93DA366D9DE5A8209E1802FA4884AC1BD69* ___m_LeadingCharacters;
	TextAsset_t2C64E93DA366D9DE5A8209E1802FA4884AC1BD69* ___m_FollowingCharacters;
	bool ___m_UseModernHangulLineBreakingRules;
	HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* ___m_LeadingCharactersLookup;
	HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* ___m_FollowingCharactersLookup;
};
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F  : public RuntimeObject
{
};
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F_marshaled_pinvoke
{
};
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F_marshaled_com
{
};
struct TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 
{
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ___itemStack;
	int32_t ___index;
	int32_t ___m_DefaultItem;
	int32_t ___m_Capacity;
	int32_t ___m_RolloverSize;
	int32_t ___m_Count;
};
struct TextProcessingStack_1_t5EA97AAC21CEE068194F77E59929440F85AD3991 
{
	ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* ___itemStack;
	int32_t ___index;
	RuntimeObject* ___m_DefaultItem;
	int32_t ___m_Capacity;
	int32_t ___m_RolloverSize;
	int32_t ___m_Count;
};
struct TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 
{
	SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* ___itemStack;
	int32_t ___index;
	float ___m_DefaultItem;
	int32_t ___m_Capacity;
	int32_t ___m_RolloverSize;
	int32_t ___m_Count;
};
struct TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E 
{
	TextColorGradientU5BU5D_tA27A5E49640CF01334A10DBDBC959903AFBD941A* ___itemStack;
	int32_t ___index;
	TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70* ___m_DefaultItem;
	int32_t ___m_Capacity;
	int32_t ___m_RolloverSize;
	int32_t ___m_Count;
};
struct Boolean_t09A6377A54BE2F9E6985A8149F19234FD7DDFE22 
{
	bool ___m_value;
};
struct Byte_t94D9231AC217BE4D2E004C4CD32DF6D099EA41A3 
{
	uint8_t ___m_value;
};
struct Char_t521A6F19B456D956AF452D926C32709DC03D6B17 
{
	Il2CppChar ___m_value;
};
struct CharacterSubstitution_t9F6215FBA3E8AD8DDF6F35A51CEC7CB7E9A44F83 
{
	int32_t ___index;
	uint32_t ___unicode;
};
struct Color_tD001788D726C3A7F1379BEED0260B9591F440C1F 
{
	float ___r;
	float ___g;
	float ___b;
	float ___a;
};
struct Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B 
{
	union
	{
		#pragma pack(push, tp, 1)
		struct
		{
			int32_t ___rgba;
		};
		#pragma pack(pop, tp)
		struct
		{
			int32_t ___rgba_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			uint8_t ___r;
		};
		#pragma pack(pop, tp)
		struct
		{
			uint8_t ___r_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___g_OffsetPadding[1];
			uint8_t ___g;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___g_OffsetPadding_forAlignmentOnly[1];
			uint8_t ___g_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___b_OffsetPadding[2];
			uint8_t ___b;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___b_OffsetPadding_forAlignmentOnly[2];
			uint8_t ___b_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___a_OffsetPadding[3];
			uint8_t ___a;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___a_OffsetPadding_forAlignmentOnly[3];
			uint8_t ___a_forAlignmentOnly;
		};
	};
};
struct Enum_t2A1A94B24E3B776EEF4E5E485E290BB9D4D072E2  : public ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F
{
};
struct Enum_t2A1A94B24E3B776EEF4E5E485E290BB9D4D072E2_marshaled_pinvoke
{
};
struct Enum_t2A1A94B24E3B776EEF4E5E485E290BB9D4D072E2_marshaled_com
{
};
struct FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 
{
	int32_t ___m_FaceIndex;
	String_t* ___m_FamilyName;
	String_t* ___m_StyleName;
	int32_t ___m_PointSize;
	float ___m_Scale;
	int32_t ___m_UnitsPerEM;
	float ___m_LineHeight;
	float ___m_AscentLine;
	float ___m_CapLine;
	float ___m_MeanLine;
	float ___m_Baseline;
	float ___m_DescentLine;
	float ___m_SuperscriptOffset;
	float ___m_SuperscriptSize;
	float ___m_SubscriptOffset;
	float ___m_SubscriptSize;
	float ___m_UnderlineOffset;
	float ___m_UnderlineThickness;
	float ___m_StrikethroughOffset;
	float ___m_StrikethroughThickness;
	float ___m_TabWidth;
};
struct FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756_marshaled_pinvoke
{
	int32_t ___m_FaceIndex;
	char* ___m_FamilyName;
	char* ___m_StyleName;
	int32_t ___m_PointSize;
	float ___m_Scale;
	int32_t ___m_UnitsPerEM;
	float ___m_LineHeight;
	float ___m_AscentLine;
	float ___m_CapLine;
	float ___m_MeanLine;
	float ___m_Baseline;
	float ___m_DescentLine;
	float ___m_SuperscriptOffset;
	float ___m_SuperscriptSize;
	float ___m_SubscriptOffset;
	float ___m_SubscriptSize;
	float ___m_UnderlineOffset;
	float ___m_UnderlineThickness;
	float ___m_StrikethroughOffset;
	float ___m_StrikethroughThickness;
	float ___m_TabWidth;
};
struct FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756_marshaled_com
{
	int32_t ___m_FaceIndex;
	Il2CppChar* ___m_FamilyName;
	Il2CppChar* ___m_StyleName;
	int32_t ___m_PointSize;
	float ___m_Scale;
	int32_t ___m_UnitsPerEM;
	float ___m_LineHeight;
	float ___m_AscentLine;
	float ___m_CapLine;
	float ___m_MeanLine;
	float ___m_Baseline;
	float ___m_DescentLine;
	float ___m_SuperscriptOffset;
	float ___m_SuperscriptSize;
	float ___m_SubscriptOffset;
	float ___m_SubscriptSize;
	float ___m_UnderlineOffset;
	float ___m_UnderlineThickness;
	float ___m_StrikethroughOffset;
	float ___m_StrikethroughThickness;
	float ___m_TabWidth;
};
struct FontAssetCreationEditorSettings_t0FF28D2E78F090105C63C81F9E438A7B09E3EA52 
{
	String_t* ___sourceFontFileGUID;
	int32_t ___faceIndex;
	int32_t ___pointSizeSamplingMode;
	int32_t ___pointSize;
	int32_t ___padding;
	int32_t ___paddingMode;
	int32_t ___packingMode;
	int32_t ___atlasWidth;
	int32_t ___atlasHeight;
	int32_t ___characterSetSelectionMode;
	String_t* ___characterSequence;
	String_t* ___referencedFontAssetGUID;
	String_t* ___referencedTextAssetGUID;
	int32_t ___fontStyle;
	float ___fontStyleModifier;
	int32_t ___renderMode;
	bool ___includeFontFeatures;
};
struct FontAssetCreationEditorSettings_t0FF28D2E78F090105C63C81F9E438A7B09E3EA52_marshaled_pinvoke
{
	char* ___sourceFontFileGUID;
	int32_t ___faceIndex;
	int32_t ___pointSizeSamplingMode;
	int32_t ___pointSize;
	int32_t ___padding;
	int32_t ___paddingMode;
	int32_t ___packingMode;
	int32_t ___atlasWidth;
	int32_t ___atlasHeight;
	int32_t ___characterSetSelectionMode;
	char* ___characterSequence;
	char* ___referencedFontAssetGUID;
	char* ___referencedTextAssetGUID;
	int32_t ___fontStyle;
	float ___fontStyleModifier;
	int32_t ___renderMode;
	int32_t ___includeFontFeatures;
};
struct FontAssetCreationEditorSettings_t0FF28D2E78F090105C63C81F9E438A7B09E3EA52_marshaled_com
{
	Il2CppChar* ___sourceFontFileGUID;
	int32_t ___faceIndex;
	int32_t ___pointSizeSamplingMode;
	int32_t ___pointSize;
	int32_t ___padding;
	int32_t ___paddingMode;
	int32_t ___packingMode;
	int32_t ___atlasWidth;
	int32_t ___atlasHeight;
	int32_t ___characterSetSelectionMode;
	Il2CppChar* ___characterSequence;
	Il2CppChar* ___referencedFontAssetGUID;
	Il2CppChar* ___referencedTextAssetGUID;
	int32_t ___fontStyle;
	float ___fontStyleModifier;
	int32_t ___renderMode;
	int32_t ___includeFontFeatures;
};
struct FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7 
{
	uint8_t ___bold;
	uint8_t ___italic;
	uint8_t ___underline;
	uint8_t ___strikethrough;
	uint8_t ___highlight;
	uint8_t ___superscript;
	uint8_t ___subscript;
	uint8_t ___uppercase;
	uint8_t ___lowercase;
	uint8_t ___smallcaps;
};
struct GlyphAnchorPoint_t581FDCAD5A1D0F3B129968FAEF20C113AAB0BC08 
{
	float ___m_XCoordinate;
	float ___m_YCoordinate;
};
struct GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A 
{
	float ___m_Width;
	float ___m_Height;
	float ___m_HorizontalBearingX;
	float ___m_HorizontalBearingY;
	float ___m_HorizontalAdvance;
};
struct GlyphRect_tB6D225B9318A527A1CBC1B4078EB923398EB808D 
{
	int32_t ___m_X;
	int32_t ___m_Y;
	int32_t ___m_Width;
	int32_t ___m_Height;
};
struct GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E 
{
	float ___m_XPlacement;
	float ___m_YPlacement;
	float ___m_XAdvance;
	float ___m_YAdvance;
};
struct Int32_t680FF22E76F6EFAD4375103CBBFFA0421349384C 
{
	int32_t ___m_value;
};
struct IntPtr_t 
{
	void* ___m_value;
};
struct MarkPositionAdjustment_t2523798D56F14A93A080D9D1298498325A51F436 
{
	float ___m_XPositionAdjustment;
	float ___m_YPositionAdjustment;
};
struct MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 
{
	int32_t ___index;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material;
	bool ___isDefaultMaterial;
	bool ___isFallbackMaterial;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___fallbackMaterial;
	float ___padding;
	int32_t ___referenceCount;
};
struct MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26_marshaled_pinvoke
{
	int32_t ___index;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material;
	int32_t ___isDefaultMaterial;
	int32_t ___isFallbackMaterial;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___fallbackMaterial;
	float ___padding;
	int32_t ___referenceCount;
};
struct MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26_marshaled_com
{
	int32_t ___index;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material;
	int32_t ___isDefaultMaterial;
	int32_t ___isFallbackMaterial;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___fallbackMaterial;
	float ___padding;
	int32_t ___referenceCount;
};
struct Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 
{
	float ___m00;
	float ___m10;
	float ___m20;
	float ___m30;
	float ___m01;
	float ___m11;
	float ___m21;
	float ___m31;
	float ___m02;
	float ___m12;
	float ___m22;
	float ___m32;
	float ___m03;
	float ___m13;
	float ___m23;
	float ___m33;
};
struct Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4 
{
	float ___m_Left;
	float ___m_Right;
	float ___m_Top;
	float ___m_Bottom;
};
struct PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909 
{
	int32_t ___firstCharacterIndex;
	int32_t ___lastCharacterIndex;
	float ___ascender;
	float ___baseLine;
	float ___descender;
};
struct Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 
{
	float ___x;
	float ___y;
	float ___z;
	float ___w;
};
struct Rect_tA04E0F8A1830E767F40FB27ECD8D309303571F0D 
{
	float ___m_XMin;
	float ___m_YMin;
	float ___m_Width;
	float ___m_Height;
};
struct Single_t4530F2FF86FCB0DC29F35385CA1BD21BE294761C 
{
	float ___m_value;
};
struct TextBackingContainer_t72D97EE144D48752E621D2AA89DEA62AB7D037CE 
{
	UInt32U5BU5D_t02FBD658AD156A17574ECE6106CF1FBFCC9807FA* ___m_Array;
	int32_t ___m_Count;
};
struct TextBackingContainer_t72D97EE144D48752E621D2AA89DEA62AB7D037CE_marshaled_pinvoke
{
	Il2CppSafeArray* ___m_Array;
	int32_t ___m_Count;
};
struct TextBackingContainer_t72D97EE144D48752E621D2AA89DEA62AB7D037CE_marshaled_com
{
	Il2CppSafeArray* ___m_Array;
	int32_t ___m_Count;
};
struct UInt32_t1833D51FFA667B18A5AA4B8D34DE284F8495D29B 
{
	uint32_t ___m_value;
};
struct Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 
{
	float ___x;
	float ___y;
};
struct Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 
{
	float ___x;
	float ___y;
	float ___z;
};
struct Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 
{
	float ___x;
	float ___y;
	float ___z;
	float ___w;
};
struct Void_t4861ACF8F4594C3437BB48B6E56783494B843915 
{
	union
	{
		struct
		{
		};
		uint8_t Void_t4861ACF8F4594C3437BB48B6E56783494B843915__padding[1];
	};
};
struct WordInfo_tA466206097891A5A2590896EE164AFC406EB060D 
{
	int32_t ___firstCharacterIndex;
	int32_t ___lastCharacterIndex;
	int32_t ___characterCount;
};
struct SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD 
{
	Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* ___character;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material;
	int32_t ___materialIndex;
};
struct SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD_marshaled_pinvoke
{
	Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* ___character;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material;
	int32_t ___materialIndex;
};
struct SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD_marshaled_com
{
	Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* ___character;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material;
	int32_t ___materialIndex;
};
struct TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 
{
	Color32U5BU5D_t38116C3E91765C4C5726CE12C77FAD7F9F737259* ___itemStack;
	int32_t ___index;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___m_DefaultItem;
	int32_t ___m_Capacity;
	int32_t ___m_RolloverSize;
	int32_t ___m_Count;
};
struct TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA 
{
	MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E* ___itemStack;
	int32_t ___index;
	MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 ___m_DefaultItem;
	int32_t ___m_Capacity;
	int32_t ___m_RolloverSize;
	int32_t ___m_Count;
};
struct AtlasPopulationMode_tD12439CB3789E0F868A2A2AC7D623C9B835E1B79 
{
	int32_t ___value__;
};
struct ColorGradientMode_t36364E6ABCEC0A0DBE9BAFF9F40DA5FFDCD969D0 
{
	int32_t ___value__;
};
struct ColorSpace_tD0808E0BE85FD3B9774234676F83A872F4EDA3C7 
{
	int32_t ___value__;
};
struct Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 
{
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___min;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___max;
};
struct FontFeatureLookupFlags_t2000121BA341A3CAE5E0D4FAC6AA4378FE14AE1B 
{
	int32_t ___value__;
};
struct FontStyles_t284AF8C10031F4774DF8BC8DE6DF9EC11EE14668 
{
	int32_t ___value__;
};
struct GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 
{
	uint32_t ___m_GlyphIndex;
	GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E ___m_GlyphValueRecord;
};
struct GlyphClassDefinitionType_t9C21A3848A07B17C2690F285B5FA60A2E246FBA2 
{
	int32_t ___value__;
};
struct GlyphRenderMode_tE7FB60827750662A45E89D168932FE2D8AEB5281 
{
	int32_t ___value__;
};
struct HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 
{
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___color;
	Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4 ___padding;
};
struct Int32Enum_tCBAC8BA2BFF3A845FA599F303093BBBA374B6F0C 
{
	int32_t ___value__;
};
struct MarkToBaseAdjustmentRecord_t4BE0F5A88932146F70A2B521176BDA91A20D8607 
{
	uint32_t ___m_BaseGlyphID;
	GlyphAnchorPoint_t581FDCAD5A1D0F3B129968FAEF20C113AAB0BC08 ___m_BaseGlyphAnchorPoint;
	uint32_t ___m_MarkGlyphID;
	MarkPositionAdjustment_t2523798D56F14A93A080D9D1298498325A51F436 ___m_MarkPositionAdjustment;
};
struct MarkToMarkAdjustmentRecord_tD53618A3728435D5C904857DAC644EE27640807C 
{
	uint32_t ___m_BaseMarkGlyphID;
	GlyphAnchorPoint_t581FDCAD5A1D0F3B129968FAEF20C113AAB0BC08 ___m_BaseMarkGlyphAnchorPoint;
	uint32_t ___m_CombiningMarkGlyphID;
	MarkPositionAdjustment_t2523798D56F14A93A080D9D1298498325A51F436 ___m_CombiningMarkPositionAdjustment;
};
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C  : public RuntimeObject
{
	intptr_t ___m_CachedPtr;
};
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr;
};
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_com
{
	intptr_t ___m_CachedPtr;
};
struct ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD 
{
	intptr_t ___m_Ptr;
};
struct TextAlignment_tD681BE7D2451C44115A90D2D8AA7D91C78A5A070 
{
	int32_t ___value__;
};
struct TextElementType_tEBCF09EEF888E8B1F62D3DD66AF21890D12545EB 
{
	uint8_t ___value__;
};
struct TextFontWeight_t789E26840C291C6C1270D4434CE007ACDFA40350 
{
	int32_t ___value__;
};
struct TextInputSource_t263451F8922D8A7ACB4051C197BE67511CEB58E1 
{
	int32_t ___value__;
};
struct TextOverflowMode_tB7F9FB28B889C1F21B14D3DAC32980D71D9D7F50 
{
	int32_t ___value__;
};
struct TextProcessingElementType_t0F469889070F147273CE0C33D25C8A80E11C1319 
{
	int32_t ___value__;
};
struct TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___position;
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___uv;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___uv2;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___color;
};
struct TextWrappingMode_t04D97C2B1A0E2A2157AD2ECDFAD9F049C97E811A 
{
	int32_t ___value__;
};
struct TextureMapping_t14CF4FEE624B1D968B076DAE56E67AA4756B653A 
{
	int32_t ___value__;
};
struct VertexSortingOrder_tEA3D744EB3D7C496D69F756B98344FDA38432EB9 
{
	int32_t ___value__;
};
struct TextProcessingStack_1_tF3616757510D9631241E95596F10A4139420DA16 
{
	HighlightStateU5BU5D_tCF5677B4773947CE4C64B938B12AC50DDA347435* ___itemStack;
	int32_t ___index;
	HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 ___m_DefaultItem;
	int32_t ___m_Capacity;
	int32_t ___m_RolloverSize;
	int32_t ___m_Count;
};
struct TextProcessingStack_1_t9C24840D494C4878BD8680855123926D6243C90D 
{
	Int32EnumU5BU5D_t87B7DB802810C38016332669039EF42C487A081F* ___itemStack;
	int32_t ___index;
	int32_t ___m_DefaultItem;
	int32_t ___m_Capacity;
	int32_t ___m_RolloverSize;
	int32_t ___m_Count;
};
struct TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F 
{
	TextAlignmentU5BU5D_t756DC2D672145699CB9718DDBA5982ED51A95F49* ___itemStack;
	int32_t ___index;
	int32_t ___m_DefaultItem;
	int32_t ___m_Capacity;
	int32_t ___m_RolloverSize;
	int32_t ___m_Count;
};
struct TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790 
{
	TextFontWeightU5BU5D_t3DE32809AEE657255C8333897D61F2EA5279D43F* ___itemStack;
	int32_t ___index;
	int32_t ___m_DefaultItem;
	int32_t ___m_Capacity;
	int32_t ___m_RolloverSize;
	int32_t ___m_Count;
};
struct Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F  : public RuntimeObject
{
	uint32_t ___m_Index;
	GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A ___m_Metrics;
	GlyphRect_tB6D225B9318A527A1CBC1B4078EB923398EB808D ___m_GlyphRect;
	float ___m_Scale;
	int32_t ___m_AtlasIndex;
	int32_t ___m_ClassDefinitionType;
};
struct Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F_marshaled_pinvoke
{
	uint32_t ___m_Index;
	GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A ___m_Metrics;
	GlyphRect_tB6D225B9318A527A1CBC1B4078EB923398EB808D ___m_GlyphRect;
	float ___m_Scale;
	int32_t ___m_AtlasIndex;
	int32_t ___m_ClassDefinitionType;
};
struct Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F_marshaled_com
{
	uint32_t ___m_Index;
	GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A ___m_Metrics;
	GlyphRect_tB6D225B9318A527A1CBC1B4078EB923398EB808D ___m_GlyphRect;
	float ___m_Scale;
	int32_t ___m_AtlasIndex;
	int32_t ___m_ClassDefinitionType;
};
struct GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E 
{
	GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 ___m_FirstAdjustmentRecord;
	GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 ___m_SecondAdjustmentRecord;
	int32_t ___m_FeatureLookupFlags;
};
struct LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 
{
	int32_t ___controlCharacterCount;
	int32_t ___characterCount;
	int32_t ___visibleCharacterCount;
	int32_t ___spaceCount;
	int32_t ___visibleSpaceCount;
	int32_t ___wordCount;
	int32_t ___firstCharacterIndex;
	int32_t ___firstVisibleCharacterIndex;
	int32_t ___lastCharacterIndex;
	int32_t ___lastVisibleCharacterIndex;
	float ___length;
	float ___lineHeight;
	float ___ascender;
	float ___baseline;
	float ___descender;
	float ___maxAdvance;
	float ___width;
	float ___marginLeft;
	float ___marginRight;
	int32_t ___alignment;
	Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 ___lineExtents;
};
struct Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3  : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C
{
};
struct MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F 
{
	int32_t ___vertexCount;
	Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* ___vertices;
	Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* ___normals;
	Vector4U5BU5D_tC0F3A7115F85007510F6D173968200CD31BCF7AD* ___tangents;
	Vector4U5BU5D_tC0F3A7115F85007510F6D173968200CD31BCF7AD* ___uvs0;
	Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA* ___uvs2;
	Color32U5BU5D_t38116C3E91765C4C5726CE12C77FAD7F9F737259* ___colors32;
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ___triangles;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material;
	int32_t ___glyphRenderMode;
};
struct MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F_marshaled_pinvoke
{
	int32_t ___vertexCount;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* ___vertices;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* ___normals;
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3* ___tangents;
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3* ___uvs0;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* ___uvs2;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B* ___colors32;
	Il2CppSafeArray* ___triangles;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material;
	int32_t ___glyphRenderMode;
};
struct MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F_marshaled_com
{
	int32_t ___vertexCount;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* ___vertices;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* ___normals;
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3* ___tangents;
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3* ___uvs0;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* ___uvs2;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B* ___colors32;
	Il2CppSafeArray* ___triangles;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material;
	int32_t ___glyphRenderMode;
};
struct ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A  : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C
{
};
struct ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A_marshaled_pinvoke : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_pinvoke
{
};
struct ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A_marshaled_com : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_com
{
};
struct TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA  : public RuntimeObject
{
	uint8_t ___m_ElementType;
	uint32_t ___m_Unicode;
	TextAsset_tB28F1843A877CCA74B89DC4F63EA532618B049B8* ___m_TextAsset;
	Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* ___m_Glyph;
	uint32_t ___m_GlyphIndex;
	float ___m_Scale;
};
struct TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2  : public RuntimeObject
{
	String_t* ___text;
	Rect_tA04E0F8A1830E767F40FB27ECD8D309303571F0D ___screenRect;
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___margins;
	float ___scale;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset;
	TextStyleSheet_t86A0FA5523897465F371A2ABC17DFA3558C8D15E* ___styleSheet;
	int32_t ___fontStyle;
	TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64* ___textSettings;
	int32_t ___textAlignment;
	int32_t ___overflowMode;
	bool ___wordWrap;
	float ___wordWrappingRatio;
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___color;
	TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70* ___fontColorGradient;
	TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70* ___fontColorGradientPreset;
	bool ___tintSprites;
	bool ___overrideRichTextColors;
	bool ___shouldConvertToLinearSpace;
	float ___fontSize;
	bool ___autoSize;
	float ___fontSizeMin;
	float ___fontSizeMax;
	bool ___enableKerning;
	bool ___richText;
	bool ___isRightToLeft;
	float ___extraPadding;
	bool ___parseControlCharacters;
	bool ___isOrthographic;
	bool ___tagNoParsing;
	float ___characterSpacing;
	float ___wordSpacing;
	float ___lineSpacing;
	float ___paragraphSpacing;
	float ___lineSpacingMax;
	int32_t ___textWrappingMode;
	int32_t ___maxVisibleCharacters;
	int32_t ___maxVisibleWords;
	int32_t ___maxVisibleLines;
	int32_t ___firstVisibleCharacter;
	bool ___useMaxVisibleDescender;
	int32_t ___fontWeight;
	int32_t ___pageToDisplay;
	int32_t ___horizontalMapping;
	int32_t ___verticalMapping;
	float ___uvLineOffset;
	int32_t ___geometrySortingOrder;
	bool ___inverseYAxis;
	float ___charWidthMaxAdj;
	int32_t ___inputSource;
};
struct TextProcessingElement_tDCD1EAF9D54829E796F4F9726D63B205344C7698 
{
	int32_t ___elementType;
	uint32_t ___unicode;
	int32_t ___stringIndex;
	int32_t ___length;
};
struct Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC  : public TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA
{
};
struct SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5  : public TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA
{
	String_t* ___m_Name;
};
struct TextAsset_tB28F1843A877CCA74B89DC4F63EA532618B049B8  : public ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A
{
	String_t* ___m_Version;
	int32_t ___m_InstanceID;
	int32_t ___m_HashCode;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___m_Material;
	int32_t ___m_MaterialHashCode;
};
struct TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70  : public ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A
{
	int32_t ___colorMode;
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___topLeft;
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___topRight;
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___bottomLeft;
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___bottomRight;
};
struct TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 
{
	Il2CppChar ___character;
	int32_t ___index;
	uint8_t ___elementType;
	int32_t ___stringLength;
	TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* ___textElement;
	Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* ___alternativeGlyph;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset;
	int32_t ___spriteIndex;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material;
	int32_t ___materialReferenceIndex;
	bool ___isUsingAlternateTypeface;
	float ___pointSize;
	int32_t ___lineNumber;
	int32_t ___pageNumber;
	int32_t ___vertexIndex;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexTopLeft;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexBottomLeft;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexTopRight;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexBottomRight;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___topLeft;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___bottomLeft;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___topRight;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___bottomRight;
	float ___origin;
	float ___ascender;
	float ___baseLine;
	float ___descender;
	float ___adjustedAscender;
	float ___adjustedDescender;
	float ___adjustedHorizontalAdvance;
	float ___xAdvance;
	float ___aspectRatio;
	float ___scale;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___color;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___underlineColor;
	int32_t ___underlineVertexIndex;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___strikethroughColor;
	int32_t ___strikethroughVertexIndex;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___highlightColor;
	HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 ___highlightState;
	int32_t ___style;
	bool ___isVisible;
};
struct TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976_marshaled_pinvoke
{
	uint8_t ___character;
	int32_t ___index;
	uint8_t ___elementType;
	int32_t ___stringLength;
	TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* ___textElement;
	Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F_marshaled_pinvoke ___alternativeGlyph;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset;
	int32_t ___spriteIndex;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material;
	int32_t ___materialReferenceIndex;
	int32_t ___isUsingAlternateTypeface;
	float ___pointSize;
	int32_t ___lineNumber;
	int32_t ___pageNumber;
	int32_t ___vertexIndex;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexTopLeft;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexBottomLeft;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexTopRight;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexBottomRight;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___topLeft;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___bottomLeft;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___topRight;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___bottomRight;
	float ___origin;
	float ___ascender;
	float ___baseLine;
	float ___descender;
	float ___adjustedAscender;
	float ___adjustedDescender;
	float ___adjustedHorizontalAdvance;
	float ___xAdvance;
	float ___aspectRatio;
	float ___scale;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___color;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___underlineColor;
	int32_t ___underlineVertexIndex;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___strikethroughColor;
	int32_t ___strikethroughVertexIndex;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___highlightColor;
	HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 ___highlightState;
	int32_t ___style;
	int32_t ___isVisible;
};
struct TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976_marshaled_com
{
	uint8_t ___character;
	int32_t ___index;
	uint8_t ___elementType;
	int32_t ___stringLength;
	TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* ___textElement;
	Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F_marshaled_com* ___alternativeGlyph;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset;
	int32_t ___spriteIndex;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material;
	int32_t ___materialReferenceIndex;
	int32_t ___isUsingAlternateTypeface;
	float ___pointSize;
	int32_t ___lineNumber;
	int32_t ___pageNumber;
	int32_t ___vertexIndex;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexTopLeft;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexBottomLeft;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexTopRight;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexBottomRight;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___topLeft;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___bottomLeft;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___topRight;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___bottomRight;
	float ___origin;
	float ___ascender;
	float ___baseLine;
	float ___descender;
	float ___adjustedAscender;
	float ___adjustedDescender;
	float ___adjustedHorizontalAdvance;
	float ___xAdvance;
	float ___aspectRatio;
	float ___scale;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___color;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___underlineColor;
	int32_t ___underlineVertexIndex;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___strikethroughColor;
	int32_t ___strikethroughVertexIndex;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___highlightColor;
	HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 ___highlightState;
	int32_t ___style;
	int32_t ___isVisible;
};
struct TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64  : public ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A
{
	String_t* ___m_Version;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___m_DefaultFontAsset;
	String_t* ___m_DefaultFontAssetPath;
	List_1_t55B85B981AC5FD6A5358491F90FE354F78BB97DE* ___m_FallbackFontAssets;
	bool ___m_MatchMaterialPreset;
	int32_t ___m_MissingCharacterUnicode;
	bool ___m_ClearDynamicDataOnBuild;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___m_DefaultSpriteAsset;
	String_t* ___m_DefaultSpriteAssetPath;
	List_1_t3EE59C28A34FCD5060EF6B6BAFA85F2C9D01D320* ___m_FallbackSpriteAssets;
	uint32_t ___m_MissingSpriteCharacterUnicode;
	TextStyleSheet_t86A0FA5523897465F371A2ABC17DFA3558C8D15E* ___m_DefaultStyleSheet;
	String_t* ___m_StyleSheetsResourcePath;
	String_t* ___m_DefaultColorGradientPresetsPath;
	UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* ___m_UnicodeLineBreakingRules;
	bool ___m_UseModernHangulLineBreakingRules;
	bool ___m_DisplayWarnings;
	Dictionary_2_tC20B3D6AE4370C892734F670EF4D1FB9CE91F371* ___m_FontLookup;
	List_1_tA1547550E5FBA50050B20DA74245C38434654EE8* ___m_FontReferences;
};
struct WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 
{
	int32_t ___previousWordBreak;
	int32_t ___totalCharacterCount;
	int32_t ___visibleCharacterCount;
	int32_t ___visibleSpaceCount;
	int32_t ___visibleSpriteCount;
	int32_t ___visibleLinkCount;
	int32_t ___firstCharacterIndex;
	int32_t ___firstVisibleCharacterIndex;
	int32_t ___lastCharacterIndex;
	int32_t ___lastVisibleCharIndex;
	int32_t ___lineNumber;
	float ___maxCapHeight;
	float ___maxAscender;
	float ___maxDescender;
	float ___maxLineAscender;
	float ___maxLineDescender;
	float ___startOfLineAscender;
	float ___xAdvance;
	float ___preferredWidth;
	float ___preferredHeight;
	float ___previousLineScale;
	float ___pageAscender;
	int32_t ___wordCount;
	int32_t ___fontStyle;
	float ___fontScale;
	float ___fontScaleMultiplier;
	int32_t ___italicAngle;
	float ___currentFontSize;
	float ___baselineOffset;
	float ___lineOffset;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 ___lineInfo;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___vertexColor;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___underlineColor;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___strikethroughColor;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___highlightColor;
	HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 ___highlightState;
	FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7 ___basicStyleStack;
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___italicAngleStack;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___colorStack;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___underlineColorStack;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___strikethroughColorStack;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___highlightColorStack;
	TextProcessingStack_1_tF3616757510D9631241E95596F10A4139420DA16 ___highlightStateStack;
	TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E ___colorGradientStack;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___sizeStack;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___indentStack;
	TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790 ___fontWeightStack;
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___styleStack;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___baselineStack;
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___actionStack;
	TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA ___materialReferenceStack;
	TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F ___lineJustificationStack;
	int32_t ___lastBaseGlyphIndex;
	int32_t ___spriteAnimationId;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___currentFontAsset;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___currentSpriteAsset;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___currentMaterial;
	int32_t ___currentMaterialIndex;
	Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 ___meshExtents;
	bool ___tagNoParsing;
	bool ___isNonBreakingSpace;
	bool ___isDrivenLineSpacing;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___fxScale;
	Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___fxRotation;
};
struct WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123_marshaled_pinvoke
{
	int32_t ___previousWordBreak;
	int32_t ___totalCharacterCount;
	int32_t ___visibleCharacterCount;
	int32_t ___visibleSpaceCount;
	int32_t ___visibleSpriteCount;
	int32_t ___visibleLinkCount;
	int32_t ___firstCharacterIndex;
	int32_t ___firstVisibleCharacterIndex;
	int32_t ___lastCharacterIndex;
	int32_t ___lastVisibleCharIndex;
	int32_t ___lineNumber;
	float ___maxCapHeight;
	float ___maxAscender;
	float ___maxDescender;
	float ___maxLineAscender;
	float ___maxLineDescender;
	float ___startOfLineAscender;
	float ___xAdvance;
	float ___preferredWidth;
	float ___preferredHeight;
	float ___previousLineScale;
	float ___pageAscender;
	int32_t ___wordCount;
	int32_t ___fontStyle;
	float ___fontScale;
	float ___fontScaleMultiplier;
	int32_t ___italicAngle;
	float ___currentFontSize;
	float ___baselineOffset;
	float ___lineOffset;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 ___lineInfo;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___vertexColor;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___underlineColor;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___strikethroughColor;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___highlightColor;
	HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 ___highlightState;
	FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7 ___basicStyleStack;
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___italicAngleStack;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___colorStack;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___underlineColorStack;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___strikethroughColorStack;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___highlightColorStack;
	TextProcessingStack_1_tF3616757510D9631241E95596F10A4139420DA16 ___highlightStateStack;
	TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E ___colorGradientStack;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___sizeStack;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___indentStack;
	TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790 ___fontWeightStack;
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___styleStack;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___baselineStack;
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___actionStack;
	TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA ___materialReferenceStack;
	TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F ___lineJustificationStack;
	int32_t ___lastBaseGlyphIndex;
	int32_t ___spriteAnimationId;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___currentFontAsset;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___currentSpriteAsset;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___currentMaterial;
	int32_t ___currentMaterialIndex;
	Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 ___meshExtents;
	int32_t ___tagNoParsing;
	int32_t ___isNonBreakingSpace;
	int32_t ___isDrivenLineSpacing;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___fxScale;
	Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___fxRotation;
};
struct WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123_marshaled_com
{
	int32_t ___previousWordBreak;
	int32_t ___totalCharacterCount;
	int32_t ___visibleCharacterCount;
	int32_t ___visibleSpaceCount;
	int32_t ___visibleSpriteCount;
	int32_t ___visibleLinkCount;
	int32_t ___firstCharacterIndex;
	int32_t ___firstVisibleCharacterIndex;
	int32_t ___lastCharacterIndex;
	int32_t ___lastVisibleCharIndex;
	int32_t ___lineNumber;
	float ___maxCapHeight;
	float ___maxAscender;
	float ___maxDescender;
	float ___maxLineAscender;
	float ___maxLineDescender;
	float ___startOfLineAscender;
	float ___xAdvance;
	float ___preferredWidth;
	float ___preferredHeight;
	float ___previousLineScale;
	float ___pageAscender;
	int32_t ___wordCount;
	int32_t ___fontStyle;
	float ___fontScale;
	float ___fontScaleMultiplier;
	int32_t ___italicAngle;
	float ___currentFontSize;
	float ___baselineOffset;
	float ___lineOffset;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 ___lineInfo;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___vertexColor;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___underlineColor;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___strikethroughColor;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___highlightColor;
	HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 ___highlightState;
	FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7 ___basicStyleStack;
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___italicAngleStack;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___colorStack;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___underlineColorStack;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___strikethroughColorStack;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___highlightColorStack;
	TextProcessingStack_1_tF3616757510D9631241E95596F10A4139420DA16 ___highlightStateStack;
	TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E ___colorGradientStack;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___sizeStack;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___indentStack;
	TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790 ___fontWeightStack;
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___styleStack;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___baselineStack;
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___actionStack;
	TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA ___materialReferenceStack;
	TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F ___lineJustificationStack;
	int32_t ___lastBaseGlyphIndex;
	int32_t ___spriteAnimationId;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___currentFontAsset;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___currentSpriteAsset;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___currentMaterial;
	int32_t ___currentMaterialIndex;
	Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 ___meshExtents;
	int32_t ___tagNoParsing;
	int32_t ___isNonBreakingSpace;
	int32_t ___isDrivenLineSpacing;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___fxScale;
	Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___fxRotation;
};
struct TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9 
{
	WordWrapStateU5BU5D_t4AA4AAC14B38359416C63A57A1ADDD9C2004EAC8* ___itemStack;
	int32_t ___index;
	WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 ___m_DefaultItem;
	int32_t ___m_Capacity;
	int32_t ___m_RolloverSize;
	int32_t ___m_Count;
};
struct FontAsset_t61A6446D934E582651044E33D250EA8D306AB958  : public TextAsset_tB28F1843A877CCA74B89DC4F63EA532618B049B8
{
	String_t* ___m_SourceFontFileGUID;
	FontAssetCreationEditorSettings_t0FF28D2E78F090105C63C81F9E438A7B09E3EA52 ___m_fontAssetCreationEditorSettings;
	Font_tC95270EA3198038970422D78B74A7F2E218A96B6* ___m_SourceFontFile;
	String_t* ___m_SourceFontFilePath;
	int32_t ___m_AtlasPopulationMode;
	bool ___InternalDynamicOS;
	FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 ___m_FaceInfo;
	int32_t ___m_FamilyNameHashCode;
	int32_t ___m_StyleNameHashCode;
	List_1_t95DB74B8EE315F8F92B7B96D93C901C8C3F6FE2C* ___m_GlyphTable;
	Dictionary_2_tC61348D10610A6B3D7B65102D82AC3467D59EAA7* ___m_GlyphLookupDictionary;
	List_1_tFED0F30EE65D995591571D3CD2C10F22439CB317* ___m_CharacterTable;
	Dictionary_2_t93CDF0F4011A5A3024EB73A492F9512E3046EACB* ___m_CharacterLookupDictionary;
	Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* ___m_AtlasTexture;
	Texture2DU5BU5D_t05332F1E3F7D4493E304C702201F9BE4F9236191* ___m_AtlasTextures;
	int32_t ___m_AtlasTextureIndex;
	bool ___m_IsMultiAtlasTexturesEnabled;
	bool ___m_ClearDynamicDataOnBuild;
	int32_t ___m_AtlasWidth;
	int32_t ___m_AtlasHeight;
	int32_t ___m_AtlasPadding;
	int32_t ___m_AtlasRenderMode;
	List_1_t425D3A455811E316D2DF73E46CF9CD90A4341C1B* ___m_UsedGlyphRects;
	List_1_t425D3A455811E316D2DF73E46CF9CD90A4341C1B* ___m_FreeGlyphRects;
	FontFeatureTable_t992E0493CD7E9D7834DF204E0198237F0D25B3B7* ___m_FontFeatureTable;
	List_1_t55B85B981AC5FD6A5358491F90FE354F78BB97DE* ___m_FallbackFontAssetTable;
	FontWeightPairU5BU5D_t76E8DB55C81EEBEFA2E6D1D3E3B3EA1FB4C4954F* ___m_FontWeightTable;
	float ___m_RegularStyleWeight;
	float ___m_RegularStyleSpacing;
	float ___m_BoldStyleWeight;
	float ___m_BoldStyleSpacing;
	uint8_t ___m_ItalicStyleSlant;
	uint8_t ___m_TabMultiple;
	bool ___IsFontAssetLookupTablesDirty;
	List_1_t95DB74B8EE315F8F92B7B96D93C901C8C3F6FE2C* ___m_GlyphsToRender;
	List_1_t95DB74B8EE315F8F92B7B96D93C901C8C3F6FE2C* ___m_GlyphsRendered;
	List_1_t9B68833848E4C4D7F623C05F6B77F0449396354A* ___m_GlyphIndexList;
	List_1_t9B68833848E4C4D7F623C05F6B77F0449396354A* ___m_GlyphIndexListNewlyAdded;
	List_1_t9B68833848E4C4D7F623C05F6B77F0449396354A* ___m_GlyphsToAdd;
	HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* ___m_GlyphsToAddLookup;
	List_1_tFED0F30EE65D995591571D3CD2C10F22439CB317* ___m_CharactersToAdd;
	HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* ___m_CharactersToAddLookup;
	List_1_t9B68833848E4C4D7F623C05F6B77F0449396354A* ___s_MissingCharacterList;
	HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* ___m_MissingUnicodesFromFontFile;
};
struct SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313  : public TextAsset_tB28F1843A877CCA74B89DC4F63EA532618B049B8
{
	Dictionary_2_tABE19B9C5C52F1DE14F0D3287B2696E7D7419180* ___m_NameLookup;
	Dictionary_2_t1A4804CA9724B6CE01D6ECABE81CE0848CBA80B4* ___m_GlyphIndexLookup;
	FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 ___m_FaceInfo;
	Texture_t791CBB51219779964E0E8A2ED7C1AA5F92A4A700* ___m_SpriteAtlasTexture;
	List_1_t7DA088250C54C07AF1211AE132355AD2D343EE51* ___m_SpriteCharacterTable;
	Dictionary_2_tD4154357CA320908C5A7A35ED81FA2A9856C28D9* ___m_SpriteCharacterLookup;
	List_1_t063B87D3CFDC3AEE80E33EFBDA1410C697D71AD6* ___m_SpriteGlyphTable;
	Dictionary_2_tDC0461D8CBB2E6B52DD2C421114EDE7C1C70DE73* ___m_SpriteGlyphLookup;
	List_1_t3EE59C28A34FCD5060EF6B6BAFA85F2C9D01D320* ___fallbackSpriteAssets;
	bool ___m_IsSpriteAssetLookupTablesDirty;
};
struct TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366  : public RuntimeObject
{
	TextBackingContainer_t72D97EE144D48752E621D2AA89DEA62AB7D037CE ___m_TextBackingArray;
	TextProcessingElementU5BU5D_t24A1E4C8745577D794FE856B4236875595E7FD22* ___m_TextProcessingArray;
	int32_t ___m_InternalTextProcessingArraySize;
	bool ___m_VertexBufferAutoSizeReduction;
	CharU5BU5D_t799905CF001DD5F13F7DBB310181FC4D8B7D0AAB* ___m_HtmlTag;
	HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 ___m_HighlightState;
	bool ___m_IsIgnoringAlignment;
	Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* ___m_RectTransformCorners;
	float ___m_MarginWidth;
	float ___m_MarginHeight;
	float ___m_PreferredWidth;
	float ___m_PreferredHeight;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___m_CurrentFontAsset;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___m_CurrentMaterial;
	int32_t ___m_CurrentMaterialIndex;
	TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA ___m_MaterialReferenceStack;
	float ___m_Padding;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___m_CurrentSpriteAsset;
	int32_t ___m_TotalCharacterCount;
	float ___m_FontSize;
	float ___m_FontScaleMultiplier;
	float ___m_CurrentFontSize;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___m_SizeStack;
	TextProcessingStack_1U5BU5D_t2552082EA18234192F7BABAE183356A81363BB6F* ___m_TextStyleStacks;
	int32_t ___m_TextStyleStackDepth;
	int32_t ___m_FontStyleInternal;
	FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7 ___m_FontStyleStack;
	int32_t ___m_FontWeightInternal;
	TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790 ___m_FontWeightStack;
	int32_t ___m_LineJustification;
	TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F ___m_LineJustificationStack;
	float ___m_BaselineOffset;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___m_BaselineOffsetStack;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___m_FontColor32;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___m_HtmlColor;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___m_UnderlineColor;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___m_StrikethroughColor;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___m_ColorStack;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___m_UnderlineColorStack;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___m_StrikethroughColorStack;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___m_HighlightColorStack;
	TextProcessingStack_1_tF3616757510D9631241E95596F10A4139420DA16 ___m_HighlightStateStack;
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___m_ItalicAngleStack;
	TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70* ___m_ColorGradientPreset;
	TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E ___m_ColorGradientStack;
	bool ___m_ColorGradientPresetIsTinted;
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___m_ActionStack;
	float ___m_LineOffset;
	float ___m_LineHeight;
	bool ___m_IsDrivenLineSpacing;
	float ___m_CSpacing;
	float ___m_MonoSpacing;
	float ___m_XAdvance;
	float ___m_TagLineIndent;
	float ___m_TagIndent;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___m_IndentStack;
	bool ___m_TagNoParsing;
	int32_t ___m_CharacterCount;
	int32_t ___m_FirstCharacterOfLine;
	int32_t ___m_LastCharacterOfLine;
	int32_t ___m_FirstVisibleCharacterOfLine;
	int32_t ___m_LastVisibleCharacterOfLine;
	float ___m_MaxLineAscender;
	float ___m_MaxLineDescender;
	int32_t ___m_LineNumber;
	int32_t ___m_LineVisibleCharacterCount;
	int32_t ___m_LineVisibleSpaceCount;
	int32_t ___m_FirstOverflowCharacterIndex;
	int32_t ___m_PageNumber;
	float ___m_MarginLeft;
	float ___m_MarginRight;
	float ___m_Width;
	Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 ___m_MeshExtents;
	float ___m_MaxCapHeight;
	float ___m_MaxAscender;
	float ___m_MaxDescender;
	bool ___m_IsNewPage;
	bool ___m_IsNonBreakingSpace;
	WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 ___m_SavedWordWrapState;
	WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 ___m_SavedLineState;
	WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 ___m_SavedEllipsisState;
	WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 ___m_SavedLastValidState;
	WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 ___m_SavedSoftLineBreakState;
	uint8_t ___m_TextElementType;
	bool ___m_isTextLayoutPhase;
	int32_t ___m_SpriteIndex;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___m_SpriteColor;
	TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* ___m_CachedTextElement;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___m_HighlightColor;
	float ___m_CharWidthAdjDelta;
	float ___m_MaxFontSize;
	float ___m_MinFontSize;
	int32_t ___m_AutoSizeIterationCount;
	int32_t ___m_AutoSizeMaxIterationCount;
	bool ___m_IsAutoSizePointSizeSet;
	float ___m_StartOfLineAscender;
	float ___m_LineSpacingDelta;
	MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E* ___m_MaterialReferences;
	int32_t ___m_SpriteCount;
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___m_StyleStack;
	TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9 ___m_EllipsisInsertionCandidateStack;
	int32_t ___m_SpriteAnimationId;
	int32_t ___m_ItalicAngle;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___m_FXScale;
	Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___m_FXRotation;
	int32_t ___m_LastBaseGlyphIndex;
	float ___m_PageAscender;
	RichTextTagAttributeU5BU5D_tEE9D071B3246F23742DBF4226567620BCBB24A14* ___m_XmlAttribute;
	SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* ___m_AttributeParameterValues;
	Dictionary_2_tABE19B9C5C52F1DE14F0D3287B2696E7D7419180* ___m_MaterialReferenceIndexLookup;
	bool ___m_IsCalculatingPreferredValues;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___m_DefaultSpriteAsset;
	bool ___m_TintSprite;
	SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD ___m_Ellipsis;
	SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD ___m_Underline;
	TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* ___m_InternalTextElementInfo;
};
struct String_t_StaticFields
{
	String_t* ___Empty;
};
struct TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_StaticFields
{
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___largePositiveVector2;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___largeNegativeVector2;
};
struct TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09_StaticFields
{
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___s_InfinityVectorPositive;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___s_InfinityVectorNegative;
};
struct TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields
{
	int32_t ___ID_MainTex;
	int32_t ___ID_FaceTex;
	int32_t ___ID_FaceColor;
	int32_t ___ID_FaceDilate;
	int32_t ___ID_Shininess;
	int32_t ___ID_OutlineOffset1;
	int32_t ___ID_OutlineOffset2;
	int32_t ___ID_OutlineOffset3;
	int32_t ___ID_OutlineMode;
	int32_t ___ID_IsoPerimeter;
	int32_t ___ID_Softness;
	int32_t ___ID_UnderlayColor;
	int32_t ___ID_UnderlayOffsetX;
	int32_t ___ID_UnderlayOffsetY;
	int32_t ___ID_UnderlayDilate;
	int32_t ___ID_UnderlaySoftness;
	int32_t ___ID_UnderlayOffset;
	int32_t ___ID_UnderlayIsoPerimeter;
	int32_t ___ID_WeightNormal;
	int32_t ___ID_WeightBold;
	int32_t ___ID_OutlineTex;
	int32_t ___ID_OutlineWidth;
	int32_t ___ID_OutlineSoftness;
	int32_t ___ID_OutlineColor;
	int32_t ___ID_Outline2Color;
	int32_t ___ID_Outline2Width;
	int32_t ___ID_Padding;
	int32_t ___ID_GradientScale;
	int32_t ___ID_ScaleX;
	int32_t ___ID_ScaleY;
	int32_t ___ID_PerspectiveFilter;
	int32_t ___ID_Sharpness;
	int32_t ___ID_TextureWidth;
	int32_t ___ID_TextureHeight;
	int32_t ___ID_BevelAmount;
	int32_t ___ID_GlowColor;
	int32_t ___ID_GlowOffset;
	int32_t ___ID_GlowPower;
	int32_t ___ID_GlowOuter;
	int32_t ___ID_GlowInner;
	int32_t ___ID_LightAngle;
	int32_t ___ID_EnvMap;
	int32_t ___ID_EnvMatrix;
	int32_t ___ID_EnvMatrixRotation;
	int32_t ___ID_MaskCoord;
	int32_t ___ID_ClipRect;
	int32_t ___ID_MaskSoftnessX;
	int32_t ___ID_MaskSoftnessY;
	int32_t ___ID_VertexOffsetX;
	int32_t ___ID_VertexOffsetY;
	int32_t ___ID_UseClipRect;
	int32_t ___ID_StencilID;
	int32_t ___ID_StencilOp;
	int32_t ___ID_StencilComp;
	int32_t ___ID_StencilReadMask;
	int32_t ___ID_StencilWriteMask;
	int32_t ___ID_ShaderFlags;
	int32_t ___ID_ScaleRatio_A;
	int32_t ___ID_ScaleRatio_B;
	int32_t ___ID_ScaleRatio_C;
	String_t* ___Keyword_Bevel;
	String_t* ___Keyword_Glow;
	String_t* ___Keyword_Underlay;
	String_t* ___Keyword_Ratios;
	String_t* ___Keyword_MASK_SOFT;
	String_t* ___Keyword_MASK_HARD;
	String_t* ___Keyword_MASK_TEX;
	String_t* ___Keyword_Outline;
	String_t* ___ShaderTag_ZTestMode;
	String_t* ___ShaderTag_CullMode;
	float ___m_clamp;
	bool ___isInitialized;
	Shader_tADC867D36B7876EE22427FAA2CE485105F4EE692* ___k_ShaderRef_MobileSDF;
	Shader_tADC867D36B7876EE22427FAA2CE485105F4EE692* ___k_ShaderRef_MobileBitmap;
};
struct Boolean_t09A6377A54BE2F9E6985A8149F19234FD7DDFE22_StaticFields
{
	String_t* ___TrueString;
	String_t* ___FalseString;
};
struct Char_t521A6F19B456D956AF452D926C32709DC03D6B17_StaticFields
{
	ByteU5BU5D_tA6237BF417AE52AD70CFB4EF24A7A82613DF9031* ___s_categoryForLatin1;
};
struct Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6_StaticFields
{
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___zeroMatrix;
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___identityMatrix;
};
struct Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4_StaticFields
{
	Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4 ___k_ZeroOffset;
};
struct Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974_StaticFields
{
	Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___identityQuaternion;
};
struct Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7_StaticFields
{
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___zeroVector;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___oneVector;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___upVector;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___downVector;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___leftVector;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___rightVector;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___positiveInfinityVector;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___negativeInfinityVector;
};
struct Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_StaticFields
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___zeroVector;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___oneVector;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___upVector;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___downVector;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___leftVector;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___rightVector;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___forwardVector;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___backVector;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___positiveInfinityVector;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___negativeInfinityVector;
};
struct Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3_StaticFields
{
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___zeroVector;
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___oneVector;
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___positiveInfinityVector;
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___negativeInfinityVector;
};
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_StaticFields
{
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject;
};
struct MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F_StaticFields
{
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___k_DefaultColor;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___k_DefaultNormal;
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___k_DefaultTangent;
};
struct TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70_StaticFields
{
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___k_DefaultColor;
};
struct FontAsset_t61A6446D934E582651044E33D250EA8D306AB958_StaticFields
{
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_ReadFontAssetDefinitionMarker;
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_AddSynthesizedCharactersMarker;
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_TryAddCharacterMarker;
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_TryAddCharactersMarker;
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_UpdateGlyphAdjustmentRecordsMarker;
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_UpdateDiacriticalMarkAdjustmentRecordsMarker;
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_ClearFontAssetDataMarker;
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_UpdateFontAssetDataMarker;
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_TryAddGlyphMarker;
	String_t* ___s_DefaultMaterialSuffix;
	HashSet_1_t4A2F2B74276D0AD3ED0F873045BD61E9504ECAE2* ___k_SearchedFontAssetLookup;
	List_1_t55B85B981AC5FD6A5358491F90FE354F78BB97DE* ___k_FontAssets_FontFeaturesUpdateQueue;
	HashSet_1_t4A2F2B74276D0AD3ED0F873045BD61E9504ECAE2* ___k_FontAssets_FontFeaturesUpdateQueueLookup;
	List_1_t0F231C3F13EBA1FF9081BD61489D01AA3CBE59D4* ___k_FontAssets_AtlasTexturesUpdateQueue;
	HashSet_1_t4A2F2B74276D0AD3ED0F873045BD61E9504ECAE2* ___k_FontAssets_AtlasTexturesUpdateQueueLookup;
	UInt32U5BU5D_t02FBD658AD156A17574ECE6106CF1FBFCC9807FA* ___k_GlyphIndexArray;
};
struct SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313_StaticFields
{
	HashSet_1_t4A2F2B74276D0AD3ED0F873045BD61E9504ECAE2* ___k_searchedSpriteAssets;
};
struct TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366_StaticFields
{
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* ___s_TextGenerator;
	bool ___m_IsTextTruncated;
	MissingCharacterEventCallback_t26E0AD04BD27B7E35AD648D0B549D13330921DED* ___OnMissingCharacter;
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
struct Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C  : public RuntimeArray
{
	ALIGN_FIELD (8) Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 m_Items[1];

	inline Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 value)
	{
		m_Items[index] = value;
	}
};
struct TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E  : public RuntimeArray
{
	ALIGN_FIELD (8) TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 m_Items[1];

	inline TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___textElement), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___alternativeGlyph), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___fontAsset), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___spriteAsset), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___material), (void*)NULL);
		#endif
	}
	inline TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___textElement), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___alternativeGlyph), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___fontAsset), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___spriteAsset), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___material), (void*)NULL);
		#endif
	}
};
struct TextProcessingElementU5BU5D_t24A1E4C8745577D794FE856B4236875595E7FD22  : public RuntimeArray
{
	ALIGN_FIELD (8) TextProcessingElement_tDCD1EAF9D54829E796F4F9726D63B205344C7698 m_Items[1];

	inline TextProcessingElement_tDCD1EAF9D54829E796F4F9726D63B205344C7698 GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline TextProcessingElement_tDCD1EAF9D54829E796F4F9726D63B205344C7698* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, TextProcessingElement_tDCD1EAF9D54829E796F4F9726D63B205344C7698 value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline TextProcessingElement_tDCD1EAF9D54829E796F4F9726D63B205344C7698 GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline TextProcessingElement_tDCD1EAF9D54829E796F4F9726D63B205344C7698* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, TextProcessingElement_tDCD1EAF9D54829E796F4F9726D63B205344C7698 value)
	{
		m_Items[index] = value;
	}
};
struct PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4  : public RuntimeArray
{
	ALIGN_FIELD (8) PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909 m_Items[1];

	inline PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909 GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909 value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909 GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909 value)
	{
		m_Items[index] = value;
	}
};
struct LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D  : public RuntimeArray
{
	ALIGN_FIELD (8) LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 m_Items[1];

	inline LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 value)
	{
		m_Items[index] = value;
	}
};
struct MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6  : public RuntimeArray
{
	ALIGN_FIELD (8) MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F m_Items[1];

	inline MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___vertices), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___normals), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___tangents), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___uvs0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___uvs2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___colors32), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___triangles), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___material), (void*)NULL);
		#endif
	}
	inline MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___vertices), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___normals), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___tangents), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___uvs0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___uvs2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___colors32), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___triangles), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___material), (void*)NULL);
		#endif
	}
};
struct WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B  : public RuntimeArray
{
	ALIGN_FIELD (8) WordInfo_tA466206097891A5A2590896EE164AFC406EB060D m_Items[1];

	inline WordInfo_tA466206097891A5A2590896EE164AFC406EB060D GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline WordInfo_tA466206097891A5A2590896EE164AFC406EB060D* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, WordInfo_tA466206097891A5A2590896EE164AFC406EB060D value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline WordInfo_tA466206097891A5A2590896EE164AFC406EB060D GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline WordInfo_tA466206097891A5A2590896EE164AFC406EB060D* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, WordInfo_tA466206097891A5A2590896EE164AFC406EB060D value)
	{
		m_Items[index] = value;
	}
};
struct MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E  : public RuntimeArray
{
	ALIGN_FIELD (8) MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 m_Items[1];

	inline MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___fontAsset), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___spriteAsset), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___material), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___fallbackMaterial), (void*)NULL);
		#endif
	}
	inline MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___fontAsset), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___spriteAsset), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___material), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___fallbackMaterial), (void*)NULL);
		#endif
	}
};


IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_SetDefault_mDAFD4911B5A8BEE57351A37415ADF348F0A6B54C_gshared (TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA* __this, MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 ___0_item, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9_gshared (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555* __this, float ___0_item, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_SetDefault_m8D8C14A7EA75EBF60C7DDD5F4C8A81209E37751D_gshared (TextProcessingStack_1_t9C24840D494C4878BD8680855123926D6243C90D* __this, int32_t ___0_item, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_Clear_m857C80F9AFD9507FE4784DB5DE79109E16C8EAA3_gshared (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_gshared (TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63* __this, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___0_item, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_SetDefault_m11524F3861DE3F60DE2BAB47DF333011E27E5C2C_gshared (TextProcessingStack_1_tF3616757510D9631241E95596F10A4139420DA16* __this, HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 ___0_item, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_SetDefault_m2748811181AC3D93A43815FE1FAC09A7E569806E_gshared (TextProcessingStack_1_t5EA97AAC21CEE068194F77E59929440F85AD3991* __this, RuntimeObject* ___0_item, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_SetDefault_m2C394C84507BCA030509AC6708DCBC3F26E112B7_gshared (TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8* __this, int32_t ___0_item, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_Clear_m3684329CF566CB94C981B1EAB3F1F3C74D42D0CD_gshared (TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_Clear_m78D739A4A3B093B4CA2AD9D95578D2B4BB9909C3_gshared (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* Dictionary_2_get_Item_m1ABC559AFCB634174C216DFF864168F9D0611B91_gshared (Dictionary_2_tC8FA8E0C06C3A9584490723EC95DC65E5AFFF71A* __this, uint32_t ___0_key, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA_gshared (Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0* __this, uint32_t ___0_key, GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E* ___1_value, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Dictionary_2_TryGetValue_mF32BD44799A9D5626676B55AEE98449663C70D33_gshared (Dictionary_2_tC58BED428F0C45B2320DCA085F781540D1CC3A26* __this, uint32_t ___0_key, MarkToBaseAdjustmentRecord_t4BE0F5A88932146F70A2B521176BDA91A20D8607* ___1_value, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Dictionary_2_TryGetValue_mE41304D9F16D4065AEA94463AE53A68A4F4F6395_gshared (Dictionary_2_t3B281EAA0FCAF1D0DED857932C74644D3F02E6D0* __this, uint32_t ___0_key, MarkToMarkAdjustmentRecord_tD53618A3728435D5C904857DAC644EE27640807C* ___1_value, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t TextProcessingStack_1_get_Count_m019E4780B26C3C62C2C3E1BA49A5B47266DC65AC_gshared (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 TextProcessingStack_1_Pop_mBDDB87E018CFAAA932187B334ABB0237AB9D73B8_gshared (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_Push_mD1A26596D8C31C64D82246093BF86E91410DD8BC_gshared (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9* __this, WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 ___0_item, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextInfo_Resize_TisPageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909_m356AAB6CAA9298FF4C0E067A3ACE9A0AD2D78DE8_gshared (PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4** ___0_array, int32_t ___1_size, bool ___2_isBlockAllocated, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9_gshared (HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* __this, uint32_t ___0_item, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D_gshared (WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B** ___0_array, int32_t ___1_size, const RuntimeMethod* method) ;

IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Object_op_Equality_mB6120F782D83091EF56A198FCEBCF066DB4A9605 (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* ___0_x, Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* ___1_y, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Dictionary_2_t93CDF0F4011A5A3024EB73A492F9512E3046EACB* FontAsset_get_characterLookupTable_m7E76D6C706C5CEB04A9541C68AE6D9E5C75F0FFC (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Debug_LogWarning_m33EF1B897E0C7C6FF538989610BFAFFEF4628CA9 (RuntimeObject* ___0_message, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextInfo_Clear_m60412774208F9D920707448E71E89C99233D9128 (TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_ClearMesh_m68BA46B0365FC730BA5D2E6BDF2528BD370B2D83 (bool ___0_updateMesh, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___1_textInfo, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MaterialReference__ctor_m044AAA2C1079EB25A5534A6E0FA2314F033DB15A (MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26* __this, int32_t ___0_index, FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___1_fontAsset, SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___2_spriteAsset, Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___3_material, float ___4_padding, const RuntimeMethod* method) ;
inline void TextProcessingStack_1_SetDefault_mDAFD4911B5A8BEE57351A37415ADF348F0A6B54C (TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA* __this, MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 ___0_item, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA*, MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26, const RuntimeMethod*))TextProcessingStack_1_SetDefault_mDAFD4911B5A8BEE57351A37415ADF348F0A6B54C_gshared)(__this, ___0_item, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t FaceInfo_get_pointSize_m7EF7429A4725AB715931A220F6BB498C3D6BF7CB (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
inline void TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9 (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555* __this, float ___0_item, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555*, float, const RuntimeMethod*))TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9_gshared)(__this, ___0_item, method);
}
inline void TextProcessingStack_1_SetDefault_mDF71503A7E4F1891305CDCC7AE245CA66A713E79 (TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790* __this, int32_t ___0_item, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790*, int32_t, const RuntimeMethod*))TextProcessingStack_1_SetDefault_m8D8C14A7EA75EBF60C7DDD5F4C8A81209E37751D_gshared)(__this, ___0_item, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FontStyleStack_Clear_m989659363648B27540168E46F23E1EF9877C06E0 (FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7* __this, const RuntimeMethod* method) ;
inline void TextProcessingStack_1_SetDefault_m2DBB41C08A4CB7F71156ED5965850C2A0570F230 (TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F* __this, int32_t ___0_item, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F*, int32_t, const RuntimeMethod*))TextProcessingStack_1_SetDefault_m8D8C14A7EA75EBF60C7DDD5F4C8A81209E37751D_gshared)(__this, ___0_item, method);
}
inline void TextProcessingStack_1_Clear_m857C80F9AFD9507FE4784DB5DE79109E16C8EAA3 (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555* __this, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555*, const RuntimeMethod*))TextProcessingStack_1_Clear_m857C80F9AFD9507FE4784DB5DE79109E16C8EAA3_gshared)(__this, method);
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline (const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B Color32_op_Implicit_m79AF5E0BDE9CE041CAC4D89CBFA66E71C6DD1B70_inline (Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___0_c, const RuntimeMethod* method) ;
inline void TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54 (TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63* __this, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___0_item, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63*, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B, const RuntimeMethod*))TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_gshared)(__this, ___0_item, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4 Offset_get_zero_mF5B6D7C3F437FA438844A0B3EF405D805F1D1958 (const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void HighlightState__ctor_mDBB71C58F46D7BDC518026AC796D24F2D9B36D3F (HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740* __this, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___0_color, Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4 ___1_padding, const RuntimeMethod* method) ;
inline void TextProcessingStack_1_SetDefault_m11524F3861DE3F60DE2BAB47DF333011E27E5C2C (TextProcessingStack_1_tF3616757510D9631241E95596F10A4139420DA16* __this, HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 ___0_item, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_tF3616757510D9631241E95596F10A4139420DA16*, HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740, const RuntimeMethod*))TextProcessingStack_1_SetDefault_m11524F3861DE3F60DE2BAB47DF333011E27E5C2C_gshared)(__this, ___0_item, method);
}
inline void TextProcessingStack_1_SetDefault_mDD0BF36ABFBF0DBA2D289C08F9862374CE18A0F9 (TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E* __this, TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70* ___0_item, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E*, TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70*, const RuntimeMethod*))TextProcessingStack_1_SetDefault_m2748811181AC3D93A43815FE1FAC09A7E569806E_gshared)(__this, ___0_item, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint8_t FontAsset_get_italicStyleSlant_m69E70060C6E7940B4ACE61F2B7CB8965F86DA96B (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
inline void TextProcessingStack_1_SetDefault_m2C394C84507BCA030509AC6708DCBC3F26E112B7 (TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8* __this, int32_t ___0_item, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8*, int32_t, const RuntimeMethod*))TextProcessingStack_1_SetDefault_m2C394C84507BCA030509AC6708DCBC3F26E112B7_gshared)(__this, ___0_item, method);
}
inline void TextProcessingStack_1_Clear_m3684329CF566CB94C981B1EAB3F1F3C74D42D0CD (TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8* __this, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8*, const RuntimeMethod*))TextProcessingStack_1_Clear_m3684329CF566CB94C981B1EAB3F1F3C74D42D0CD_gshared)(__this, method);
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_get_one_mC9B289F1E15C42C597180C9FE6FB492495B51D02_inline (const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 Quaternion_get_identity_m7E701AE095ED10FD5EA0B50ABCFDE2EEFF2173A5_inline (const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9 (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_lineHeight_m528B4A822181FCECF3D4FF1045DF288E5872AB9D (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_ascentLine_m193755D649428EC24A7E433A1728F11DA7547ABD (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_descentLine_m811A243C9B328B0C546BF9927A010A05DF172BD3 (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Mathf_Clamp_m4DC36EEFDBE5F07C16249DA568023C5ECCFF0E7B_inline (int32_t ___0_value, int32_t ___1_min, int32_t ___2_max, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextInfo_ClearPageInfo_m57DE207346C5245799E50F8A57B56B65665B7430 (TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextInfo_ClearLineInfo_m986C886D34A324C8C4D30F9D8EF24AC242A10AD7 (TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void CharacterSubstitution__ctor_mBB5C3EA59D985711FE3DF1F266D648201E18CE29 (CharacterSubstitution_t9F6215FBA3E8AD8DDF6F35A51CEC7CB7E9A44F83* __this, int32_t ___0_index, uint32_t ___1_unicode, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* ___0_state, int32_t ___1_index, int32_t ___2_count, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___3_textInfo, const RuntimeMethod* method) ;
inline void TextProcessingStack_1_Clear_m78D739A4A3B093B4CA2AD9D95578D2B4BB9909C3 (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9* __this, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9*, const RuntimeMethod*))TextProcessingStack_1_Clear_m78D739A4A3B093B4CA2AD9D95578D2B4BB9909C3_gshared)(__this, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* UInt32_ToString_mB6FA6D2459C82ADCF285C55363491D9669A80154 (uint32_t* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* Int32_ToString_m030E01C24E294D6762FB0B6F37CB541581F55CA5 (int32_t* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Concat_m093934F71A9B351911EE46311674ED463B180006 (String_t* ___0_str0, String_t* ___1_str1, String_t* ___2_str2, String_t* ___3_str3, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Debug_LogError_mB00B2B4468EF3CAF041B038D840820FB84C924B2 (RuntimeObject* ___0_message, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TextGenerator_ValidateHtmlTag_mF8187EB1D0CB901861EDFC36151409F8FF6AB287 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, TextProcessingElementU5BU5D_t24A1E4C8745577D794FE856B4236875595E7FD22* ___0_chars, int32_t ___1_startIndex, int32_t* ___2_endIndex, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___3_generationSettings, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___4_textInfo, const RuntimeMethod* method) ;
inline Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* Dictionary_2_get_Item_mFA05B9BB2D2D3E43B23F6C859A051759E7C1C75D (Dictionary_2_t93CDF0F4011A5A3024EB73A492F9512E3046EACB* __this, uint32_t ___0_key, const RuntimeMethod* method)
{
	return ((  Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* (*) (Dictionary_2_t93CDF0F4011A5A3024EB73A492F9512E3046EACB*, uint32_t, const RuntimeMethod*))Dictionary_2_get_Item_m1ABC559AFCB634174C216DFF864168F9D0611B91_gshared)(__this, ___0_key, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsLower_m9DDB41367F97CFFE6C46A3B5EDE7D11180B5F1AE (Il2CppChar ___0_c, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Il2CppChar Char_ToUpper_m7DB51DD07EE52F4CA897807281880930F5CBD2D2 (Il2CppChar ___0_c, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsUpper_mF150C44B70F522A14B2A8DF71DE0ADE52F9A3392 (Il2CppChar ___0_c, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Il2CppChar Char_ToLower_m238489988C62CB10C7C7CAAEF8F3B2D1C5B5E056 (Il2CppChar ___0_c, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR TextAsset_tB28F1843A877CCA74B89DC4F63EA532618B049B8* TextElement_get_textAsset_m52383A3758AABF5BEA013155765BD1141479685A (TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t TextElement_get_glyphIndex_m43F82F2F998D640DEDBE6860EBE7B171DDF4FE56 (TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Color_tD001788D726C3A7F1379BEED0260B9591F440C1F Color_get_white_m068F5AF879B0FCA584E3693F762EA41BB65532C6_inline (const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Glyph_get_scale_m3ED738CBB032247526DB38161E180759B2D06F29 (Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_baseline_m934B597D3E0080FEF98CBDD091C457B497179C3A (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA (Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_height_mE0872B23CE1A20BF78DEACDBD53BAF789D84AD5C (GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924 (Il2CppChar ___0_c, const RuntimeMethod* method) ;
inline bool Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA (Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0* __this, uint32_t ___0_key, GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E* ___1_value, const RuntimeMethod* method)
{
	return ((  bool (*) (Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0*, uint32_t, GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E*, const RuntimeMethod*))Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA_gshared)(__this, ___0_key, ___1_value, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 GlyphPairAdjustmentRecord_get_firstAdjustmentRecord_m867469548F17B298F893B78EE2F93D34E4A6C39C (GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E GlyphAdjustmentRecord_get_glyphValueRecord_m83866DCE07A22F903D4BA417476E64114625BDD7 (GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t GlyphPairAdjustmentRecord_get_featureLookupFlags_m08DA76766FDE949068B881DBEA29955C9C43E8A9 (GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 GlyphPairAdjustmentRecord_get_secondAdjustmentRecord_mFDFECB1F7A38E22BD2388FFE9C71E732F6B44D91 (GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E GlyphValueRecord_op_Addition_mF26165B4CE61A5409AEFF24B0D1727804E13602B (GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E ___0_a, GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E ___1_b, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphValueRecord_get_xAdvance_m6C392027FA91E0705C1585C5EF40D984AAA0013E (GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TextGeneratorUtilities_IsBaseGlyph_mEE0E7D6C3FB32204C2299FBA2B9F7C51E06F80FE (uint32_t ___0_c, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2 (TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t Glyph_get_index_mCFBBCF85E7F3434B7A595EEE3411EFFB78E5675B (Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR FontFeatureTable_t992E0493CD7E9D7834DF204E0198237F0D25B3B7* FontAsset_get_fontFeatureTable_m7C4EB9A655B237CE02FAF7B8B16C2F2863FE5070 (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
inline bool Dictionary_2_TryGetValue_mF32BD44799A9D5626676B55AEE98449663C70D33 (Dictionary_2_tC58BED428F0C45B2320DCA085F781540D1CC3A26* __this, uint32_t ___0_key, MarkToBaseAdjustmentRecord_t4BE0F5A88932146F70A2B521176BDA91A20D8607* ___1_value, const RuntimeMethod* method)
{
	return ((  bool (*) (Dictionary_2_tC58BED428F0C45B2320DCA085F781540D1CC3A26*, uint32_t, MarkToBaseAdjustmentRecord_t4BE0F5A88932146F70A2B521176BDA91A20D8607*, const RuntimeMethod*))Dictionary_2_TryGetValue_mF32BD44799A9D5626676B55AEE98449663C70D33_gshared)(__this, ___0_key, ___1_value, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphAnchorPoint_t581FDCAD5A1D0F3B129968FAEF20C113AAB0BC08 MarkToBaseAdjustmentRecord_get_baseGlyphAnchorPoint_mCBF57932B7A89C532B0EF750DFD81F8FE389EE08 (MarkToBaseAdjustmentRecord_t4BE0F5A88932146F70A2B521176BDA91A20D8607* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphAnchorPoint_get_xCoordinate_mCD33464763911ECB78DEB1965970A916FA27DD1C (GlyphAnchorPoint_t581FDCAD5A1D0F3B129968FAEF20C113AAB0BC08* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR MarkPositionAdjustment_t2523798D56F14A93A080D9D1298498325A51F436 MarkToBaseAdjustmentRecord_get_markPositionAdjustment_m570715D1D0F84361A90564D4A958394453E1F9AB (MarkToBaseAdjustmentRecord_t4BE0F5A88932146F70A2B521176BDA91A20D8607* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float MarkPositionAdjustment_get_xPositionAdjustment_m5ACBB4C515357320C12597CAE5E4D409BA298765 (MarkPositionAdjustment_t2523798D56F14A93A080D9D1298498325A51F436* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GlyphValueRecord_set_xPlacement_m79F92029922BDE50ED63A6A03EBE478869F1CCFC (GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E* __this, float ___0_value, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphAnchorPoint_get_yCoordinate_m2683C19C6A3D750E4D6C536307313E55589909D6 (GlyphAnchorPoint_t581FDCAD5A1D0F3B129968FAEF20C113AAB0BC08* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float MarkPositionAdjustment_get_yPositionAdjustment_m1F5F7DBBFEB0B52CCC772F68664D06B11D6A9F2C (MarkPositionAdjustment_t2523798D56F14A93A080D9D1298498325A51F436* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GlyphValueRecord_set_yPlacement_m04DA300FAB827A708CB291DA3B2EA3128279CA2B (GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E* __this, float ___0_value, const RuntimeMethod* method) ;
inline bool Dictionary_2_TryGetValue_mE41304D9F16D4065AEA94463AE53A68A4F4F6395 (Dictionary_2_t3B281EAA0FCAF1D0DED857932C74644D3F02E6D0* __this, uint32_t ___0_key, MarkToMarkAdjustmentRecord_tD53618A3728435D5C904857DAC644EE27640807C* ___1_value, const RuntimeMethod* method)
{
	return ((  bool (*) (Dictionary_2_t3B281EAA0FCAF1D0DED857932C74644D3F02E6D0*, uint32_t, MarkToMarkAdjustmentRecord_tD53618A3728435D5C904857DAC644EE27640807C*, const RuntimeMethod*))Dictionary_2_TryGetValue_mE41304D9F16D4065AEA94463AE53A68A4F4F6395_gshared)(__this, ___0_key, ___1_value, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphAnchorPoint_t581FDCAD5A1D0F3B129968FAEF20C113AAB0BC08 MarkToMarkAdjustmentRecord_get_baseMarkGlyphAnchorPoint_mB87ADA10491B42650BAD4DB7330771061827ACAB (MarkToMarkAdjustmentRecord_tD53618A3728435D5C904857DAC644EE27640807C* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR MarkPositionAdjustment_t2523798D56F14A93A080D9D1298498325A51F436 MarkToMarkAdjustmentRecord_get_combiningMarkPositionAdjustment_mC109ECEDB4AD314A25C0EB1F6F6151AE611DE15C (MarkToMarkAdjustmentRecord_tD53618A3728435D5C904857DAC644EE27640807C* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphValueRecord_get_yPlacement_mB6303F8800305F6F96ECCD0CD9AA70A1A30A15DA (GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_horizontalAdvance_m110E66C340A19E672FB1C26DFB875AB6900AFFF1 (GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_width_m0F9F391E3A98984167E8001D4101BE1CE9354D13 (GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_horizontalBearingX_m9C39B5E6D27FF34B706649AE47EE9390B5D76D6F (GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Object_op_Inequality_mD0BE578448EAA61948F25C32F8DD55AB1F778602 (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* ___0_x, Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* ___1_y, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Material_HasProperty_m52E2D3BC3049B8B228149E023CD73C34B05A5222 (Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* __this, int32_t ___0_nameID, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Material_GetFloat_m52462F4AEDE20758BFB592B11DE83A79D2774932 (Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* __this, int32_t ___0_nameID, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FontAsset_get_boldStyleWeight_m804ACC85DD80DC72DB4BCC83C3FB866411F8EFCA (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FontAsset_get_boldStyleSpacing_mB8CF4F4880B110E41D566648FF1D995010CF1FF0 (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphValueRecord_get_xPlacement_m5E2B8B05A5DF57B2DC4B3795E71330CDDE1761C8 (GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_horizontalBearingY_mD316BDD38A32258256994D6A2BCF0FC051D9B223 (GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_capLine_m0D95B5D5CEC5CFB12091F5EB5965DE6E38588C88 (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* __this, float ___0_x, float ___1_y, float ___2_z, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_b, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Quaternion_op_Inequality_m4EC1EF263D0E42432A301F85CB52028D2973F5DA_inline (Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___0_lhs, Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___1_rhs, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 Matrix4x4_Rotate_m015442530DFF5651458BBFDFB3CBC9180FC09D9E (Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___0_q, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, float ___1_d, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_b, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Matrix4x4_MultiplyPoint3x4_mACCBD70AFA82C63DA88555780B7B6B01281AB814 (Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6* __this, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_point, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline (float ___0_a, float ___1_b, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline (float ___0_a, float ___1_b, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* ___0_state, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___1_textInfo, const RuntimeMethod* method) ;
inline int32_t TextProcessingStack_1_get_Count_m019E4780B26C3C62C2C3E1BA49A5B47266DC65AC (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9* __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9*, const RuntimeMethod*))TextProcessingStack_1_get_Count_m019E4780B26C3C62C2C3E1BA49A5B47266DC65AC_gshared)(__this, method);
}
inline WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 TextProcessingStack_1_Pop_mBDDB87E018CFAAA932187B334ABB0237AB9D73B8 (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9* __this, const RuntimeMethod* method)
{
	return ((  WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 (*) (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9*, const RuntimeMethod*))TextProcessingStack_1_Pop_mBDDB87E018CFAAA932187B334ABB0237AB9D73B8_gshared)(__this, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_InsertNewLine_m00109EA00343212A7FD05D49E7DBF81DBFE4B5E4 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, int32_t ___0_i, float ___1_baseScale, float ___2_currentElementScale, float ___3_currentEmScale, float ___4_boldSpacingAdjustment, float ___5_characterSpacingAdjustment, float ___6_width, float ___7_lineGap, bool* ___8_isMaxVisibleDescenderSet, float* ___9_maxVisibleDescender, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___10_generationSettings, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___11_textInfo, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_SaveGlyphVertexInfo_m0CD6E1D45488FFC6675294AC64F40AC23C986A09 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, float ___0_padding, float ___1_stylePadding, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___2_vertexColor, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___3_generationSettings, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___4_textInfo, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_SaveSpriteVertexInfo_m4B47901F01927E7CC4E486A1C4354AFBF4D138A5 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___0_vertexColor, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___1_generationSettings, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___2_textInfo, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsSeparator_m8DBA05CCFA10131140E40057E6553F7AC7397BF9 (Il2CppChar ___0_c, const RuntimeMethod* method) ;
inline void TextProcessingStack_1_Push_mD1A26596D8C31C64D82246093BF86E91410DD8BC (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9* __this, WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 ___0_item, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9*, WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123, const RuntimeMethod*))TextProcessingStack_1_Push_mD1A26596D8C31C64D82246093BF86E91410DD8BC_gshared)(__this, ___0_item, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_tabWidth_mC6D9F42C40EDD767DE22050E4FBE3878AC96B161 (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint8_t FontAsset_get_tabMultiple_m9C0422A00BFCF82091F14F4E303E2717247350AE (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FontAsset_get_regularStyleSpacing_mB7EEEA236312F5AC31FD3B787808279206F521B1 (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
inline void TextInfo_Resize_TisPageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909_m356AAB6CAA9298FF4C0E067A3ACE9A0AD2D78DE8 (PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4** ___0_array, int32_t ___1_size, bool ___2_isBlockAllocated, const RuntimeMethod* method)
{
	((  void (*) (PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4**, int32_t, bool, const RuntimeMethod*))TextInfo_Resize_TisPageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909_m356AAB6CAA9298FF4C0E067A3ACE9A0AD2D78DE8_gshared)(___0_array, ___1_size, ___2_isBlockAllocated, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGeneratorUtilities_AdjustLineOffset_m811C187EA3E41781116F0C7A679B05BB27874123 (int32_t ___0_startIndex, int32_t ___1_endIndex, float ___2_offset, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___3_textInfo, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* __this, float ___0_x, float ___1_y, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGeneratorUtilities_ResizeLineExtents_m2EA9BE32A38D5E075DEF8EDA9EC01766E45C0F85 (int32_t ___0_size, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___1_textInfo, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TextGeneratorUtilities_IsHangul_m5A23BA8E0EBE57243E2E96A248B3F6570A87A966 (uint32_t ___0_c, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* TextSettings_get_lineBreakingRules_m96E2C32D4F08309D904B0BCD83CEBE8CD6716A04 (TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool UnicodeLineBreakingRules_get_useModernHangulLineBreakingRules_mD86D283CE7BA23A0174B9227A7BD915D3D9FD464_inline (UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TextGeneratorUtilities_IsCJK_m2F2718B1203271CC2C501C5054590299FBCA5B7D (uint32_t ___0_c, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* UnicodeLineBreakingRules_get_leadingCharactersLookup_m1DAC015D7E37112EAE0437E6472AEA0719DFF3DC (UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* __this, const RuntimeMethod* method) ;
inline bool HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9 (HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* __this, uint32_t ___0_item, const RuntimeMethod* method)
{
	return ((  bool (*) (HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A*, uint32_t, const RuntimeMethod*))HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9_gshared)(__this, ___0_item, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* UnicodeLineBreakingRules_get_followingCharactersLookup_m5510A21873DC5DA66F4A2DFA4C26A5EFAD494D8B (UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* Single_ToString_mE282EDA9CA4F7DF88432D807732837A629D04972 (float* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Debug_Log_m87A9A3C761FF5C43ED8A53B16190A53D08F818BB (RuntimeObject* ___0_message, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MeshInfo_Clear_m06992FEB7AC9B2AE1728BEDFC8D8A39DE1AAD475 (MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F* __this, bool ___0_uploadChanges, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Color32__ctor_mC9C6B443F0C7CA3F8B174158B2AF6F05E18EAC4E_inline (Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B* __this, uint8_t ___0_r, uint8_t ___1_g, uint8_t ___2_b, uint8_t ___3_a, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsControl_m133C10360BE82B7580E4D3ECE3C881A6C82B3F7F (Il2CppChar ___0_c, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t QualitySettings_get_activeColorSpace_m4F47784E7B0FE0A5497C8BAB9CA86BD576FB92F9 (const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGeneratorUtilities_FillCharacterVertexBuffers_mE0CCB8DA0D27F37DCFC4E47E89697D8823A8FCE8 (int32_t ___0_i, bool ___1_convertToLinearSpace, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___2_generationSettings, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___3_textInfo, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGeneratorUtilities_FillSpriteVertexBuffers_mD1AECFE4D4356A6925BF056E15CF84118313412B (int32_t ___0_i, bool ___1_convertToLinearSpace, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___2_generationSettings, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___3_textInfo, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsLetterOrDigit_m14049A362108679FD23E424FD9C5C42057359B72 (Il2CppChar ___0_c, const RuntimeMethod* method) ;
inline void TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D (WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B** ___0_array, int32_t ___1_size, const RuntimeMethod* method)
{
	((  void (*) (WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B**, int32_t, const RuntimeMethod*))TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D_gshared)(___0_array, ___1_size, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsPunctuation_m619E42D942E22C9BA1DDB8E704BECA546C376473 (Il2CppChar ___0_c, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_underlineOffset_mB1CBB29ECFFE69047F35E654E7F90755F95DD251 (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_DrawUnderlineMesh_m307EA8034106ACD13F89CC7E78C5DE08CCCCEFAE (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_start, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_end, float ___2_startScale, float ___3_endScale, float ___4_maxScale, float ___5_sdfScale, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___6_underlineColor, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___7_generationSettings, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___8_textInfo, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ColorUtilities_CompareColors_m0F0F140129DEE889FB8AE3B2921C495E94B5E875 (Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___0_a, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___1_b, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_strikethroughOffset_m7997E4A1512FE358331B3A6543C62C92A0AA5CA5 (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TextGeneratorUtilities_Approximately_m696ABB909732F536F1FF83EA8CE34CF53266794D (float ___0_a, float ___1_b, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Object_GetInstanceID_m554FF4073C9465F3835574CC084E68AAEEC6CC6A (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___0_v, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool HighlightState_op_Inequality_m2DFBCB59E593F72191BFBBD7424A8C6151E68272 (HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 ___0_lhs, HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 ___1_rhs, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Offset_get_right_m45AEBB7DE1D42A9A7234FB0DCE4E92420060D3FB (Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_DrawTextHighlight_m4046F4CC59C6DD8FE5B0BD97DB8BFE015B829389 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_start, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_end, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___2_highlightColor, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___3_generationSettings, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___4_textInfo, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Offset_get_bottom_m3BC4AB202A1B7D7D5A65EF746CDA1A73B5D8866C (Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Offset_get_top_mD62FECE7914DF9723A872AAD91BDB07295C6E0F4 (Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Offset_get_left_m83657AF289FA1DB8B5D4007B8310573B76AA6D82 (Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MeshInfo_ClearUnusedVertices_m7B6003EF4CA72C0ABBA4D25DEA8B0BF3934B2830 (MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MeshInfo_SortGeometry_m92046C53AA6AE75EE3627CE73846296AB3E99DD1 (MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F* __this, int32_t ___0_order, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Mathf_Clamp01_mA7E048DBDA832D399A581BE4D6DED9FA44CE0F14_inline (float ___0_value, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Color__ctor_m3786F0D6E510D9CFA544523A955870BD2A514C8C_inline (Color_tD001788D726C3A7F1379BEED0260B9591F440C1F* __this, float ___0_r, float ___1_g, float ___2_b, float ___3_a, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Quaternion_op_Equality_mE6F6B56FCED8478552BE02BBAF18C70B969217F9_inline (Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___0_lhs, Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___1_rhs, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Quaternion_Dot_mF9D3BE33940A47979DADA7E81650AEB356D5D12B_inline (Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___0_a, Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___1_b, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Quaternion_IsEqualUsingDot_m9C672201C918C2D1E739F559DBE4406F95997CBD_inline (float ___0_dot, const RuntimeMethod* method) ;
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___0_generationSettings, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___1_textInfo, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Debug_t8394C7EEAECA3689C2C9B9DE9C7166D73596276F_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Dictionary_2_TryGetValue_mE41304D9F16D4065AEA94463AE53A68A4F4F6395_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Dictionary_2_TryGetValue_mF32BD44799A9D5626676B55AEE98449663C70D33_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Dictionary_2_get_Item_mFA05B9BB2D2D3E43B23F6C859A051759E7C1C75D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextInfo_Resize_TisPageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909_m356AAB6CAA9298FF4C0E067A3ACE9A0AD2D78DE8_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_Clear_m3684329CF566CB94C981B1EAB3F1F3C74D42D0CD_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_Clear_m78D739A4A3B093B4CA2AD9D95578D2B4BB9909C3_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_Clear_m857C80F9AFD9507FE4784DB5DE79109E16C8EAA3_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_Pop_mBDDB87E018CFAAA932187B334ABB0237AB9D73B8_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_Push_mD1A26596D8C31C64D82246093BF86E91410DD8BC_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_SetDefault_m11524F3861DE3F60DE2BAB47DF333011E27E5C2C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_SetDefault_m2C394C84507BCA030509AC6708DCBC3F26E112B7_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_SetDefault_m2DBB41C08A4CB7F71156ED5965850C2A0570F230_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_SetDefault_mDAFD4911B5A8BEE57351A37415ADF348F0A6B54C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_SetDefault_mDD0BF36ABFBF0DBA2D289C08F9862374CE18A0F9_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_SetDefault_mDF71503A7E4F1891305CDCC7AE245CA66A713E79_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_get_Count_m019E4780B26C3C62C2C3E1BA49A5B47266DC65AC_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral41BB69D2BDF9A4541A716BE07E74D1ED0DEADD05);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral4D24EAAEA041EAFA17400A5C3BEA644DA7F8067F);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral6EFD426731423F3C40A7DA0D6CAECBFB816A8F61);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral94B946B03625197025E6D70053ADE0256BC25DD1);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralAFB91D1DF3A99213A5F62F37EB0B31E6121411C4);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralFE37C361B118D899F298E7DBBEDF126B8808060D);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	float V_1 = 0.0f;
	float V_2 = 0.0f;
	float V_3 = 0.0f;
	float V_4 = 0.0f;
	uint32_t V_5 = 0;
	float V_6 = 0.0f;
	bool V_7 = false;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_8;
	memset((&V_8), 0, sizeof(V_8));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_9;
	memset((&V_9), 0, sizeof(V_9));
	bool V_10 = false;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_11;
	memset((&V_11), 0, sizeof(V_11));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_12;
	memset((&V_12), 0, sizeof(V_12));
	bool V_13 = false;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_14;
	memset((&V_14), 0, sizeof(V_14));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_15;
	memset((&V_15), 0, sizeof(V_15));
	float V_16 = 0.0f;
	bool V_17 = false;
	int32_t V_18 = 0;
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 V_19;
	memset((&V_19), 0, sizeof(V_19));
	float V_20 = 0.0f;
	float V_21 = 0.0f;
	float V_22 = 0.0f;
	float V_23 = 0.0f;
	bool V_24 = false;
	bool V_25 = false;
	bool V_26 = false;
	int32_t V_27 = 0;
	CharacterSubstitution_t9F6215FBA3E8AD8DDF6F35A51CEC7CB7E9A44F83 V_28;
	memset((&V_28), 0, sizeof(V_28));
	bool V_29 = false;
	int32_t V_30 = 0;
	TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64* V_31 = NULL;
	int32_t V_32 = 0;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_33;
	memset((&V_33), 0, sizeof(V_33));
	Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* V_34 = NULL;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_35;
	memset((&V_35), 0, sizeof(V_35));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_36;
	memset((&V_36), 0, sizeof(V_36));
	int32_t V_37 = 0;
	int32_t V_38 = 0;
	int32_t V_39 = 0;
	bool V_40 = false;
	bool V_41 = false;
	int32_t V_42 = 0;
	int32_t V_43 = 0;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B V_44;
	memset((&V_44), 0, sizeof(V_44));
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B V_45;
	memset((&V_45), 0, sizeof(V_45));
	HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 V_46;
	memset((&V_46), 0, sizeof(V_46));
	float V_47 = 0.0f;
	float V_48 = 0.0f;
	float V_49 = 0.0f;
	float V_50 = 0.0f;
	float V_51 = 0.0f;
	float V_52 = 0.0f;
	int32_t V_53 = 0;
	float V_54 = 0.0f;
	float V_55 = 0.0f;
	float V_56 = 0.0f;
	TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* V_57 = NULL;
	bool V_58 = false;
	bool V_59 = false;
	bool V_60 = false;
	FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 V_61;
	memset((&V_61), 0, sizeof(V_61));
	int32_t V_62 = 0;
	int32_t V_63 = 0;
	bool V_64 = false;
	bool V_65 = false;
	float V_66 = 0.0f;
	float V_67 = 0.0f;
	float V_68 = 0.0f;
	float V_69 = 0.0f;
	float V_70 = 0.0f;
	Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* V_71 = NULL;
	GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A V_72;
	memset((&V_72), 0, sizeof(V_72));
	bool V_73 = false;
	GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E V_74;
	memset((&V_74), 0, sizeof(V_74));
	float V_75 = 0.0f;
	bool V_76 = false;
	float V_77 = 0.0f;
	float V_78 = 0.0f;
	float V_79 = 0.0f;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_80;
	memset((&V_80), 0, sizeof(V_80));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_81;
	memset((&V_81), 0, sizeof(V_81));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_82;
	memset((&V_82), 0, sizeof(V_82));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_83;
	memset((&V_83), 0, sizeof(V_83));
	float V_84 = 0.0f;
	float V_85 = 0.0f;
	float V_86 = 0.0f;
	float V_87 = 0.0f;
	bool V_88 = false;
	bool V_89 = false;
	bool V_90 = false;
	bool V_91 = false;
	bool V_92 = false;
	int32_t V_93 = 0;
	bool V_94 = false;
	bool V_95 = false;
	bool V_96 = false;
	uint32_t V_97 = 0;
	uint32_t V_98 = 0;
	bool V_99 = false;
	bool V_100 = false;
	bool V_101 = false;
	bool V_102 = false;
	bool V_103 = false;
	bool V_104 = false;
	bool V_105 = false;
	bool V_106 = false;
	bool V_107 = false;
	SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* V_108 = NULL;
	float V_109 = 0.0f;
	bool V_110 = false;
	bool V_111 = false;
	bool V_112 = false;
	float V_113 = 0.0f;
	float V_114 = 0.0f;
	float V_115 = 0.0f;
	GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A V_116;
	memset((&V_116), 0, sizeof(V_116));
	bool V_117 = false;
	float V_118 = 0.0f;
	bool V_119 = false;
	bool V_120 = false;
	bool V_121 = false;
	bool V_122 = false;
	bool V_123 = false;
	GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E V_124;
	memset((&V_124), 0, sizeof(V_124));
	uint32_t V_125 = 0;
	bool V_126 = false;
	uint32_t V_127 = 0;
	uint32_t V_128 = 0;
	bool V_129 = false;
	GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 V_130;
	memset((&V_130), 0, sizeof(V_130));
	bool V_131 = false;
	uint32_t V_132 = 0;
	uint32_t V_133 = 0;
	bool V_134 = false;
	bool V_135 = false;
	bool V_136 = false;
	bool V_137 = false;
	Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* V_138 = NULL;
	uint32_t V_139 = 0;
	uint32_t V_140 = 0;
	uint32_t V_141 = 0;
	MarkToBaseAdjustmentRecord_t4BE0F5A88932146F70A2B521176BDA91A20D8607 V_142;
	memset((&V_142), 0, sizeof(V_142));
	bool V_143 = false;
	float V_144 = 0.0f;
	GlyphAnchorPoint_t581FDCAD5A1D0F3B129968FAEF20C113AAB0BC08 V_145;
	memset((&V_145), 0, sizeof(V_145));
	MarkPositionAdjustment_t2523798D56F14A93A080D9D1298498325A51F436 V_146;
	memset((&V_146), 0, sizeof(V_146));
	bool V_147 = false;
	int32_t V_148 = 0;
	Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* V_149 = NULL;
	uint32_t V_150 = 0;
	uint32_t V_151 = 0;
	uint32_t V_152 = 0;
	MarkToMarkAdjustmentRecord_tD53618A3728435D5C904857DAC644EE27640807C V_153;
	memset((&V_153), 0, sizeof(V_153));
	bool V_154 = false;
	float V_155 = 0.0f;
	float V_156 = 0.0f;
	float V_157 = 0.0f;
	int32_t V_158 = 0;
	bool V_159 = false;
	bool V_160 = false;
	Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* V_161 = NULL;
	uint32_t V_162 = 0;
	uint32_t V_163 = 0;
	uint32_t V_164 = 0;
	MarkToBaseAdjustmentRecord_t4BE0F5A88932146F70A2B521176BDA91A20D8607 V_165;
	memset((&V_165), 0, sizeof(V_165));
	bool V_166 = false;
	float V_167 = 0.0f;
	bool V_168 = false;
	bool V_169 = false;
	bool V_170 = false;
	bool V_171 = false;
	bool V_172 = false;
	float V_173 = 0.0f;
	bool V_174 = false;
	bool V_175 = false;
	float V_176 = 0.0f;
	bool V_177 = false;
	bool V_178 = false;
	float V_179 = 0.0f;
	float V_180 = 0.0f;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_181;
	memset((&V_181), 0, sizeof(V_181));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_182;
	memset((&V_182), 0, sizeof(V_182));
	bool V_183 = false;
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 V_184;
	memset((&V_184), 0, sizeof(V_184));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_185;
	memset((&V_185), 0, sizeof(V_185));
	bool V_186 = false;
	bool V_187 = false;
	bool V_188 = false;
	float V_189 = 0.0f;
	bool V_190 = false;
	bool V_191 = false;
	bool V_192 = false;
	bool V_193 = false;
	bool V_194 = false;
	float V_195 = 0.0f;
	float V_196 = 0.0f;
	float V_197 = 0.0f;
	float V_198 = 0.0f;
	int32_t V_199 = 0;
	bool V_200 = false;
	bool V_201 = false;
	bool V_202 = false;
	bool V_203 = false;
	bool V_204 = false;
	float V_205 = 0.0f;
	bool V_206 = false;
	float V_207 = 0.0f;
	int32_t V_208 = 0;
	int32_t V_209 = 0;
	bool V_210 = false;
	WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 V_211;
	memset((&V_211), 0, sizeof(V_211));
	bool V_212 = false;
	bool V_213 = false;
	bool V_214 = false;
	bool V_215 = false;
	bool V_216 = false;
	float V_217 = 0.0f;
	float V_218 = 0.0f;
	int32_t V_219 = 0;
	bool V_220 = false;
	float V_221 = 0.0f;
	bool V_222 = false;
	bool V_223 = false;
	bool V_224 = false;
	bool V_225 = false;
	bool V_226 = false;
	float V_227 = 0.0f;
	float V_228 = 0.0f;
	bool V_229 = false;
	bool V_230 = false;
	float V_231 = 0.0f;
	bool V_232 = false;
	bool V_233 = false;
	bool V_234 = false;
	bool V_235 = false;
	bool V_236 = false;
	bool V_237 = false;
	bool V_238 = false;
	float V_239 = 0.0f;
	bool V_240 = false;
	float V_241 = 0.0f;
	float V_242 = 0.0f;
	bool V_243 = false;
	bool V_244 = false;
	float V_245 = 0.0f;
	WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 V_246;
	memset((&V_246), 0, sizeof(V_246));
	int32_t V_247 = 0;
	int32_t V_248 = 0;
	bool V_249 = false;
	bool V_250 = false;
	bool V_251 = false;
	float V_252 = 0.0f;
	float V_253 = 0.0f;
	bool V_254 = false;
	bool V_255 = false;
	float V_256 = 0.0f;
	WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 V_257;
	memset((&V_257), 0, sizeof(V_257));
	int32_t V_258 = 0;
	int32_t V_259 = 0;
	bool V_260 = false;
	bool V_261 = false;
	int32_t* V_262 = NULL;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* V_263 = NULL;
	bool V_264 = false;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B V_265;
	memset((&V_265), 0, sizeof(V_265));
	bool V_266 = false;
	bool V_267 = false;
	bool V_268 = false;
	bool V_269 = false;
	bool V_270 = false;
	float V_271 = 0.0f;
	int32_t V_272 = 0;
	bool V_273 = false;
	bool V_274 = false;
	bool V_275 = false;
	bool V_276 = false;
	bool V_277 = false;
	float V_278 = 0.0f;
	float V_279 = 0.0f;
	float V_280 = 0.0f;
	float V_281 = 0.0f;
	float V_282 = 0.0f;
	float V_283 = 0.0f;
	float V_284 = 0.0f;
	bool V_285 = false;
	bool V_286 = false;
	bool V_287 = false;
	bool V_288 = false;
	bool V_289 = false;
	float V_290 = 0.0f;
	float V_291 = 0.0f;
	bool V_292 = false;
	bool V_293 = false;
	bool V_294 = false;
	bool V_295 = false;
	bool V_296 = false;
	bool V_297 = false;
	bool V_298 = false;
	bool V_299 = false;
	bool V_300 = false;
	bool V_301 = false;
	float V_302 = 0.0f;
	float V_303 = 0.0f;
	float V_304 = 0.0f;
	float V_305 = 0.0f;
	bool V_306 = false;
	bool V_307 = false;
	float* V_308 = NULL;
	bool V_309 = false;
	bool V_310 = false;
	bool V_311 = false;
	bool V_312 = false;
	bool V_313 = false;
	float V_314 = 0.0f;
	bool V_315 = false;
	bool V_316 = false;
	float V_317 = 0.0f;
	bool V_318 = false;
	bool V_319 = false;
	bool V_320 = false;
	bool V_321 = false;
	bool V_322 = false;
	bool V_323 = false;
	bool V_324 = false;
	bool V_325 = false;
	bool V_326 = false;
	bool V_327 = false;
	bool V_328 = false;
	bool V_329 = false;
	bool V_330 = false;
	bool V_331 = false;
	bool V_332 = false;
	bool V_333 = false;
	bool V_334 = false;
	float V_335 = 0.0f;
	bool V_336 = false;
	bool V_337 = false;
	bool V_338 = false;
	int32_t V_339 = 0;
	int32_t V_340 = 0;
	bool V_341 = false;
	bool V_342 = false;
	bool V_343 = false;
	int32_t V_344 = 0;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* V_345 = NULL;
	Il2CppChar V_346 = 0x0;
	bool V_347 = false;
	int32_t V_348 = 0;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 V_349;
	memset((&V_349), 0, sizeof(V_349));
	int32_t V_350 = 0;
	bool V_351 = false;
	bool V_352 = false;
	bool V_353 = false;
	float V_354 = 0.0f;
	bool V_355 = false;
	Il2CppChar V_356 = 0x0;
	bool V_357 = false;
	int32_t V_358 = 0;
	int32_t V_359 = 0;
	bool V_360 = false;
	bool V_361 = false;
	bool V_362 = false;
	bool V_363 = false;
	bool V_364 = false;
	bool V_365 = false;
	bool V_366 = false;
	float V_367 = 0.0f;
	int32_t V_368 = 0;
	int32_t V_369 = 0;
	float V_370 = 0.0f;
	bool V_371 = false;
	bool V_372 = false;
	bool V_373 = false;
	bool V_374 = false;
	bool V_375 = false;
	bool V_376 = false;
	bool V_377 = false;
	uint8_t V_378 = 0;
	bool V_379 = false;
	Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 V_380;
	memset((&V_380), 0, sizeof(V_380));
	float V_381 = 0.0f;
	uint8_t V_382 = 0;
	uint8_t V_383 = 0;
	float V_384 = 0.0f;
	int32_t V_385 = 0;
	int32_t V_386 = 0;
	bool V_387 = false;
	int32_t V_388 = 0;
	int32_t V_389 = 0;
	float V_390 = 0.0f;
	int32_t V_391 = 0;
	int32_t V_392 = 0;
	bool V_393 = false;
	bool V_394 = false;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* V_395 = NULL;
	bool V_396 = false;
	bool V_397 = false;
	bool V_398 = false;
	bool V_399 = false;
	bool V_400 = false;
	bool V_401 = false;
	bool V_402 = false;
	bool V_403 = false;
	bool V_404 = false;
	bool V_405 = false;
	int32_t V_406 = 0;
	int32_t V_407 = 0;
	bool V_408 = false;
	bool V_409 = false;
	bool V_410 = false;
	int32_t V_411 = 0;
	int32_t V_412 = 0;
	bool V_413 = false;
	bool V_414 = false;
	bool V_415 = false;
	int32_t V_416 = 0;
	bool V_417 = false;
	bool V_418 = false;
	bool V_419 = false;
	bool V_420 = false;
	bool V_421 = false;
	bool V_422 = false;
	bool V_423 = false;
	bool V_424 = false;
	int32_t V_425 = 0;
	bool V_426 = false;
	bool V_427 = false;
	bool V_428 = false;
	bool V_429 = false;
	bool V_430 = false;
	bool V_431 = false;
	bool V_432 = false;
	bool V_433 = false;
	bool V_434 = false;
	bool V_435 = false;
	bool V_436 = false;
	int32_t V_437 = 0;
	bool V_438 = false;
	int32_t V_439 = 0;
	bool V_440 = false;
	bool V_441 = false;
	bool V_442 = false;
	bool V_443 = false;
	bool V_444 = false;
	bool V_445 = false;
	int32_t V_446 = 0;
	bool V_447 = false;
	bool V_448 = false;
	bool V_449 = false;
	bool V_450 = false;
	TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 V_451;
	memset((&V_451), 0, sizeof(V_451));
	HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 V_452;
	memset((&V_452), 0, sizeof(V_452));
	bool V_453 = false;
	bool V_454 = false;
	bool V_455 = false;
	bool V_456 = false;
	bool V_457 = false;
	bool V_458 = false;
	bool V_459 = false;
	bool V_460 = false;
	bool V_461 = false;
	bool V_462 = false;
	bool V_463 = false;
	int32_t V_464 = 0;
	bool V_465 = false;
	bool V_466 = false;
	int32_t G_B3_0 = 0;
	int32_t G_B11_0 = 0;
	float G_B15_0 = 0.0f;
	float G_B14_0 = 0.0f;
	float G_B16_0 = 0.0f;
	float G_B16_1 = 0.0f;
	float G_B18_0 = 0.0f;
	float G_B17_0 = 0.0f;
	float G_B19_0 = 0.0f;
	float G_B19_1 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B21_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B20_0 = NULL;
	int32_t G_B22_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B22_1 = NULL;
	float G_B25_0 = 0.0f;
	float G_B28_0 = 0.0f;
	int32_t G_B31_0 = 0;
	int32_t G_B39_0 = 0;
	int32_t G_B60_0 = 0;
	float G_B84_0 = 0.0f;
	float G_B83_0 = 0.0f;
	float G_B85_0 = 0.0f;
	float G_B85_1 = 0.0f;
	float G_B88_0 = 0.0f;
	float G_B87_0 = 0.0f;
	float G_B89_0 = 0.0f;
	float G_B89_1 = 0.0f;
	float G_B92_0 = 0.0f;
	float G_B91_0 = 0.0f;
	float G_B93_0 = 0.0f;
	float G_B93_1 = 0.0f;
	int32_t G_B102_0 = 0;
	float G_B105_0 = 0.0f;
	float G_B104_0 = 0.0f;
	float G_B106_0 = 0.0f;
	float G_B106_1 = 0.0f;
	float G_B109_0 = 0.0f;
	float G_B108_0 = 0.0f;
	float G_B110_0 = 0.0f;
	float G_B110_1 = 0.0f;
	int32_t G_B114_0 = 0;
	int32_t G_B121_0 = 0;
	GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A G_B126_0;
	memset((&G_B126_0), 0, sizeof(G_B126_0));
	int32_t G_B129_0 = 0;
	float G_B135_0 = 0.0f;
	float G_B142_0 = 0.0f;
	int32_t G_B150_0 = 0;
	int32_t G_B154_0 = 0;
	int32_t G_B165_0 = 0;
	int32_t G_B169_0 = 0;
	int32_t G_B179_0 = 0;
	int32_t G_B188_0 = 0;
	int32_t G_B192_0 = 0;
	int32_t G_B202_0 = 0;
	int32_t G_B212_0 = 0;
	float G_B219_0 = 0.0f;
	float G_B222_0 = 0.0f;
	int32_t G_B225_0 = 0;
	int32_t G_B232_0 = 0;
	int32_t G_B238_0 = 0;
	int32_t G_B242_0 = 0;
	int32_t G_B249_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B252_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B251_0 = NULL;
	float G_B253_0 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B253_1 = NULL;
	int32_t G_B258_0 = 0;
	int32_t G_B271_0 = 0;
	float G_B277_0 = 0.0f;
	float G_B279_0 = 0.0f;
	float G_B278_0 = 0.0f;
	float G_B280_0 = 0.0f;
	float G_B280_1 = 0.0f;
	float G_B282_0 = 0.0f;
	float G_B282_1 = 0.0f;
	float G_B281_0 = 0.0f;
	float G_B281_1 = 0.0f;
	float G_B283_0 = 0.0f;
	float G_B283_1 = 0.0f;
	float G_B283_2 = 0.0f;
	float G_B285_0 = 0.0f;
	float G_B284_0 = 0.0f;
	float G_B286_0 = 0.0f;
	float G_B287_0 = 0.0f;
	float G_B287_1 = 0.0f;
	int32_t G_B295_0 = 0;
	int32_t G_B300_0 = 0;
	int32_t G_B316_0 = 0;
	float G_B325_0 = 0.0f;
	float G_B325_1 = 0.0f;
	float G_B324_0 = 0.0f;
	float G_B324_1 = 0.0f;
	float G_B326_0 = 0.0f;
	float G_B326_1 = 0.0f;
	float G_B326_2 = 0.0f;
	int32_t G_B328_0 = 0;
	int32_t G_B333_0 = 0;
	float G_B339_0 = 0.0f;
	int32_t G_B344_0 = 0;
	int32_t G_B348_0 = 0;
	int32_t G_B357_0 = 0;
	float G_B362_0 = 0.0f;
	float G_B362_1 = 0.0f;
	float G_B361_0 = 0.0f;
	float G_B361_1 = 0.0f;
	float G_B363_0 = 0.0f;
	float G_B363_1 = 0.0f;
	float G_B363_2 = 0.0f;
	int32_t G_B367_0 = 0;
	int32_t G_B373_0 = 0;
	int32_t G_B386_0 = 0;
	int32_t G_B391_0 = 0;
	float G_B396_0 = 0.0f;
	float G_B396_1 = 0.0f;
	float G_B395_0 = 0.0f;
	float G_B395_1 = 0.0f;
	float G_B397_0 = 0.0f;
	float G_B397_1 = 0.0f;
	float G_B397_2 = 0.0f;
	int32_t G_B401_0 = 0;
	int32_t G_B419_0 = 0;
	float G_B425_0 = 0.0f;
	float G_B425_1 = 0.0f;
	float G_B424_0 = 0.0f;
	float G_B424_1 = 0.0f;
	float G_B426_0 = 0.0f;
	float G_B426_1 = 0.0f;
	float G_B426_2 = 0.0f;
	int32_t G_B459_0 = 0;
	int32_t G_B461_0 = 0;
	float G_B464_0 = 0.0f;
	float G_B463_0 = 0.0f;
	float G_B465_0 = 0.0f;
	float G_B466_0 = 0.0f;
	float G_B466_1 = 0.0f;
	int32_t G_B482_0 = 0;
	int32_t G_B491_0 = 0;
	int32_t G_B493_0 = 0;
	float G_B496_0 = 0.0f;
	float G_B495_0 = 0.0f;
	float G_B497_0 = 0.0f;
	float G_B497_1 = 0.0f;
	int32_t G_B500_0 = 0;
	float G_B503_0 = 0.0f;
	float G_B502_0 = 0.0f;
	float G_B504_0 = 0.0f;
	float G_B504_1 = 0.0f;
	float G_B507_0 = 0.0f;
	float G_B506_0 = 0.0f;
	float G_B508_0 = 0.0f;
	float G_B509_0 = 0.0f;
	float G_B509_1 = 0.0f;
	float G_B511_0 = 0.0f;
	float G_B510_0 = 0.0f;
	float G_B512_0 = 0.0f;
	float G_B512_1 = 0.0f;
	float G_B515_0 = 0.0f;
	float G_B517_0 = 0.0f;
	float G_B517_1 = 0.0f;
	float G_B516_0 = 0.0f;
	float G_B516_1 = 0.0f;
	float G_B518_0 = 0.0f;
	float G_B518_1 = 0.0f;
	float G_B518_2 = 0.0f;
	int32_t G_B527_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B533_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B532_0 = NULL;
	float G_B534_0 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B534_1 = NULL;
	int32_t G_B539_0 = 0;
	int32_t G_B546_0 = 0;
	int32_t G_B552_0 = 0;
	int32_t G_B565_0 = 0;
	PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909* G_B570_0 = NULL;
	PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909* G_B569_0 = NULL;
	float G_B571_0 = 0.0f;
	PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909* G_B571_1 = NULL;
	int32_t G_B582_0 = 0;
	int32_t G_B588_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B594_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B593_0 = NULL;
	float G_B595_0 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B595_1 = NULL;
	int32_t G_B601_0 = 0;
	int32_t G_B603_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B607_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B607_1 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B606_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B606_1 = NULL;
	int32_t G_B608_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B608_1 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B608_2 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B610_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B610_1 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B609_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B609_1 = NULL;
	int32_t G_B611_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B611_1 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B611_2 = NULL;
	float G_B616_0 = 0.0f;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B616_1 = NULL;
	float G_B615_0 = 0.0f;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B615_1 = NULL;
	float G_B617_0 = 0.0f;
	float G_B617_1 = 0.0f;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B617_2 = NULL;
	float G_B620_0 = 0.0f;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B620_1 = NULL;
	float G_B619_0 = 0.0f;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B619_1 = NULL;
	float G_B621_0 = 0.0f;
	float G_B621_1 = 0.0f;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B621_2 = NULL;
	int32_t G_B628_0 = 0;
	float G_B635_0 = 0.0f;
	float G_B635_1 = 0.0f;
	float G_B633_0 = 0.0f;
	float G_B633_1 = 0.0f;
	float G_B634_0 = 0.0f;
	float G_B634_1 = 0.0f;
	float G_B636_0 = 0.0f;
	float G_B636_1 = 0.0f;
	float G_B636_2 = 0.0f;
	float G_B640_0 = 0.0f;
	float G_B640_1 = 0.0f;
	float G_B640_2 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B640_3 = NULL;
	float G_B638_0 = 0.0f;
	float G_B638_1 = 0.0f;
	float G_B638_2 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B638_3 = NULL;
	float G_B639_0 = 0.0f;
	float G_B639_1 = 0.0f;
	float G_B639_2 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B639_3 = NULL;
	float G_B641_0 = 0.0f;
	float G_B641_1 = 0.0f;
	float G_B641_2 = 0.0f;
	float G_B641_3 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B641_4 = NULL;
	int32_t G_B654_0 = 0;
	int32_t G_B666_0 = 0;
	int32_t G_B673_0 = 0;
	int32_t G_B675_0 = 0;
	int32_t G_B679_0 = 0;
	int32_t G_B699_0 = 0;
	int32_t G_B701_0 = 0;
	int32_t G_B710_0 = 0;
	int32_t G_B716_0 = 0;
	int32_t G_B726_0 = 0;
	int32_t G_B728_0 = 0;
	int32_t G_B891_0 = 0;
	int32_t G_B896_0 = 0;
	int32_t G_B899_0 = 0;
	int32_t G_B904_0 = 0;
	float G_B915_0 = 0.0f;
	float G_B920_0 = 0.0f;
	int32_t G_B926_0 = 0;
	int32_t G_B928_0 = 0;
	int32_t G_B972_0 = 0;
	int32_t G_B981_0 = 0;
	int32_t G_B989_0 = 0;
	int32_t G_B995_0 = 0;
	int32_t G_B1005_0 = 0;
	int32_t G_B1017_0 = 0;
	int32_t G_B1023_0 = 0;
	int32_t G_B1034_0 = 0;
	int32_t G_B1036_0 = 0;
	int32_t G_B1038_0 = 0;
	int32_t G_B1047_0 = 0;
	int32_t G_B1053_0 = 0;
	int32_t G_B1063_0 = 0;
	int32_t G_B1065_0 = 0;
	int32_t G_B1070_0 = 0;
	float G_B1074_0 = 0.0f;
	int32_t G_B1082_0 = 0;
	int32_t G_B1086_0 = 0;
	int32_t G_B1095_0 = 0;
	int32_t G_B1101_0 = 0;
	int32_t G_B1103_0 = 0;
	int32_t G_B1107_0 = 0;
	int32_t G_B1114_0 = 0;
	int32_t G_B1120_0 = 0;
	int32_t G_B1132_0 = 0;
	int32_t G_B1134_0 = 0;
	int32_t G_B1142_0 = 0;
	int32_t G_B1146_0 = 0;
	int32_t G_B1153_0 = 0;
	int32_t G_B1158_0 = 0;
	int32_t G_B1162_0 = 0;
	int32_t G_B1171_0 = 0;
	int32_t G_B1173_0 = 0;
	int32_t G_B1182_0 = 0;
	int32_t G_B1187_0 = 0;
	int32_t G_B1199_0 = 0;
	int32_t G_B1201_0 = 0;
	int32_t G_B1210_0 = 0;
	int32_t G_B1214_0 = 0;
	int32_t G_B1236_0 = 0;
	int32_t G_B1242_0 = 0;
	int32_t G_B1244_0 = 0;
	int32_t G_B1249_0 = 0;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* G_B1259_0 = NULL;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* G_B1258_0 = NULL;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* G_B1260_0 = NULL;
	int32_t G_B1261_0 = 0;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* G_B1261_1 = NULL;
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_0 = ___0_generationSettings;
		NullCheck(L_0);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1 = L_0->___fontAsset;
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		bool L_2;
		L_2 = Object_op_Equality_mB6120F782D83091EF56A198FCEBCF066DB4A9605(L_1, (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C*)NULL, NULL);
		if (L_2)
		{
			goto IL_001f;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3 = ___0_generationSettings;
		NullCheck(L_3);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_4 = L_3->___fontAsset;
		NullCheck(L_4);
		Dictionary_2_t93CDF0F4011A5A3024EB73A492F9512E3046EACB* L_5;
		L_5 = FontAsset_get_characterLookupTable_m7E76D6C706C5CEB04A9541C68AE6D9E5C75F0FFC(L_4, NULL);
		G_B3_0 = ((((RuntimeObject*)(Dictionary_2_t93CDF0F4011A5A3024EB73A492F9512E3046EACB*)L_5) == ((RuntimeObject*)(RuntimeObject*)NULL))? 1 : 0);
		goto IL_0020;
	}

IL_001f:
	{
		G_B3_0 = 1;
	}

IL_0020:
	{
		V_58 = (bool)G_B3_0;
		bool L_6 = V_58;
		if (!L_6)
		{
			goto IL_003e;
		}
	}
	{
		il2cpp_codegen_runtime_class_init_inline(Debug_t8394C7EEAECA3689C2C9B9DE9C7166D73596276F_il2cpp_TypeInfo_var);
		Debug_LogWarning_m33EF1B897E0C7C6FF538989610BFAFFEF4628CA9(_stringLiteral6EFD426731423F3C40A7DA0D6CAECBFB816A8F61, NULL);
		__this->___m_IsAutoSizePointSizeSet = (bool)1;
		goto IL_88b4;
	}

IL_003e:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_7 = ___1_textInfo;
		V_59 = (bool)((!(((RuntimeObject*)(TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09*)L_7) <= ((RuntimeObject*)(RuntimeObject*)NULL)))? 1 : 0);
		bool L_8 = V_59;
		if (!L_8)
		{
			goto IL_004f;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_9 = ___1_textInfo;
		NullCheck(L_9);
		TextInfo_Clear_m60412774208F9D920707448E71E89C99233D9128(L_9, NULL);
	}

IL_004f:
	{
		TextProcessingElementU5BU5D_t24A1E4C8745577D794FE856B4236875595E7FD22* L_10 = __this->___m_TextProcessingArray;
		if (!L_10)
		{
			goto IL_0076;
		}
	}
	{
		TextProcessingElementU5BU5D_t24A1E4C8745577D794FE856B4236875595E7FD22* L_11 = __this->___m_TextProcessingArray;
		NullCheck(L_11);
		if (!(((RuntimeArray*)L_11)->max_length))
		{
			goto IL_0076;
		}
	}
	{
		TextProcessingElementU5BU5D_t24A1E4C8745577D794FE856B4236875595E7FD22* L_12 = __this->___m_TextProcessingArray;
		NullCheck(L_12);
		uint32_t L_13 = ((L_12)->GetAddressAt(static_cast<il2cpp_array_size_t>(0)))->___unicode;
		G_B11_0 = ((((int32_t)L_13) == ((int32_t)0))? 1 : 0);
		goto IL_0077;
	}

IL_0076:
	{
		G_B11_0 = 1;
	}

IL_0077:
	{
		V_60 = (bool)G_B11_0;
		bool L_14 = V_60;
		if (!L_14)
		{
			goto IL_00a8;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_15 = ___1_textInfo;
		TextGenerator_ClearMesh_m68BA46B0365FC730BA5D2E6BDF2528BD370B2D83((bool)1, L_15, NULL);
		__this->___m_PreferredWidth = (0.0f);
		__this->___m_PreferredHeight = (0.0f);
		__this->___m_IsAutoSizePointSizeSet = (bool)1;
		goto IL_88b4;
	}

IL_00a8:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_16 = ___0_generationSettings;
		NullCheck(L_16);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_17 = L_16->___fontAsset;
		__this->___m_CurrentFontAsset = L_17;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CurrentFontAsset), (void*)L_17);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_18 = ___0_generationSettings;
		NullCheck(L_18);
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_19 = L_18->___material;
		__this->___m_CurrentMaterial = L_19;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CurrentMaterial), (void*)L_19);
		__this->___m_CurrentMaterialIndex = 0;
		TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA* L_20 = (TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA*)(&__this->___m_MaterialReferenceStack);
		int32_t L_21 = __this->___m_CurrentMaterialIndex;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_22 = __this->___m_CurrentFontAsset;
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_23 = __this->___m_CurrentMaterial;
		float L_24 = __this->___m_Padding;
		MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 L_25;
		memset((&L_25), 0, sizeof(L_25));
		MaterialReference__ctor_m044AAA2C1079EB25A5534A6E0FA2314F033DB15A((&L_25), L_21, L_22, (SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313*)NULL, L_23, L_24, NULL);
		TextProcessingStack_1_SetDefault_mDAFD4911B5A8BEE57351A37415ADF348F0A6B54C(L_20, L_25, TextProcessingStack_1_SetDefault_mDAFD4911B5A8BEE57351A37415ADF348F0A6B54C_RuntimeMethod_var);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_26 = ___0_generationSettings;
		NullCheck(L_26);
		SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* L_27 = L_26->___spriteAsset;
		__this->___m_CurrentSpriteAsset = L_27;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CurrentSpriteAsset), (void*)L_27);
		int32_t L_28 = __this->___m_TotalCharacterCount;
		V_0 = L_28;
		float L_29 = __this->___m_FontSize;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_30 = ___0_generationSettings;
		NullCheck(L_30);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_31 = L_30->___fontAsset;
		NullCheck(L_31);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_32 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_31->___m_FaceInfo);
		int32_t L_33;
		L_33 = FaceInfo_get_pointSize_m7EF7429A4725AB715931A220F6BB498C3D6BF7CB(L_32, NULL);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_34 = ___0_generationSettings;
		NullCheck(L_34);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_35 = L_34->___fontAsset;
		NullCheck(L_35);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_36 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_35->___m_FaceInfo);
		float L_37;
		L_37 = FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD(L_36, NULL);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_38 = ___0_generationSettings;
		NullCheck(L_38);
		bool L_39 = L_38->___isOrthographic;
		if (L_39)
		{
			G_B15_0 = ((float)il2cpp_codegen_multiply(((float)(L_29/((float)L_33))), L_37));
			goto IL_013c;
		}
		G_B14_0 = ((float)il2cpp_codegen_multiply(((float)(L_29/((float)L_33))), L_37));
	}
	{
		G_B16_0 = (0.100000001f);
		G_B16_1 = G_B14_0;
		goto IL_0141;
	}

IL_013c:
	{
		G_B16_0 = (1.0f);
		G_B16_1 = G_B15_0;
	}

IL_0141:
	{
		V_1 = ((float)il2cpp_codegen_multiply(G_B16_1, G_B16_0));
		float L_40 = V_1;
		V_2 = L_40;
		float L_41 = __this->___m_FontSize;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_42 = ___0_generationSettings;
		NullCheck(L_42);
		bool L_43 = L_42->___isOrthographic;
		if (L_43)
		{
			G_B18_0 = ((float)il2cpp_codegen_multiply(L_41, (0.00999999978f)));
			goto IL_0160;
		}
		G_B17_0 = ((float)il2cpp_codegen_multiply(L_41, (0.00999999978f)));
	}
	{
		G_B19_0 = (0.100000001f);
		G_B19_1 = G_B17_0;
		goto IL_0165;
	}

IL_0160:
	{
		G_B19_0 = (1.0f);
		G_B19_1 = G_B18_0;
	}

IL_0165:
	{
		V_3 = ((float)il2cpp_codegen_multiply(G_B19_1, G_B19_0));
		__this->___m_FontScaleMultiplier = (1.0f);
		float L_44 = __this->___m_FontSize;
		__this->___m_CurrentFontSize = L_44;
		TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555* L_45 = (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555*)(&__this->___m_SizeStack);
		float L_46 = __this->___m_CurrentFontSize;
		TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9(L_45, L_46, TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9_RuntimeMethod_var);
		V_4 = (0.0f);
		V_5 = 0;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_47 = ___0_generationSettings;
		NullCheck(L_47);
		int32_t L_48 = L_47->___fontStyle;
		__this->___m_FontStyleInternal = L_48;
		int32_t L_49 = __this->___m_FontStyleInternal;
		if ((((int32_t)((int32_t)((int32_t)L_49&1))) == ((int32_t)1)))
		{
			G_B21_0 = __this;
			goto IL_01ba;
		}
		G_B20_0 = __this;
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_50 = ___0_generationSettings;
		NullCheck(L_50);
		int32_t L_51 = L_50->___fontWeight;
		G_B22_0 = ((int32_t)(L_51));
		G_B22_1 = G_B20_0;
		goto IL_01bf;
	}

IL_01ba:
	{
		G_B22_0 = ((int32_t)700);
		G_B22_1 = G_B21_0;
	}

IL_01bf:
	{
		NullCheck(G_B22_1);
		G_B22_1->___m_FontWeightInternal = G_B22_0;
		TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790* L_52 = (TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790*)(&__this->___m_FontWeightStack);
		int32_t L_53 = __this->___m_FontWeightInternal;
		TextProcessingStack_1_SetDefault_mDF71503A7E4F1891305CDCC7AE245CA66A713E79(L_52, L_53, TextProcessingStack_1_SetDefault_mDF71503A7E4F1891305CDCC7AE245CA66A713E79_RuntimeMethod_var);
		FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7* L_54 = (FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7*)(&__this->___m_FontStyleStack);
		FontStyleStack_Clear_m989659363648B27540168E46F23E1EF9877C06E0(L_54, NULL);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_55 = ___0_generationSettings;
		NullCheck(L_55);
		int32_t L_56 = L_55->___textAlignment;
		__this->___m_LineJustification = L_56;
		TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F* L_57 = (TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F*)(&__this->___m_LineJustificationStack);
		int32_t L_58 = __this->___m_LineJustification;
		TextProcessingStack_1_SetDefault_m2DBB41C08A4CB7F71156ED5965850C2A0570F230(L_57, L_58, TextProcessingStack_1_SetDefault_m2DBB41C08A4CB7F71156ED5965850C2A0570F230_RuntimeMethod_var);
		V_6 = (0.0f);
		__this->___m_BaselineOffset = (0.0f);
		TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555* L_59 = (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555*)(&__this->___m_BaselineOffsetStack);
		TextProcessingStack_1_Clear_m857C80F9AFD9507FE4784DB5DE79109E16C8EAA3(L_59, TextProcessingStack_1_Clear_m857C80F9AFD9507FE4784DB5DE79109E16C8EAA3_RuntimeMethod_var);
		V_7 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_60;
		L_60 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_8 = L_60;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_61;
		L_61 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_9 = L_61;
		V_10 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_62;
		L_62 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_11 = L_62;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_63;
		L_63 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_12 = L_63;
		V_13 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_64;
		L_64 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_14 = L_64;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_65;
		L_65 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_15 = L_65;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_66 = ___0_generationSettings;
		NullCheck(L_66);
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_67 = L_66->___color;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_68;
		L_68 = Color32_op_Implicit_m79AF5E0BDE9CE041CAC4D89CBFA66E71C6DD1B70_inline(L_67, NULL);
		__this->___m_FontColor32 = L_68;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_69 = __this->___m_FontColor32;
		__this->___m_HtmlColor = L_69;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_70 = __this->___m_HtmlColor;
		__this->___m_UnderlineColor = L_70;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_71 = __this->___m_HtmlColor;
		__this->___m_StrikethroughColor = L_71;
		TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63* L_72 = (TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63*)(&__this->___m_ColorStack);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_73 = __this->___m_HtmlColor;
		TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54(L_72, L_73, TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_RuntimeMethod_var);
		TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63* L_74 = (TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63*)(&__this->___m_UnderlineColorStack);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_75 = __this->___m_HtmlColor;
		TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54(L_74, L_75, TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_RuntimeMethod_var);
		TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63* L_76 = (TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63*)(&__this->___m_StrikethroughColorStack);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_77 = __this->___m_HtmlColor;
		TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54(L_76, L_77, TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_RuntimeMethod_var);
		TextProcessingStack_1_tF3616757510D9631241E95596F10A4139420DA16* L_78 = (TextProcessingStack_1_tF3616757510D9631241E95596F10A4139420DA16*)(&__this->___m_HighlightStateStack);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_79 = __this->___m_HtmlColor;
		il2cpp_codegen_runtime_class_init_inline(Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4_il2cpp_TypeInfo_var);
		Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4 L_80;
		L_80 = Offset_get_zero_mF5B6D7C3F437FA438844A0B3EF405D805F1D1958(NULL);
		HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 L_81;
		memset((&L_81), 0, sizeof(L_81));
		HighlightState__ctor_mDBB71C58F46D7BDC518026AC796D24F2D9B36D3F((&L_81), L_79, L_80, NULL);
		TextProcessingStack_1_SetDefault_m11524F3861DE3F60DE2BAB47DF333011E27E5C2C(L_78, L_81, TextProcessingStack_1_SetDefault_m11524F3861DE3F60DE2BAB47DF333011E27E5C2C_RuntimeMethod_var);
		__this->___m_ColorGradientPreset = (TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70*)NULL;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_ColorGradientPreset), (void*)(TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70*)NULL);
		TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E* L_82 = (TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E*)(&__this->___m_ColorGradientStack);
		TextProcessingStack_1_SetDefault_mDD0BF36ABFBF0DBA2D289C08F9862374CE18A0F9(L_82, (TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70*)NULL, TextProcessingStack_1_SetDefault_mDD0BF36ABFBF0DBA2D289C08F9862374CE18A0F9_RuntimeMethod_var);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_83 = __this->___m_CurrentFontAsset;
		NullCheck(L_83);
		uint8_t L_84;
		L_84 = FontAsset_get_italicStyleSlant_m69E70060C6E7940B4ACE61F2B7CB8965F86DA96B(L_83, NULL);
		__this->___m_ItalicAngle = L_84;
		TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8* L_85 = (TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8*)(&__this->___m_ItalicAngleStack);
		int32_t L_86 = __this->___m_ItalicAngle;
		TextProcessingStack_1_SetDefault_m2C394C84507BCA030509AC6708DCBC3F26E112B7(L_85, L_86, TextProcessingStack_1_SetDefault_m2C394C84507BCA030509AC6708DCBC3F26E112B7_RuntimeMethod_var);
		TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8* L_87 = (TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8*)(&__this->___m_ActionStack);
		TextProcessingStack_1_Clear_m3684329CF566CB94C981B1EAB3F1F3C74D42D0CD(L_87, TextProcessingStack_1_Clear_m3684329CF566CB94C981B1EAB3F1F3C74D42D0CD_RuntimeMethod_var);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_88;
		L_88 = Vector3_get_one_mC9B289F1E15C42C597180C9FE6FB492495B51D02_inline(NULL);
		__this->___m_FXScale = L_88;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_89;
		L_89 = Quaternion_get_identity_m7E701AE095ED10FD5EA0B50ABCFDE2EEFF2173A5_inline(NULL);
		__this->___m_FXRotation = L_89;
		__this->___m_LineOffset = (0.0f);
		__this->___m_LineHeight = (-32767.0f);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_90 = __this->___m_CurrentFontAsset;
		NullCheck(L_90);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_91;
		L_91 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_90, NULL);
		V_61 = L_91;
		float L_92;
		L_92 = FaceInfo_get_lineHeight_m528B4A822181FCECF3D4FF1045DF288E5872AB9D((&V_61), NULL);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_93 = __this->___m_CurrentFontAsset;
		NullCheck(L_93);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_94 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_93->___m_FaceInfo);
		float L_95;
		L_95 = FaceInfo_get_ascentLine_m193755D649428EC24A7E433A1728F11DA7547ABD(L_94, NULL);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_96 = __this->___m_CurrentFontAsset;
		NullCheck(L_96);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_97 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_96->___m_FaceInfo);
		float L_98;
		L_98 = FaceInfo_get_descentLine_m811A243C9B328B0C546BF9927A010A05DF172BD3(L_97, NULL);
		V_16 = ((float)il2cpp_codegen_subtract(L_92, ((float)il2cpp_codegen_subtract(L_95, L_98))));
		__this->___m_CSpacing = (0.0f);
		__this->___m_MonoSpacing = (0.0f);
		__this->___m_XAdvance = (0.0f);
		__this->___m_TagLineIndent = (0.0f);
		__this->___m_TagIndent = (0.0f);
		TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555* L_99 = (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555*)(&__this->___m_IndentStack);
		TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9(L_99, (0.0f), TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9_RuntimeMethod_var);
		__this->___m_TagNoParsing = (bool)0;
		__this->___m_CharacterCount = 0;
		__this->___m_FirstCharacterOfLine = 0;
		__this->___m_LastCharacterOfLine = 0;
		__this->___m_FirstVisibleCharacterOfLine = 0;
		__this->___m_LastVisibleCharacterOfLine = 0;
		__this->___m_MaxLineAscender = (-32767.0f);
		__this->___m_MaxLineDescender = (32767.0f);
		__this->___m_LineNumber = 0;
		__this->___m_StartOfLineAscender = (0.0f);
		__this->___m_LineVisibleCharacterCount = 0;
		__this->___m_LineVisibleSpaceCount = 0;
		V_17 = (bool)1;
		__this->___m_IsDrivenLineSpacing = (bool)0;
		__this->___m_FirstOverflowCharacterIndex = (-1);
		__this->___m_LastBaseGlyphIndex = ((int32_t)-2147483648LL);
		__this->___m_PageNumber = 0;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_100 = ___0_generationSettings;
		NullCheck(L_100);
		int32_t L_101 = L_100->___pageToDisplay;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_102 = ___1_textInfo;
		NullCheck(L_102);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_103 = L_102->___pageInfo;
		NullCheck(L_103);
		int32_t L_104;
		L_104 = Mathf_Clamp_m4DC36EEFDBE5F07C16249DA568023C5ECCFF0E7B_inline(((int32_t)il2cpp_codegen_subtract(L_101, 1)), 0, ((int32_t)il2cpp_codegen_subtract(((int32_t)(((RuntimeArray*)L_103)->max_length)), 1)), NULL);
		V_18 = L_104;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_105 = ___1_textInfo;
		NullCheck(L_105);
		TextInfo_ClearPageInfo_m57DE207346C5245799E50F8A57B56B65665B7430(L_105, NULL);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_106 = ___0_generationSettings;
		NullCheck(L_106);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_107 = L_106->___margins;
		V_19 = L_107;
		float L_108 = __this->___m_MarginWidth;
		if ((((float)L_108) > ((float)(0.0f))))
		{
			goto IL_0487;
		}
	}
	{
		G_B25_0 = (0.0f);
		goto IL_048d;
	}

IL_0487:
	{
		float L_109 = __this->___m_MarginWidth;
		G_B25_0 = L_109;
	}

IL_048d:
	{
		V_20 = G_B25_0;
		float L_110 = __this->___m_MarginHeight;
		if ((((float)L_110) > ((float)(0.0f))))
		{
			goto IL_04a3;
		}
	}
	{
		G_B28_0 = (0.0f);
		goto IL_04a9;
	}

IL_04a3:
	{
		float L_111 = __this->___m_MarginHeight;
		G_B28_0 = L_111;
	}

IL_04a9:
	{
		V_21 = G_B28_0;
		__this->___m_MarginLeft = (0.0f);
		__this->___m_MarginRight = (0.0f);
		__this->___m_Width = (-1.0f);
		float L_112 = V_20;
		float L_113 = __this->___m_MarginLeft;
		float L_114 = __this->___m_MarginRight;
		V_22 = ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_112, (9.99999975E-05f))), L_113)), L_114));
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_115 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_116 = ((TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_StaticFields*)il2cpp_codegen_static_fields_for(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var))->___largePositiveVector2;
		L_115->___min = L_116;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_117 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_118 = ((TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_StaticFields*)il2cpp_codegen_static_fields_for(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var))->___largeNegativeVector2;
		L_117->___max = L_118;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_119 = ___1_textInfo;
		NullCheck(L_119);
		TextInfo_ClearLineInfo_m986C886D34A324C8C4D30F9D8EF24AC242A10AD7(L_119, NULL);
		__this->___m_MaxCapHeight = (0.0f);
		__this->___m_MaxAscender = (0.0f);
		__this->___m_MaxDescender = (0.0f);
		__this->___m_PageAscender = (0.0f);
		V_23 = (0.0f);
		V_24 = (bool)0;
		__this->___m_IsNewPage = (bool)0;
		V_25 = (bool)1;
		__this->___m_IsNonBreakingSpace = (bool)0;
		V_26 = (bool)0;
		V_27 = 0;
		CharacterSubstitution__ctor_mBB5C3EA59D985711FE3DF1F266D648201E18CE29((&V_28), (-1), 0, NULL);
		V_29 = (bool)0;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_120 = ___0_generationSettings;
		NullCheck(L_120);
		bool L_121 = L_120->___wordWrap;
		if (L_121)
		{
			goto IL_056f;
		}
	}
	{
		G_B31_0 = 0;
		goto IL_0570;
	}

IL_056f:
	{
		G_B31_0 = 1;
	}

IL_0570:
	{
		V_30 = G_B31_0;
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_122 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedWordWrapState);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_123 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_122, (-1), (-1), L_123, NULL);
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_124 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedLineState);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_125 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_124, (-1), (-1), L_125, NULL);
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_126 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedEllipsisState);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_127 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_126, (-1), (-1), L_127, NULL);
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_128 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedLastValidState);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_129 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_128, (-1), (-1), L_129, NULL);
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_130 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedSoftLineBreakState);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_131 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_130, (-1), (-1), L_131, NULL);
		TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9* L_132 = (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9*)(&__this->___m_EllipsisInsertionCandidateStack);
		TextProcessingStack_1_Clear_m78D739A4A3B093B4CA2AD9D95578D2B4BB9909C3(L_132, TextProcessingStack_1_Clear_m78D739A4A3B093B4CA2AD9D95578D2B4BB9909C3_RuntimeMethod_var);
		((TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366_StaticFields*)il2cpp_codegen_static_fields_for(TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366_il2cpp_TypeInfo_var))->___m_IsTextTruncated = (bool)0;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_133 = ___0_generationSettings;
		NullCheck(L_133);
		TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64* L_134 = L_133->___textSettings;
		V_31 = L_134;
		V_32 = 0;
		V_62 = 0;
		goto IL_43e1;
	}

IL_05e7:
	{
		TextProcessingElementU5BU5D_t24A1E4C8745577D794FE856B4236875595E7FD22* L_135 = __this->___m_TextProcessingArray;
		int32_t L_136 = V_62;
		NullCheck(L_135);
		uint32_t L_137 = ((L_135)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_136)))->___unicode;
		V_5 = L_137;
		int32_t L_138 = V_32;
		V_90 = (bool)((((int32_t)L_138) > ((int32_t)5))? 1 : 0);
		bool L_139 = V_90;
		if (!L_139)
		{
			goto IL_0641;
		}
	}
	{
		String_t* L_140;
		L_140 = UInt32_ToString_mB6FA6D2459C82ADCF285C55363491D9669A80154((&V_5), NULL);
		String_t* L_141;
		L_141 = Int32_ToString_m030E01C24E294D6762FB0B6F37CB541581F55CA5((&V_62), NULL);
		String_t* L_142;
		L_142 = String_Concat_m093934F71A9B351911EE46311674ED463B180006(_stringLiteral41BB69D2BDF9A4541A716BE07E74D1ED0DEADD05, L_140, _stringLiteral94B946B03625197025E6D70053ADE0256BC25DD1, L_141, NULL);
		il2cpp_codegen_runtime_class_init_inline(Debug_t8394C7EEAECA3689C2C9B9DE9C7166D73596276F_il2cpp_TypeInfo_var);
		Debug_LogError_mB00B2B4468EF3CAF041B038D840820FB84C924B2(L_142, NULL);
		int32_t L_143 = __this->___m_CharacterCount;
		(&V_28)->___index = L_143;
		(&V_28)->___unicode = 3;
	}

IL_0641:
	{
		uint32_t L_144 = V_5;
		V_91 = (bool)((((int32_t)L_144) == ((int32_t)((int32_t)26)))? 1 : 0);
		bool L_145 = V_91;
		if (!L_145)
		{
			goto IL_0652;
		}
	}
	{
		goto IL_43d7;
	}

IL_0652:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_146 = ___0_generationSettings;
		NullCheck(L_146);
		bool L_147 = L_146->___richText;
		if (!L_147)
		{
			goto IL_0662;
		}
	}
	{
		uint32_t L_148 = V_5;
		G_B39_0 = ((((int32_t)L_148) == ((int32_t)((int32_t)60)))? 1 : 0);
		goto IL_0663;
	}

IL_0662:
	{
		G_B39_0 = 0;
	}

IL_0663:
	{
		V_92 = (bool)G_B39_0;
		bool L_149 = V_92;
		if (!L_149)
		{
			goto IL_06b0;
		}
	}
	{
		__this->___m_isTextLayoutPhase = (bool)1;
		__this->___m_TextElementType = 1;
		TextProcessingElementU5BU5D_t24A1E4C8745577D794FE856B4236875595E7FD22* L_150 = __this->___m_TextProcessingArray;
		int32_t L_151 = V_62;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_152 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_153 = ___1_textInfo;
		bool L_154;
		L_154 = TextGenerator_ValidateHtmlTag_mF8187EB1D0CB901861EDFC36151409F8FF6AB287(__this, L_150, ((int32_t)il2cpp_codegen_add(L_151, 1)), (&V_93), L_152, L_153, NULL);
		V_94 = L_154;
		bool L_155 = V_94;
		if (!L_155)
		{
			goto IL_06ad;
		}
	}
	{
		int32_t L_156 = V_93;
		V_62 = L_156;
		uint8_t L_157 = __this->___m_TextElementType;
		V_95 = (bool)((((int32_t)L_157) == ((int32_t)1))? 1 : 0);
		bool L_158 = V_95;
		if (!L_158)
		{
			goto IL_06ac;
		}
	}
	{
		goto IL_43d7;
	}

IL_06ac:
	{
	}

IL_06ad:
	{
		goto IL_0706;
	}

IL_06b0:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_159 = ___1_textInfo;
		NullCheck(L_159);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_160 = L_159->___textElementInfo;
		int32_t L_161 = __this->___m_CharacterCount;
		NullCheck(L_160);
		uint8_t L_162 = ((L_160)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_161)))->___elementType;
		__this->___m_TextElementType = L_162;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_163 = ___1_textInfo;
		NullCheck(L_163);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_164 = L_163->___textElementInfo;
		int32_t L_165 = __this->___m_CharacterCount;
		NullCheck(L_164);
		int32_t L_166 = ((L_164)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_165)))->___materialReferenceIndex;
		__this->___m_CurrentMaterialIndex = L_166;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_167 = ___1_textInfo;
		NullCheck(L_167);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_168 = L_167->___textElementInfo;
		int32_t L_169 = __this->___m_CharacterCount;
		NullCheck(L_168);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_170 = ((L_168)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_169)))->___fontAsset;
		__this->___m_CurrentFontAsset = L_170;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CurrentFontAsset), (void*)L_170);
	}

IL_0706:
	{
		int32_t L_171 = __this->___m_CurrentMaterialIndex;
		V_63 = L_171;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_172 = ___1_textInfo;
		NullCheck(L_172);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_173 = L_172->___textElementInfo;
		int32_t L_174 = __this->___m_CharacterCount;
		NullCheck(L_173);
		bool L_175 = ((L_173)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_174)))->___isUsingAlternateTypeface;
		V_64 = L_175;
		__this->___m_isTextLayoutPhase = (bool)0;
		V_65 = (bool)0;
		CharacterSubstitution_t9F6215FBA3E8AD8DDF6F35A51CEC7CB7E9A44F83 L_176 = V_28;
		int32_t L_177 = L_176.___index;
		int32_t L_178 = __this->___m_CharacterCount;
		V_96 = (bool)((((int32_t)L_177) == ((int32_t)L_178))? 1 : 0);
		bool L_179 = V_96;
		if (!L_179)
		{
			goto IL_0873;
		}
	}
	{
		CharacterSubstitution_t9F6215FBA3E8AD8DDF6F35A51CEC7CB7E9A44F83 L_180 = V_28;
		uint32_t L_181 = L_180.___unicode;
		V_5 = L_181;
		__this->___m_TextElementType = 1;
		V_65 = (bool)1;
		uint32_t L_182 = V_5;
		V_98 = L_182;
		uint32_t L_183 = V_98;
		V_97 = L_183;
		uint32_t L_184 = V_97;
		if ((((int32_t)L_184) == ((int32_t)3)))
		{
			goto IL_0781;
		}
	}
	{
		goto IL_076b;
	}

IL_076b:
	{
		uint32_t L_185 = V_97;
		if ((((int32_t)L_185) == ((int32_t)((int32_t)45))))
		{
			goto IL_07b3;
		}
	}
	{
		goto IL_0773;
	}

IL_0773:
	{
		uint32_t L_186 = V_97;
		if ((((int32_t)L_186) == ((int32_t)((int32_t)8230))))
		{
			goto IL_07b8;
		}
	}
	{
		goto IL_0872;
	}

IL_0781:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_187 = ___1_textInfo;
		NullCheck(L_187);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_188 = L_187->___textElementInfo;
		int32_t L_189 = __this->___m_CharacterCount;
		NullCheck(L_188);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_190 = __this->___m_CurrentFontAsset;
		NullCheck(L_190);
		Dictionary_2_t93CDF0F4011A5A3024EB73A492F9512E3046EACB* L_191;
		L_191 = FontAsset_get_characterLookupTable_m7E76D6C706C5CEB04A9541C68AE6D9E5C75F0FFC(L_190, NULL);
		NullCheck(L_191);
		Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* L_192;
		L_192 = Dictionary_2_get_Item_mFA05B9BB2D2D3E43B23F6C859A051759E7C1C75D(L_191, 3, Dictionary_2_get_Item_mFA05B9BB2D2D3E43B23F6C859A051759E7C1C75D_RuntimeMethod_var);
		((L_188)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_189)))->___textElement = L_192;
		Il2CppCodeGenWriteBarrier((void**)(&((L_188)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_189)))->___textElement), (void*)L_192);
		((TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366_StaticFields*)il2cpp_codegen_static_fields_for(TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366_il2cpp_TypeInfo_var))->___m_IsTextTruncated = (bool)1;
		goto IL_0872;
	}

IL_07b3:
	{
		goto IL_0872;
	}

IL_07b8:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_193 = ___1_textInfo;
		NullCheck(L_193);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_194 = L_193->___textElementInfo;
		int32_t L_195 = __this->___m_CharacterCount;
		NullCheck(L_194);
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_196 = (SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD*)(&__this->___m_Ellipsis);
		Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* L_197 = L_196->___character;
		((L_194)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_195)))->___textElement = L_197;
		Il2CppCodeGenWriteBarrier((void**)(&((L_194)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_195)))->___textElement), (void*)L_197);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_198 = ___1_textInfo;
		NullCheck(L_198);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_199 = L_198->___textElementInfo;
		int32_t L_200 = __this->___m_CharacterCount;
		NullCheck(L_199);
		((L_199)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_200)))->___elementType = 1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_201 = ___1_textInfo;
		NullCheck(L_201);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_202 = L_201->___textElementInfo;
		int32_t L_203 = __this->___m_CharacterCount;
		NullCheck(L_202);
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_204 = (SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD*)(&__this->___m_Ellipsis);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_205 = L_204->___fontAsset;
		((L_202)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_203)))->___fontAsset = L_205;
		Il2CppCodeGenWriteBarrier((void**)(&((L_202)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_203)))->___fontAsset), (void*)L_205);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_206 = ___1_textInfo;
		NullCheck(L_206);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_207 = L_206->___textElementInfo;
		int32_t L_208 = __this->___m_CharacterCount;
		NullCheck(L_207);
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_209 = (SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD*)(&__this->___m_Ellipsis);
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_210 = L_209->___material;
		((L_207)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_208)))->___material = L_210;
		Il2CppCodeGenWriteBarrier((void**)(&((L_207)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_208)))->___material), (void*)L_210);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_211 = ___1_textInfo;
		NullCheck(L_211);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_212 = L_211->___textElementInfo;
		int32_t L_213 = __this->___m_CharacterCount;
		NullCheck(L_212);
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_214 = (SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD*)(&__this->___m_Ellipsis);
		int32_t L_215 = L_214->___materialIndex;
		((L_212)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_213)))->___materialReferenceIndex = L_215;
		((TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366_StaticFields*)il2cpp_codegen_static_fields_for(TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366_il2cpp_TypeInfo_var))->___m_IsTextTruncated = (bool)1;
		int32_t L_216 = __this->___m_CharacterCount;
		(&V_28)->___index = ((int32_t)il2cpp_codegen_add(L_216, 1));
		(&V_28)->___unicode = 3;
		goto IL_0872;
	}

IL_0872:
	{
	}

IL_0873:
	{
		int32_t L_217 = __this->___m_CharacterCount;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_218 = ___0_generationSettings;
		NullCheck(L_218);
		int32_t L_219 = L_218->___firstVisibleCharacter;
		if ((((int32_t)L_217) >= ((int32_t)L_219)))
		{
			goto IL_088b;
		}
	}
	{
		uint32_t L_220 = V_5;
		G_B60_0 = ((((int32_t)((((int32_t)L_220) == ((int32_t)3))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_088c;
	}

IL_088b:
	{
		G_B60_0 = 0;
	}

IL_088c:
	{
		V_99 = (bool)G_B60_0;
		bool L_221 = V_99;
		if (!L_221)
		{
			goto IL_08ef;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_222 = ___1_textInfo;
		NullCheck(L_222);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_223 = L_222->___textElementInfo;
		int32_t L_224 = __this->___m_CharacterCount;
		NullCheck(L_223);
		((L_223)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_224)))->___isVisible = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_225 = ___1_textInfo;
		NullCheck(L_225);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_226 = L_225->___textElementInfo;
		int32_t L_227 = __this->___m_CharacterCount;
		NullCheck(L_226);
		((L_226)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_227)))->___character = ((int32_t)8203);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_228 = ___1_textInfo;
		NullCheck(L_228);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_229 = L_228->___textElementInfo;
		int32_t L_230 = __this->___m_CharacterCount;
		NullCheck(L_229);
		((L_229)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_230)))->___lineNumber = 0;
		int32_t L_231 = __this->___m_CharacterCount;
		__this->___m_CharacterCount = ((int32_t)il2cpp_codegen_add(L_231, 1));
		goto IL_43d7;
	}

IL_08ef:
	{
		V_66 = (1.0f);
		uint8_t L_232 = __this->___m_TextElementType;
		V_100 = (bool)((((int32_t)L_232) == ((int32_t)1))? 1 : 0);
		bool L_233 = V_100;
		if (!L_233)
		{
			goto IL_099c;
		}
	}
	{
		int32_t L_234 = __this->___m_FontStyleInternal;
		V_101 = (bool)((((int32_t)((int32_t)((int32_t)L_234&((int32_t)16)))) == ((int32_t)((int32_t)16)))? 1 : 0);
		bool L_235 = V_101;
		if (!L_235)
		{
			goto IL_0938;
		}
	}
	{
		uint32_t L_236 = V_5;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_237;
		L_237 = Char_IsLower_m9DDB41367F97CFFE6C46A3B5EDE7D11180B5F1AE(((int32_t)(uint16_t)L_236), NULL);
		V_102 = L_237;
		bool L_238 = V_102;
		if (!L_238)
		{
			goto IL_0935;
		}
	}
	{
		uint32_t L_239 = V_5;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		Il2CppChar L_240;
		L_240 = Char_ToUpper_m7DB51DD07EE52F4CA897807281880930F5CBD2D2(((int32_t)(uint16_t)L_239), NULL);
		V_5 = L_240;
	}

IL_0935:
	{
		goto IL_099b;
	}

IL_0938:
	{
		int32_t L_241 = __this->___m_FontStyleInternal;
		V_103 = (bool)((((int32_t)((int32_t)((int32_t)L_241&8))) == ((int32_t)8))? 1 : 0);
		bool L_242 = V_103;
		if (!L_242)
		{
			goto IL_0965;
		}
	}
	{
		uint32_t L_243 = V_5;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_244;
		L_244 = Char_IsUpper_mF150C44B70F522A14B2A8DF71DE0ADE52F9A3392(((int32_t)(uint16_t)L_243), NULL);
		V_104 = L_244;
		bool L_245 = V_104;
		if (!L_245)
		{
			goto IL_0962;
		}
	}
	{
		uint32_t L_246 = V_5;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		Il2CppChar L_247;
		L_247 = Char_ToLower_m238489988C62CB10C7C7CAAEF8F3B2D1C5B5E056(((int32_t)(uint16_t)L_246), NULL);
		V_5 = L_247;
	}

IL_0962:
	{
		goto IL_099b;
	}

IL_0965:
	{
		int32_t L_248 = __this->___m_FontStyleInternal;
		V_105 = (bool)((((int32_t)((int32_t)((int32_t)L_248&((int32_t)32)))) == ((int32_t)((int32_t)32)))? 1 : 0);
		bool L_249 = V_105;
		if (!L_249)
		{
			goto IL_099b;
		}
	}
	{
		uint32_t L_250 = V_5;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_251;
		L_251 = Char_IsLower_m9DDB41367F97CFFE6C46A3B5EDE7D11180B5F1AE(((int32_t)(uint16_t)L_250), NULL);
		V_106 = L_251;
		bool L_252 = V_106;
		if (!L_252)
		{
			goto IL_099a;
		}
	}
	{
		V_66 = (0.800000012f);
		uint32_t L_253 = V_5;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		Il2CppChar L_254;
		L_254 = Char_ToUpper_m7DB51DD07EE52F4CA897807281880930F5CBD2D2(((int32_t)(uint16_t)L_253), NULL);
		V_5 = L_254;
	}

IL_099a:
	{
	}

IL_099b:
	{
	}

IL_099c:
	{
		V_67 = (0.0f);
		V_68 = (0.0f);
		V_69 = (0.0f);
		uint8_t L_255 = __this->___m_TextElementType;
		V_107 = (bool)((((int32_t)L_255) == ((int32_t)2))? 1 : 0);
		bool L_256 = V_107;
		if (!L_256)
		{
			goto IL_0ccd;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_257 = ___1_textInfo;
		NullCheck(L_257);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_258 = L_257->___textElementInfo;
		int32_t L_259 = __this->___m_CharacterCount;
		NullCheck(L_258);
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_260 = ((L_258)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_259)))->___textElement;
		V_108 = ((SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5*)CastclassClass((RuntimeObject*)L_260, SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5_il2cpp_TypeInfo_var));
		SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* L_261 = V_108;
		NullCheck(L_261);
		TextAsset_tB28F1843A877CCA74B89DC4F63EA532618B049B8* L_262;
		L_262 = TextElement_get_textAsset_m52383A3758AABF5BEA013155765BD1141479685A(L_261, NULL);
		__this->___m_CurrentSpriteAsset = ((SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313*)IsInstClass((RuntimeObject*)L_262, SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313_il2cpp_TypeInfo_var));
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CurrentSpriteAsset), (void*)((SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313*)IsInstClass((RuntimeObject*)L_262, SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313_il2cpp_TypeInfo_var)));
		SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* L_263 = V_108;
		NullCheck(L_263);
		uint32_t L_264;
		L_264 = TextElement_get_glyphIndex_m43F82F2F998D640DEDBE6860EBE7B171DDF4FE56(L_263, NULL);
		__this->___m_SpriteIndex = L_264;
		SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* L_265 = V_108;
		V_110 = (bool)((((RuntimeObject*)(SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5*)L_265) == ((RuntimeObject*)(RuntimeObject*)NULL))? 1 : 0);
		bool L_266 = V_110;
		if (!L_266)
		{
			goto IL_0a10;
		}
	}
	{
		goto IL_43d7;
	}

IL_0a10:
	{
		uint32_t L_267 = V_5;
		V_111 = (bool)((((int32_t)L_267) == ((int32_t)((int32_t)60)))? 1 : 0);
		bool L_268 = V_111;
		if (!L_268)
		{
			goto IL_0a2c;
		}
	}
	{
		int32_t L_269 = __this->___m_SpriteIndex;
		V_5 = ((int32_t)il2cpp_codegen_add(((int32_t)57344), L_269));
		goto IL_0a3c;
	}

IL_0a2c:
	{
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_270;
		L_270 = Color_get_white_m068F5AF879B0FCA584E3693F762EA41BB65532C6_inline(NULL);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_271;
		L_271 = Color32_op_Implicit_m79AF5E0BDE9CE041CAC4D89CBFA66E71C6DD1B70_inline(L_270, NULL);
		__this->___m_SpriteColor = L_271;
	}

IL_0a3c:
	{
		float L_272 = __this->___m_CurrentFontSize;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_273 = __this->___m_CurrentFontAsset;
		NullCheck(L_273);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_274;
		L_274 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_273, NULL);
		V_61 = L_274;
		int32_t L_275;
		L_275 = FaceInfo_get_pointSize_m7EF7429A4725AB715931A220F6BB498C3D6BF7CB((&V_61), NULL);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_276 = __this->___m_CurrentFontAsset;
		NullCheck(L_276);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_277;
		L_277 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_276, NULL);
		V_61 = L_277;
		float L_278;
		L_278 = FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD((&V_61), NULL);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_279 = ___0_generationSettings;
		NullCheck(L_279);
		bool L_280 = L_279->___isOrthographic;
		if (L_280)
		{
			G_B84_0 = ((float)il2cpp_codegen_multiply(((float)(L_272/((float)L_275))), L_278));
			goto IL_0a7c;
		}
		G_B83_0 = ((float)il2cpp_codegen_multiply(((float)(L_272/((float)L_275))), L_278));
	}
	{
		G_B85_0 = (0.100000001f);
		G_B85_1 = G_B83_0;
		goto IL_0a81;
	}

IL_0a7c:
	{
		G_B85_0 = (1.0f);
		G_B85_1 = G_B84_0;
	}

IL_0a81:
	{
		V_109 = ((float)il2cpp_codegen_multiply(G_B85_1, G_B85_0));
		SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* L_281 = __this->___m_CurrentSpriteAsset;
		NullCheck(L_281);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_282 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_281->___m_FaceInfo);
		int32_t L_283;
		L_283 = FaceInfo_get_pointSize_m7EF7429A4725AB715931A220F6BB498C3D6BF7CB(L_282, NULL);
		V_112 = (bool)((((int32_t)L_283) > ((int32_t)0))? 1 : 0);
		bool L_284 = V_112;
		if (!L_284)
		{
			goto IL_0b50;
		}
	}
	{
		float L_285 = __this->___m_CurrentFontSize;
		SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* L_286 = __this->___m_CurrentSpriteAsset;
		NullCheck(L_286);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_287 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_286->___m_FaceInfo);
		int32_t L_288;
		L_288 = FaceInfo_get_pointSize_m7EF7429A4725AB715931A220F6BB498C3D6BF7CB(L_287, NULL);
		SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* L_289 = __this->___m_CurrentSpriteAsset;
		NullCheck(L_289);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_290 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_289->___m_FaceInfo);
		float L_291;
		L_291 = FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD(L_290, NULL);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_292 = ___0_generationSettings;
		NullCheck(L_292);
		bool L_293 = L_292->___isOrthographic;
		if (L_293)
		{
			G_B88_0 = ((float)il2cpp_codegen_multiply(((float)(L_285/((float)L_288))), L_291));
			goto IL_0ad9;
		}
		G_B87_0 = ((float)il2cpp_codegen_multiply(((float)(L_285/((float)L_288))), L_291));
	}
	{
		G_B89_0 = (0.100000001f);
		G_B89_1 = G_B87_0;
		goto IL_0ade;
	}

IL_0ad9:
	{
		G_B89_0 = (1.0f);
		G_B89_1 = G_B88_0;
	}

IL_0ade:
	{
		V_113 = ((float)il2cpp_codegen_multiply(G_B89_1, G_B89_0));
		SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* L_294 = V_108;
		NullCheck(L_294);
		float L_295 = ((TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA*)L_294)->___m_Scale;
		SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* L_296 = V_108;
		NullCheck(L_296);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_297 = ((TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA*)L_296)->___m_Glyph;
		NullCheck(L_297);
		float L_298;
		L_298 = Glyph_get_scale_m3ED738CBB032247526DB38161E180759B2D06F29(L_297, NULL);
		float L_299 = V_113;
		V_2 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(L_295, L_298)), L_299));
		SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* L_300 = __this->___m_CurrentSpriteAsset;
		NullCheck(L_300);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_301 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_300->___m_FaceInfo);
		float L_302;
		L_302 = FaceInfo_get_ascentLine_m193755D649428EC24A7E433A1728F11DA7547ABD(L_301, NULL);
		V_68 = L_302;
		SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* L_303 = __this->___m_CurrentSpriteAsset;
		NullCheck(L_303);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_304 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_303->___m_FaceInfo);
		float L_305;
		L_305 = FaceInfo_get_baseline_m934B597D3E0080FEF98CBDD091C457B497179C3A(L_304, NULL);
		float L_306 = V_109;
		float L_307 = __this->___m_FontScaleMultiplier;
		SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* L_308 = __this->___m_CurrentSpriteAsset;
		NullCheck(L_308);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_309 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_308->___m_FaceInfo);
		float L_310;
		L_310 = FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD(L_309, NULL);
		V_67 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(L_305, L_306)), L_307)), L_310));
		SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* L_311 = __this->___m_CurrentSpriteAsset;
		NullCheck(L_311);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_312 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_311->___m_FaceInfo);
		float L_313;
		L_313 = FaceInfo_get_descentLine_m811A243C9B328B0C546BF9927A010A05DF172BD3(L_312, NULL);
		V_69 = L_313;
		goto IL_0c2e;
	}

IL_0b50:
	{
		float L_314 = __this->___m_CurrentFontSize;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_315 = __this->___m_CurrentFontAsset;
		NullCheck(L_315);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_316 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_315->___m_FaceInfo);
		int32_t L_317;
		L_317 = FaceInfo_get_pointSize_m7EF7429A4725AB715931A220F6BB498C3D6BF7CB(L_316, NULL);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_318 = __this->___m_CurrentFontAsset;
		NullCheck(L_318);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_319 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_318->___m_FaceInfo);
		float L_320;
		L_320 = FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD(L_319, NULL);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_321 = ___0_generationSettings;
		NullCheck(L_321);
		bool L_322 = L_321->___isOrthographic;
		if (L_322)
		{
			G_B92_0 = ((float)il2cpp_codegen_multiply(((float)(L_314/((float)L_317))), L_320));
			goto IL_0b89;
		}
		G_B91_0 = ((float)il2cpp_codegen_multiply(((float)(L_314/((float)L_317))), L_320));
	}
	{
		G_B93_0 = (0.100000001f);
		G_B93_1 = G_B91_0;
		goto IL_0b8e;
	}

IL_0b89:
	{
		G_B93_0 = (1.0f);
		G_B93_1 = G_B92_0;
	}

IL_0b8e:
	{
		V_114 = ((float)il2cpp_codegen_multiply(G_B93_1, G_B93_0));
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_323 = __this->___m_CurrentFontAsset;
		NullCheck(L_323);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_324 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_323->___m_FaceInfo);
		float L_325;
		L_325 = FaceInfo_get_ascentLine_m193755D649428EC24A7E433A1728F11DA7547ABD(L_324, NULL);
		SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* L_326 = V_108;
		NullCheck(L_326);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_327 = ((TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA*)L_326)->___m_Glyph;
		NullCheck(L_327);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_328;
		L_328 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_327, NULL);
		V_116 = L_328;
		float L_329;
		L_329 = GlyphMetrics_get_height_mE0872B23CE1A20BF78DEACDBD53BAF789D84AD5C((&V_116), NULL);
		SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* L_330 = V_108;
		NullCheck(L_330);
		float L_331 = ((TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA*)L_330)->___m_Scale;
		SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* L_332 = V_108;
		NullCheck(L_332);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_333 = ((TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA*)L_332)->___m_Glyph;
		NullCheck(L_333);
		float L_334;
		L_334 = Glyph_get_scale_m3ED738CBB032247526DB38161E180759B2D06F29(L_333, NULL);
		float L_335 = V_114;
		V_2 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)(L_325/L_329)), L_331)), L_334)), L_335));
		float L_336 = V_114;
		float L_337 = V_2;
		V_115 = ((float)(L_336/L_337));
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_338 = __this->___m_CurrentFontAsset;
		NullCheck(L_338);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_339 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_338->___m_FaceInfo);
		float L_340;
		L_340 = FaceInfo_get_ascentLine_m193755D649428EC24A7E433A1728F11DA7547ABD(L_339, NULL);
		float L_341 = V_115;
		V_68 = ((float)il2cpp_codegen_multiply(L_340, L_341));
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_342 = __this->___m_CurrentFontAsset;
		NullCheck(L_342);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_343 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_342->___m_FaceInfo);
		float L_344;
		L_344 = FaceInfo_get_baseline_m934B597D3E0080FEF98CBDD091C457B497179C3A(L_343, NULL);
		float L_345 = V_109;
		float L_346 = __this->___m_FontScaleMultiplier;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_347 = __this->___m_CurrentFontAsset;
		NullCheck(L_347);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_348 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_347->___m_FaceInfo);
		float L_349;
		L_349 = FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD(L_348, NULL);
		V_67 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(L_344, L_345)), L_346)), L_349));
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_350 = __this->___m_CurrentFontAsset;
		NullCheck(L_350);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_351 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_350->___m_FaceInfo);
		float L_352;
		L_352 = FaceInfo_get_descentLine_m811A243C9B328B0C546BF9927A010A05DF172BD3(L_351, NULL);
		float L_353 = V_115;
		V_69 = ((float)il2cpp_codegen_multiply(L_352, L_353));
	}

IL_0c2e:
	{
		SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* L_354 = V_108;
		__this->___m_CachedTextElement = L_354;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CachedTextElement), (void*)L_354);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_355 = ___1_textInfo;
		NullCheck(L_355);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_356 = L_355->___textElementInfo;
		int32_t L_357 = __this->___m_CharacterCount;
		NullCheck(L_356);
		((L_356)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_357)))->___elementType = 2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_358 = ___1_textInfo;
		NullCheck(L_358);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_359 = L_358->___textElementInfo;
		int32_t L_360 = __this->___m_CharacterCount;
		NullCheck(L_359);
		float L_361 = V_2;
		((L_359)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_360)))->___scale = L_361;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_362 = ___1_textInfo;
		NullCheck(L_362);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_363 = L_362->___textElementInfo;
		int32_t L_364 = __this->___m_CharacterCount;
		NullCheck(L_363);
		SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* L_365 = __this->___m_CurrentSpriteAsset;
		((L_363)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_364)))->___spriteAsset = L_365;
		Il2CppCodeGenWriteBarrier((void**)(&((L_363)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_364)))->___spriteAsset), (void*)L_365);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_366 = ___1_textInfo;
		NullCheck(L_366);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_367 = L_366->___textElementInfo;
		int32_t L_368 = __this->___m_CharacterCount;
		NullCheck(L_367);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_369 = __this->___m_CurrentFontAsset;
		((L_367)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_368)))->___fontAsset = L_369;
		Il2CppCodeGenWriteBarrier((void**)(&((L_367)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_368)))->___fontAsset), (void*)L_369);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_370 = ___1_textInfo;
		NullCheck(L_370);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_371 = L_370->___textElementInfo;
		int32_t L_372 = __this->___m_CharacterCount;
		NullCheck(L_371);
		int32_t L_373 = __this->___m_CurrentMaterialIndex;
		((L_371)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_372)))->___materialReferenceIndex = L_373;
		int32_t L_374 = V_63;
		__this->___m_CurrentMaterialIndex = L_374;
		V_6 = (0.0f);
		goto IL_0f0c;
	}

IL_0ccd:
	{
		uint8_t L_375 = __this->___m_TextElementType;
		V_117 = (bool)((((int32_t)L_375) == ((int32_t)1))? 1 : 0);
		bool L_376 = V_117;
		if (!L_376)
		{
			goto IL_0f0c;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_377 = ___1_textInfo;
		NullCheck(L_377);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_378 = L_377->___textElementInfo;
		int32_t L_379 = __this->___m_CharacterCount;
		NullCheck(L_378);
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_380 = ((L_378)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_379)))->___textElement;
		__this->___m_CachedTextElement = L_380;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CachedTextElement), (void*)L_380);
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_381 = __this->___m_CachedTextElement;
		V_119 = (bool)((((RuntimeObject*)(TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA*)L_381) == ((RuntimeObject*)(RuntimeObject*)NULL))? 1 : 0);
		bool L_382 = V_119;
		if (!L_382)
		{
			goto IL_0d11;
		}
	}
	{
		goto IL_43d7;
	}

IL_0d11:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_383 = ___1_textInfo;
		NullCheck(L_383);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_384 = L_383->___textElementInfo;
		int32_t L_385 = __this->___m_CharacterCount;
		NullCheck(L_384);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_386 = ((L_384)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_385)))->___fontAsset;
		__this->___m_CurrentFontAsset = L_386;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CurrentFontAsset), (void*)L_386);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_387 = ___1_textInfo;
		NullCheck(L_387);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_388 = L_387->___textElementInfo;
		int32_t L_389 = __this->___m_CharacterCount;
		NullCheck(L_388);
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_390 = ((L_388)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_389)))->___material;
		__this->___m_CurrentMaterial = L_390;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CurrentMaterial), (void*)L_390);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_391 = ___1_textInfo;
		NullCheck(L_391);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_392 = L_391->___textElementInfo;
		int32_t L_393 = __this->___m_CharacterCount;
		NullCheck(L_392);
		int32_t L_394 = ((L_392)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_393)))->___materialReferenceIndex;
		__this->___m_CurrentMaterialIndex = L_394;
		bool L_395 = V_65;
		if (!L_395)
		{
			goto IL_0d92;
		}
	}
	{
		TextProcessingElementU5BU5D_t24A1E4C8745577D794FE856B4236875595E7FD22* L_396 = __this->___m_TextProcessingArray;
		int32_t L_397 = V_62;
		NullCheck(L_396);
		uint32_t L_398 = ((L_396)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_397)))->___unicode;
		if ((!(((uint32_t)L_398) == ((uint32_t)((int32_t)10)))))
		{
			goto IL_0d92;
		}
	}
	{
		int32_t L_399 = __this->___m_CharacterCount;
		int32_t L_400 = __this->___m_FirstCharacterOfLine;
		G_B102_0 = ((((int32_t)((((int32_t)L_399) == ((int32_t)L_400))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_0d93;
	}

IL_0d92:
	{
		G_B102_0 = 0;
	}

IL_0d93:
	{
		V_120 = (bool)G_B102_0;
		bool L_401 = V_120;
		if (!L_401)
		{
			goto IL_0df0;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_402 = ___1_textInfo;
		NullCheck(L_402);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_403 = L_402->___textElementInfo;
		int32_t L_404 = __this->___m_CharacterCount;
		NullCheck(L_403);
		float L_405 = ((L_403)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_404, 1)))))->___pointSize;
		float L_406 = V_66;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_407 = __this->___m_CurrentFontAsset;
		NullCheck(L_407);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_408 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_407->___m_FaceInfo);
		int32_t L_409;
		L_409 = FaceInfo_get_pointSize_m7EF7429A4725AB715931A220F6BB498C3D6BF7CB(L_408, NULL);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_410 = __this->___m_CurrentFontAsset;
		NullCheck(L_410);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_411 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_410->___m_FaceInfo);
		float L_412;
		L_412 = FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD(L_411, NULL);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_413 = ___0_generationSettings;
		NullCheck(L_413);
		bool L_414 = L_413->___isOrthographic;
		if (L_414)
		{
			G_B105_0 = ((float)il2cpp_codegen_multiply(((float)(((float)il2cpp_codegen_multiply(L_405, L_406))/((float)L_409))), L_412));
			goto IL_0de6;
		}
		G_B104_0 = ((float)il2cpp_codegen_multiply(((float)(((float)il2cpp_codegen_multiply(L_405, L_406))/((float)L_409))), L_412));
	}
	{
		G_B106_0 = (0.100000001f);
		G_B106_1 = G_B104_0;
		goto IL_0deb;
	}

IL_0de6:
	{
		G_B106_0 = (1.0f);
		G_B106_1 = G_B105_0;
	}

IL_0deb:
	{
		V_118 = ((float)il2cpp_codegen_multiply(G_B106_1, G_B106_0));
		goto IL_0e33;
	}

IL_0df0:
	{
		float L_415 = __this->___m_CurrentFontSize;
		float L_416 = V_66;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_417 = __this->___m_CurrentFontAsset;
		NullCheck(L_417);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_418 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_417->___m_FaceInfo);
		int32_t L_419;
		L_419 = FaceInfo_get_pointSize_m7EF7429A4725AB715931A220F6BB498C3D6BF7CB(L_418, NULL);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_420 = __this->___m_CurrentFontAsset;
		NullCheck(L_420);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_421 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_420->___m_FaceInfo);
		float L_422;
		L_422 = FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD(L_421, NULL);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_423 = ___0_generationSettings;
		NullCheck(L_423);
		bool L_424 = L_423->___isOrthographic;
		if (L_424)
		{
			G_B109_0 = ((float)il2cpp_codegen_multiply(((float)(((float)il2cpp_codegen_multiply(L_415, L_416))/((float)L_419))), L_422));
			goto IL_0e2b;
		}
		G_B108_0 = ((float)il2cpp_codegen_multiply(((float)(((float)il2cpp_codegen_multiply(L_415, L_416))/((float)L_419))), L_422));
	}
	{
		G_B110_0 = (0.100000001f);
		G_B110_1 = G_B108_0;
		goto IL_0e30;
	}

IL_0e2b:
	{
		G_B110_0 = (1.0f);
		G_B110_1 = G_B109_0;
	}

IL_0e30:
	{
		V_118 = ((float)il2cpp_codegen_multiply(G_B110_1, G_B110_0));
	}

IL_0e33:
	{
		bool L_425 = V_65;
		if (!L_425)
		{
			goto IL_0e42;
		}
	}
	{
		uint32_t L_426 = V_5;
		G_B114_0 = ((((int32_t)L_426) == ((int32_t)((int32_t)8230)))? 1 : 0);
		goto IL_0e43;
	}

IL_0e42:
	{
		G_B114_0 = 0;
	}

IL_0e43:
	{
		V_121 = (bool)G_B114_0;
		bool L_427 = V_121;
		if (!L_427)
		{
			goto IL_0e5b;
		}
	}
	{
		V_68 = (0.0f);
		V_69 = (0.0f);
		goto IL_0e81;
	}

IL_0e5b:
	{
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_428 = __this->___m_CurrentFontAsset;
		NullCheck(L_428);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_429 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_428->___m_FaceInfo);
		float L_430;
		L_430 = FaceInfo_get_ascentLine_m193755D649428EC24A7E433A1728F11DA7547ABD(L_429, NULL);
		V_68 = L_430;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_431 = __this->___m_CurrentFontAsset;
		NullCheck(L_431);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_432 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_431->___m_FaceInfo);
		float L_433;
		L_433 = FaceInfo_get_descentLine_m811A243C9B328B0C546BF9927A010A05DF172BD3(L_432, NULL);
		V_69 = L_433;
	}

IL_0e81:
	{
		float L_434 = V_118;
		float L_435 = __this->___m_FontScaleMultiplier;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_436 = __this->___m_CachedTextElement;
		NullCheck(L_436);
		float L_437 = L_436->___m_Scale;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_438 = __this->___m_CachedTextElement;
		NullCheck(L_438);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_439 = L_438->___m_Glyph;
		NullCheck(L_439);
		float L_440;
		L_440 = Glyph_get_scale_m3ED738CBB032247526DB38161E180759B2D06F29(L_439, NULL);
		V_2 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(L_434, L_435)), L_437)), L_440));
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_441 = __this->___m_CurrentFontAsset;
		NullCheck(L_441);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_442 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_441->___m_FaceInfo);
		float L_443;
		L_443 = FaceInfo_get_baseline_m934B597D3E0080FEF98CBDD091C457B497179C3A(L_442, NULL);
		float L_444 = V_118;
		float L_445 = __this->___m_FontScaleMultiplier;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_446 = __this->___m_CurrentFontAsset;
		NullCheck(L_446);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_447 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_446->___m_FaceInfo);
		float L_448;
		L_448 = FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD(L_447, NULL);
		V_67 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(L_443, L_444)), L_445)), L_448));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_449 = ___1_textInfo;
		NullCheck(L_449);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_450 = L_449->___textElementInfo;
		int32_t L_451 = __this->___m_CharacterCount;
		NullCheck(L_450);
		((L_450)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_451)))->___elementType = 1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_452 = ___1_textInfo;
		NullCheck(L_452);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_453 = L_452->___textElementInfo;
		int32_t L_454 = __this->___m_CharacterCount;
		NullCheck(L_453);
		float L_455 = V_2;
		((L_453)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_454)))->___scale = L_455;
		float L_456 = __this->___m_Padding;
		V_6 = L_456;
	}

IL_0f0c:
	{
		float L_457 = V_2;
		V_70 = L_457;
		uint32_t L_458 = V_5;
		if ((((int32_t)L_458) == ((int32_t)((int32_t)173))))
		{
			goto IL_0f1f;
		}
	}
	{
		uint32_t L_459 = V_5;
		G_B121_0 = ((((int32_t)L_459) == ((int32_t)3))? 1 : 0);
		goto IL_0f20;
	}

IL_0f1f:
	{
		G_B121_0 = 1;
	}

IL_0f20:
	{
		V_122 = (bool)G_B121_0;
		bool L_460 = V_122;
		if (!L_460)
		{
			goto IL_0f2c;
		}
	}
	{
		V_2 = (0.0f);
	}

IL_0f2c:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_461 = ___1_textInfo;
		NullCheck(L_461);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_462 = L_461->___textElementInfo;
		int32_t L_463 = __this->___m_CharacterCount;
		NullCheck(L_462);
		uint32_t L_464 = V_5;
		((L_462)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_463)))->___character = ((int32_t)(uint16_t)L_464);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_465 = ___1_textInfo;
		NullCheck(L_465);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_466 = L_465->___textElementInfo;
		int32_t L_467 = __this->___m_CharacterCount;
		NullCheck(L_466);
		float L_468 = __this->___m_CurrentFontSize;
		((L_466)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_467)))->___pointSize = L_468;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_469 = ___1_textInfo;
		NullCheck(L_469);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_470 = L_469->___textElementInfo;
		int32_t L_471 = __this->___m_CharacterCount;
		NullCheck(L_470);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_472 = __this->___m_HtmlColor;
		((L_470)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_471)))->___color = L_472;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_473 = ___1_textInfo;
		NullCheck(L_473);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_474 = L_473->___textElementInfo;
		int32_t L_475 = __this->___m_CharacterCount;
		NullCheck(L_474);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_476 = __this->___m_UnderlineColor;
		((L_474)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_475)))->___underlineColor = L_476;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_477 = ___1_textInfo;
		NullCheck(L_477);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_478 = L_477->___textElementInfo;
		int32_t L_479 = __this->___m_CharacterCount;
		NullCheck(L_478);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_480 = __this->___m_StrikethroughColor;
		((L_478)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_479)))->___strikethroughColor = L_480;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_481 = ___1_textInfo;
		NullCheck(L_481);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_482 = L_481->___textElementInfo;
		int32_t L_483 = __this->___m_CharacterCount;
		NullCheck(L_482);
		HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 L_484 = __this->___m_HighlightState;
		((L_482)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_483)))->___highlightState = L_484;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_485 = ___1_textInfo;
		NullCheck(L_485);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_486 = L_485->___textElementInfo;
		int32_t L_487 = __this->___m_CharacterCount;
		NullCheck(L_486);
		int32_t L_488 = __this->___m_FontStyleInternal;
		((L_486)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_487)))->___style = L_488;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_489 = ___1_textInfo;
		NullCheck(L_489);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_490 = L_489->___textElementInfo;
		int32_t L_491 = __this->___m_CharacterCount;
		NullCheck(L_490);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_492 = ((L_490)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_491)))->___alternativeGlyph;
		V_71 = L_492;
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_493 = V_71;
		if (!L_493)
		{
			goto IL_1012;
		}
	}
	{
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_494 = V_71;
		NullCheck(L_494);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_495;
		L_495 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_494, NULL);
		G_B126_0 = L_495;
		goto IL_1022;
	}

IL_1012:
	{
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_496 = __this->___m_CachedTextElement;
		NullCheck(L_496);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_497 = L_496->___m_Glyph;
		NullCheck(L_497);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_498;
		L_498 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_497, NULL);
		G_B126_0 = L_498;
	}

IL_1022:
	{
		V_72 = G_B126_0;
		uint32_t L_499 = V_5;
		if ((!(((uint32_t)L_499) <= ((uint32_t)((int32_t)65535)))))
		{
			goto IL_1037;
		}
	}
	{
		uint32_t L_500 = V_5;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_501;
		L_501 = Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924(((int32_t)(uint16_t)L_500), NULL);
		G_B129_0 = ((int32_t)(L_501));
		goto IL_1038;
	}

IL_1037:
	{
		G_B129_0 = 0;
	}

IL_1038:
	{
		V_73 = (bool)G_B129_0;
		il2cpp_codegen_initobj((&V_74), sizeof(GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_502 = ___0_generationSettings;
		NullCheck(L_502);
		float L_503 = L_502->___characterSpacing;
		V_75 = L_503;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_504 = ___0_generationSettings;
		NullCheck(L_504);
		bool L_505 = L_504->___enableKerning;
		V_123 = L_505;
		bool L_506 = V_123;
		if (!L_506)
		{
			goto IL_118f;
		}
	}
	{
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_507 = __this->___m_CachedTextElement;
		NullCheck(L_507);
		uint32_t L_508 = L_507->___m_GlyphIndex;
		V_125 = L_508;
		int32_t L_509 = __this->___m_CharacterCount;
		int32_t L_510 = V_0;
		V_126 = (bool)((((int32_t)L_509) < ((int32_t)((int32_t)il2cpp_codegen_subtract(L_510, 1))))? 1 : 0);
		bool L_511 = V_126;
		if (!L_511)
		{
			goto IL_10f5;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_512 = ___1_textInfo;
		NullCheck(L_512);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_513 = L_512->___textElementInfo;
		int32_t L_514 = __this->___m_CharacterCount;
		NullCheck(L_513);
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_515 = ((L_513)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_514, 1)))))->___textElement;
		NullCheck(L_515);
		uint32_t L_516 = L_515->___m_GlyphIndex;
		V_127 = L_516;
		uint32_t L_517 = V_127;
		uint32_t L_518 = V_125;
		V_128 = ((int32_t)(((int32_t)((int32_t)L_517<<((int32_t)16)))|(int32_t)L_518));
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_519 = __this->___m_CurrentFontAsset;
		NullCheck(L_519);
		FontFeatureTable_t992E0493CD7E9D7834DF204E0198237F0D25B3B7* L_520 = L_519->___m_FontFeatureTable;
		NullCheck(L_520);
		Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0* L_521 = L_520->___m_GlyphPairAdjustmentRecordLookup;
		uint32_t L_522 = V_128;
		NullCheck(L_521);
		bool L_523;
		L_523 = Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA(L_521, L_522, (&V_124), Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA_RuntimeMethod_var);
		V_129 = L_523;
		bool L_524 = V_129;
		if (!L_524)
		{
			goto IL_10f4;
		}
	}
	{
		GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 L_525;
		L_525 = GlyphPairAdjustmentRecord_get_firstAdjustmentRecord_m867469548F17B298F893B78EE2F93D34E4A6C39C((&V_124), NULL);
		V_130 = L_525;
		GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E L_526;
		L_526 = GlyphAdjustmentRecord_get_glyphValueRecord_m83866DCE07A22F903D4BA417476E64114625BDD7((&V_130), NULL);
		V_74 = L_526;
		int32_t L_527;
		L_527 = GlyphPairAdjustmentRecord_get_featureLookupFlags_m08DA76766FDE949068B881DBEA29955C9C43E8A9((&V_124), NULL);
		if ((((int32_t)((int32_t)((int32_t)L_527&((int32_t)256)))) == ((int32_t)((int32_t)256))))
		{
			goto IL_10ec;
		}
	}
	{
		float L_528 = V_75;
		G_B135_0 = L_528;
		goto IL_10f1;
	}

IL_10ec:
	{
		G_B135_0 = (0.0f);
	}

IL_10f1:
	{
		V_75 = G_B135_0;
	}

IL_10f4:
	{
	}

IL_10f5:
	{
		int32_t L_529 = __this->___m_CharacterCount;
		V_131 = (bool)((((int32_t)((((int32_t)L_529) < ((int32_t)1))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_530 = V_131;
		if (!L_530)
		{
			goto IL_118e;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_531 = ___1_textInfo;
		NullCheck(L_531);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_532 = L_531->___textElementInfo;
		int32_t L_533 = __this->___m_CharacterCount;
		NullCheck(L_532);
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_534 = ((L_532)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_533, 1)))))->___textElement;
		NullCheck(L_534);
		uint32_t L_535 = L_534->___m_GlyphIndex;
		V_132 = L_535;
		uint32_t L_536 = V_125;
		uint32_t L_537 = V_132;
		V_133 = ((int32_t)(((int32_t)((int32_t)L_536<<((int32_t)16)))|(int32_t)L_537));
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_538 = __this->___m_CurrentFontAsset;
		NullCheck(L_538);
		FontFeatureTable_t992E0493CD7E9D7834DF204E0198237F0D25B3B7* L_539 = L_538->___m_FontFeatureTable;
		NullCheck(L_539);
		Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0* L_540 = L_539->___m_GlyphPairAdjustmentRecordLookup;
		uint32_t L_541 = V_133;
		NullCheck(L_540);
		bool L_542;
		L_542 = Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA(L_540, L_541, (&V_124), Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA_RuntimeMethod_var);
		V_134 = L_542;
		bool L_543 = V_134;
		if (!L_543)
		{
			goto IL_118d;
		}
	}
	{
		GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E L_544 = V_74;
		GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 L_545;
		L_545 = GlyphPairAdjustmentRecord_get_secondAdjustmentRecord_mFDFECB1F7A38E22BD2388FFE9C71E732F6B44D91((&V_124), NULL);
		V_130 = L_545;
		GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E L_546;
		L_546 = GlyphAdjustmentRecord_get_glyphValueRecord_m83866DCE07A22F903D4BA417476E64114625BDD7((&V_130), NULL);
		GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E L_547;
		L_547 = GlyphValueRecord_op_Addition_mF26165B4CE61A5409AEFF24B0D1727804E13602B(L_544, L_546, NULL);
		V_74 = L_547;
		int32_t L_548;
		L_548 = GlyphPairAdjustmentRecord_get_featureLookupFlags_m08DA76766FDE949068B881DBEA29955C9C43E8A9((&V_124), NULL);
		if ((((int32_t)((int32_t)((int32_t)L_548&((int32_t)256)))) == ((int32_t)((int32_t)256))))
		{
			goto IL_1185;
		}
	}
	{
		float L_549 = V_75;
		G_B142_0 = L_549;
		goto IL_118a;
	}

IL_1185:
	{
		G_B142_0 = (0.0f);
	}

IL_118a:
	{
		V_75 = G_B142_0;
	}

IL_118d:
	{
	}

IL_118e:
	{
	}

IL_118f:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_550 = ___1_textInfo;
		NullCheck(L_550);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_551 = L_550->___textElementInfo;
		int32_t L_552 = __this->___m_CharacterCount;
		NullCheck(L_551);
		float L_553;
		L_553 = GlyphValueRecord_get_xAdvance_m6C392027FA91E0705C1585C5EF40D984AAA0013E((&V_74), NULL);
		((L_551)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_552)))->___adjustedHorizontalAdvance = L_553;
		uint32_t L_554 = V_5;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		bool L_555;
		L_555 = TextGeneratorUtilities_IsBaseGlyph_mEE0E7D6C3FB32204C2299FBA2B9F7C51E06F80FE(L_554, NULL);
		V_76 = L_555;
		bool L_556 = V_76;
		V_135 = L_556;
		bool L_557 = V_135;
		if (!L_557)
		{
			goto IL_11c9;
		}
	}
	{
		int32_t L_558 = __this->___m_CharacterCount;
		__this->___m_LastBaseGlyphIndex = L_558;
	}

IL_11c9:
	{
		int32_t L_559 = __this->___m_CharacterCount;
		if ((((int32_t)L_559) <= ((int32_t)0)))
		{
			goto IL_11d9;
		}
	}
	{
		bool L_560 = V_76;
		G_B150_0 = ((((int32_t)L_560) == ((int32_t)0))? 1 : 0);
		goto IL_11da;
	}

IL_11d9:
	{
		G_B150_0 = 0;
	}

IL_11da:
	{
		V_136 = (bool)G_B150_0;
		bool L_561 = V_136;
		if (!L_561)
		{
			goto IL_1531;
		}
	}
	{
		int32_t L_562 = __this->___m_LastBaseGlyphIndex;
		if ((((int32_t)L_562) == ((int32_t)((int32_t)-2147483648LL))))
		{
			goto IL_1203;
		}
	}
	{
		int32_t L_563 = __this->___m_LastBaseGlyphIndex;
		int32_t L_564 = __this->___m_CharacterCount;
		G_B154_0 = ((((int32_t)L_563) == ((int32_t)((int32_t)il2cpp_codegen_subtract(L_564, 1))))? 1 : 0);
		goto IL_1204;
	}

IL_1203:
	{
		G_B154_0 = 0;
	}

IL_1204:
	{
		V_137 = (bool)G_B154_0;
		bool L_565 = V_137;
		if (!L_565)
		{
			goto IL_12ef;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_566 = ___1_textInfo;
		NullCheck(L_566);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_567 = L_566->___textElementInfo;
		int32_t L_568 = __this->___m_LastBaseGlyphIndex;
		NullCheck(L_567);
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_569 = ((L_567)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_568)))->___textElement;
		NullCheck(L_569);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_570;
		L_570 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_569, NULL);
		V_138 = L_570;
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_571 = V_138;
		NullCheck(L_571);
		uint32_t L_572;
		L_572 = Glyph_get_index_mCFBBCF85E7F3434B7A595EEE3411EFFB78E5675B(L_571, NULL);
		V_139 = L_572;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_573 = __this->___m_CachedTextElement;
		NullCheck(L_573);
		uint32_t L_574;
		L_574 = TextElement_get_glyphIndex_m43F82F2F998D640DEDBE6860EBE7B171DDF4FE56(L_573, NULL);
		V_140 = L_574;
		uint32_t L_575 = V_140;
		uint32_t L_576 = V_139;
		V_141 = ((int32_t)(((int32_t)((int32_t)L_575<<((int32_t)16)))|(int32_t)L_576));
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_577 = __this->___m_CurrentFontAsset;
		NullCheck(L_577);
		FontFeatureTable_t992E0493CD7E9D7834DF204E0198237F0D25B3B7* L_578;
		L_578 = FontAsset_get_fontFeatureTable_m7C4EB9A655B237CE02FAF7B8B16C2F2863FE5070(L_577, NULL);
		NullCheck(L_578);
		Dictionary_2_tC58BED428F0C45B2320DCA085F781540D1CC3A26* L_579 = L_578->___m_MarkToBaseAdjustmentRecordLookup;
		uint32_t L_580 = V_141;
		NullCheck(L_579);
		bool L_581;
		L_581 = Dictionary_2_TryGetValue_mF32BD44799A9D5626676B55AEE98449663C70D33(L_579, L_580, (&V_142), Dictionary_2_TryGetValue_mF32BD44799A9D5626676B55AEE98449663C70D33_RuntimeMethod_var);
		V_143 = L_581;
		bool L_582 = V_143;
		if (!L_582)
		{
			goto IL_12e9;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_583 = ___1_textInfo;
		NullCheck(L_583);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_584 = L_583->___textElementInfo;
		int32_t L_585 = __this->___m_LastBaseGlyphIndex;
		NullCheck(L_584);
		float L_586 = ((L_584)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_585)))->___origin;
		float L_587 = __this->___m_XAdvance;
		float L_588 = V_2;
		V_144 = ((float)(((float)il2cpp_codegen_subtract(L_586, L_587))/L_588));
		float L_589 = V_144;
		GlyphAnchorPoint_t581FDCAD5A1D0F3B129968FAEF20C113AAB0BC08 L_590;
		L_590 = MarkToBaseAdjustmentRecord_get_baseGlyphAnchorPoint_mCBF57932B7A89C532B0EF750DFD81F8FE389EE08((&V_142), NULL);
		V_145 = L_590;
		float L_591;
		L_591 = GlyphAnchorPoint_get_xCoordinate_mCD33464763911ECB78DEB1965970A916FA27DD1C((&V_145), NULL);
		MarkPositionAdjustment_t2523798D56F14A93A080D9D1298498325A51F436 L_592;
		L_592 = MarkToBaseAdjustmentRecord_get_markPositionAdjustment_m570715D1D0F84361A90564D4A958394453E1F9AB((&V_142), NULL);
		V_146 = L_592;
		float L_593;
		L_593 = MarkPositionAdjustment_get_xPositionAdjustment_m5ACBB4C515357320C12597CAE5E4D409BA298765((&V_146), NULL);
		GlyphValueRecord_set_xPlacement_m79F92029922BDE50ED63A6A03EBE478869F1CCFC((&V_74), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_589, L_591)), L_593)), NULL);
		GlyphAnchorPoint_t581FDCAD5A1D0F3B129968FAEF20C113AAB0BC08 L_594;
		L_594 = MarkToBaseAdjustmentRecord_get_baseGlyphAnchorPoint_mCBF57932B7A89C532B0EF750DFD81F8FE389EE08((&V_142), NULL);
		V_145 = L_594;
		float L_595;
		L_595 = GlyphAnchorPoint_get_yCoordinate_m2683C19C6A3D750E4D6C536307313E55589909D6((&V_145), NULL);
		MarkPositionAdjustment_t2523798D56F14A93A080D9D1298498325A51F436 L_596;
		L_596 = MarkToBaseAdjustmentRecord_get_markPositionAdjustment_m570715D1D0F84361A90564D4A958394453E1F9AB((&V_142), NULL);
		V_146 = L_596;
		float L_597;
		L_597 = MarkPositionAdjustment_get_yPositionAdjustment_m1F5F7DBBFEB0B52CCC772F68664D06B11D6A9F2C((&V_146), NULL);
		GlyphValueRecord_set_yPlacement_m04DA300FAB827A708CB291DA3B2EA3128279CA2B((&V_74), ((float)il2cpp_codegen_subtract(L_595, L_597)), NULL);
		V_75 = (0.0f);
	}

IL_12e9:
	{
		goto IL_1530;
	}

IL_12ef:
	{
		V_147 = (bool)0;
		int32_t L_598 = __this->___m_CharacterCount;
		V_148 = ((int32_t)il2cpp_codegen_subtract(L_598, 1));
		goto IL_1416;
	}

IL_1302:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_599 = ___1_textInfo;
		NullCheck(L_599);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_600 = L_599->___textElementInfo;
		int32_t L_601 = V_148;
		NullCheck(L_600);
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_602 = ((L_600)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_601)))->___textElement;
		NullCheck(L_602);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_603;
		L_603 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_602, NULL);
		V_149 = L_603;
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_604 = V_149;
		NullCheck(L_604);
		uint32_t L_605;
		L_605 = Glyph_get_index_mCFBBCF85E7F3434B7A595EEE3411EFFB78E5675B(L_604, NULL);
		V_150 = L_605;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_606 = __this->___m_CachedTextElement;
		NullCheck(L_606);
		uint32_t L_607;
		L_607 = TextElement_get_glyphIndex_m43F82F2F998D640DEDBE6860EBE7B171DDF4FE56(L_606, NULL);
		V_151 = L_607;
		uint32_t L_608 = V_151;
		uint32_t L_609 = V_150;
		V_152 = ((int32_t)(((int32_t)((int32_t)L_608<<((int32_t)16)))|(int32_t)L_609));
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_610 = __this->___m_CurrentFontAsset;
		NullCheck(L_610);
		FontFeatureTable_t992E0493CD7E9D7834DF204E0198237F0D25B3B7* L_611;
		L_611 = FontAsset_get_fontFeatureTable_m7C4EB9A655B237CE02FAF7B8B16C2F2863FE5070(L_610, NULL);
		NullCheck(L_611);
		Dictionary_2_t3B281EAA0FCAF1D0DED857932C74644D3F02E6D0* L_612 = L_611->___m_MarkToMarkAdjustmentRecordLookup;
		uint32_t L_613 = V_152;
		NullCheck(L_612);
		bool L_614;
		L_614 = Dictionary_2_TryGetValue_mE41304D9F16D4065AEA94463AE53A68A4F4F6395(L_612, L_613, (&V_153), Dictionary_2_TryGetValue_mE41304D9F16D4065AEA94463AE53A68A4F4F6395_RuntimeMethod_var);
		V_154 = L_614;
		bool L_615 = V_154;
		if (!L_615)
		{
			goto IL_140b;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_616 = ___1_textInfo;
		NullCheck(L_616);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_617 = L_616->___textElementInfo;
		int32_t L_618 = V_148;
		NullCheck(L_617);
		float L_619 = ((L_617)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_618)))->___origin;
		float L_620 = __this->___m_XAdvance;
		float L_621 = V_2;
		V_155 = ((float)(((float)il2cpp_codegen_subtract(L_619, L_620))/L_621));
		float L_622 = V_67;
		float L_623 = __this->___m_LineOffset;
		float L_624 = __this->___m_BaselineOffset;
		V_156 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(L_622, L_623)), L_624));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_625 = ___1_textInfo;
		NullCheck(L_625);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_626 = L_625->___textElementInfo;
		int32_t L_627 = V_148;
		NullCheck(L_626);
		float L_628 = ((L_626)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_627)))->___baseLine;
		float L_629 = V_156;
		float L_630 = V_2;
		V_157 = ((float)(((float)il2cpp_codegen_subtract(L_628, L_629))/L_630));
		float L_631 = V_155;
		GlyphAnchorPoint_t581FDCAD5A1D0F3B129968FAEF20C113AAB0BC08 L_632;
		L_632 = MarkToMarkAdjustmentRecord_get_baseMarkGlyphAnchorPoint_mB87ADA10491B42650BAD4DB7330771061827ACAB((&V_153), NULL);
		V_145 = L_632;
		float L_633;
		L_633 = GlyphAnchorPoint_get_xCoordinate_mCD33464763911ECB78DEB1965970A916FA27DD1C((&V_145), NULL);
		MarkPositionAdjustment_t2523798D56F14A93A080D9D1298498325A51F436 L_634;
		L_634 = MarkToMarkAdjustmentRecord_get_combiningMarkPositionAdjustment_mC109ECEDB4AD314A25C0EB1F6F6151AE611DE15C((&V_153), NULL);
		V_146 = L_634;
		float L_635;
		L_635 = MarkPositionAdjustment_get_xPositionAdjustment_m5ACBB4C515357320C12597CAE5E4D409BA298765((&V_146), NULL);
		GlyphValueRecord_set_xPlacement_m79F92029922BDE50ED63A6A03EBE478869F1CCFC((&V_74), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_631, L_633)), L_635)), NULL);
		float L_636 = V_157;
		GlyphAnchorPoint_t581FDCAD5A1D0F3B129968FAEF20C113AAB0BC08 L_637;
		L_637 = MarkToMarkAdjustmentRecord_get_baseMarkGlyphAnchorPoint_mB87ADA10491B42650BAD4DB7330771061827ACAB((&V_153), NULL);
		V_145 = L_637;
		float L_638;
		L_638 = GlyphAnchorPoint_get_yCoordinate_m2683C19C6A3D750E4D6C536307313E55589909D6((&V_145), NULL);
		MarkPositionAdjustment_t2523798D56F14A93A080D9D1298498325A51F436 L_639;
		L_639 = MarkToMarkAdjustmentRecord_get_combiningMarkPositionAdjustment_mC109ECEDB4AD314A25C0EB1F6F6151AE611DE15C((&V_153), NULL);
		V_146 = L_639;
		float L_640;
		L_640 = MarkPositionAdjustment_get_yPositionAdjustment_m1F5F7DBBFEB0B52CCC772F68664D06B11D6A9F2C((&V_146), NULL);
		GlyphValueRecord_set_yPlacement_m04DA300FAB827A708CB291DA3B2EA3128279CA2B((&V_74), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_636, L_638)), L_640)), NULL);
		V_75 = (0.0f);
		V_147 = (bool)1;
		goto IL_1434;
	}

IL_140b:
	{
		int32_t L_641 = V_148;
		V_158 = L_641;
		int32_t L_642 = V_158;
		V_148 = ((int32_t)il2cpp_codegen_subtract(L_642, 1));
	}

IL_1416:
	{
		int32_t L_643 = V_148;
		if ((((int32_t)L_643) < ((int32_t)0)))
		{
			goto IL_142a;
		}
	}
	{
		int32_t L_644 = V_148;
		int32_t L_645 = __this->___m_LastBaseGlyphIndex;
		G_B165_0 = ((((int32_t)((((int32_t)L_644) == ((int32_t)L_645))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_142b;
	}

IL_142a:
	{
		G_B165_0 = 0;
	}

IL_142b:
	{
		V_159 = (bool)G_B165_0;
		bool L_646 = V_159;
		if (L_646)
		{
			goto IL_1302;
		}
	}

IL_1434:
	{
		int32_t L_647 = __this->___m_LastBaseGlyphIndex;
		if ((((int32_t)L_647) == ((int32_t)((int32_t)-2147483648LL))))
		{
			goto IL_1448;
		}
	}
	{
		bool L_648 = V_147;
		G_B169_0 = ((((int32_t)L_648) == ((int32_t)0))? 1 : 0);
		goto IL_1449;
	}

IL_1448:
	{
		G_B169_0 = 0;
	}

IL_1449:
	{
		V_160 = (bool)G_B169_0;
		bool L_649 = V_160;
		if (!L_649)
		{
			goto IL_152f;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_650 = ___1_textInfo;
		NullCheck(L_650);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_651 = L_650->___textElementInfo;
		int32_t L_652 = __this->___m_LastBaseGlyphIndex;
		NullCheck(L_651);
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_653 = ((L_651)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_652)))->___textElement;
		NullCheck(L_653);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_654;
		L_654 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_653, NULL);
		V_161 = L_654;
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_655 = V_161;
		NullCheck(L_655);
		uint32_t L_656;
		L_656 = Glyph_get_index_mCFBBCF85E7F3434B7A595EEE3411EFFB78E5675B(L_655, NULL);
		V_162 = L_656;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_657 = __this->___m_CachedTextElement;
		NullCheck(L_657);
		uint32_t L_658;
		L_658 = TextElement_get_glyphIndex_m43F82F2F998D640DEDBE6860EBE7B171DDF4FE56(L_657, NULL);
		V_163 = L_658;
		uint32_t L_659 = V_163;
		uint32_t L_660 = V_162;
		V_164 = ((int32_t)(((int32_t)((int32_t)L_659<<((int32_t)16)))|(int32_t)L_660));
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_661 = __this->___m_CurrentFontAsset;
		NullCheck(L_661);
		FontFeatureTable_t992E0493CD7E9D7834DF204E0198237F0D25B3B7* L_662;
		L_662 = FontAsset_get_fontFeatureTable_m7C4EB9A655B237CE02FAF7B8B16C2F2863FE5070(L_661, NULL);
		NullCheck(L_662);
		Dictionary_2_tC58BED428F0C45B2320DCA085F781540D1CC3A26* L_663 = L_662->___m_MarkToBaseAdjustmentRecordLookup;
		uint32_t L_664 = V_164;
		NullCheck(L_663);
		bool L_665;
		L_665 = Dictionary_2_TryGetValue_mF32BD44799A9D5626676B55AEE98449663C70D33(L_663, L_664, (&V_165), Dictionary_2_TryGetValue_mF32BD44799A9D5626676B55AEE98449663C70D33_RuntimeMethod_var);
		V_166 = L_665;
		bool L_666 = V_166;
		if (!L_666)
		{
			goto IL_152e;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_667 = ___1_textInfo;
		NullCheck(L_667);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_668 = L_667->___textElementInfo;
		int32_t L_669 = __this->___m_LastBaseGlyphIndex;
		NullCheck(L_668);
		float L_670 = ((L_668)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_669)))->___origin;
		float L_671 = __this->___m_XAdvance;
		float L_672 = V_2;
		V_167 = ((float)(((float)il2cpp_codegen_subtract(L_670, L_671))/L_672));
		float L_673 = V_167;
		GlyphAnchorPoint_t581FDCAD5A1D0F3B129968FAEF20C113AAB0BC08 L_674;
		L_674 = MarkToBaseAdjustmentRecord_get_baseGlyphAnchorPoint_mCBF57932B7A89C532B0EF750DFD81F8FE389EE08((&V_165), NULL);
		V_145 = L_674;
		float L_675;
		L_675 = GlyphAnchorPoint_get_xCoordinate_mCD33464763911ECB78DEB1965970A916FA27DD1C((&V_145), NULL);
		MarkPositionAdjustment_t2523798D56F14A93A080D9D1298498325A51F436 L_676;
		L_676 = MarkToBaseAdjustmentRecord_get_markPositionAdjustment_m570715D1D0F84361A90564D4A958394453E1F9AB((&V_165), NULL);
		V_146 = L_676;
		float L_677;
		L_677 = MarkPositionAdjustment_get_xPositionAdjustment_m5ACBB4C515357320C12597CAE5E4D409BA298765((&V_146), NULL);
		GlyphValueRecord_set_xPlacement_m79F92029922BDE50ED63A6A03EBE478869F1CCFC((&V_74), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_673, L_675)), L_677)), NULL);
		GlyphAnchorPoint_t581FDCAD5A1D0F3B129968FAEF20C113AAB0BC08 L_678;
		L_678 = MarkToBaseAdjustmentRecord_get_baseGlyphAnchorPoint_mCBF57932B7A89C532B0EF750DFD81F8FE389EE08((&V_165), NULL);
		V_145 = L_678;
		float L_679;
		L_679 = GlyphAnchorPoint_get_yCoordinate_m2683C19C6A3D750E4D6C536307313E55589909D6((&V_145), NULL);
		MarkPositionAdjustment_t2523798D56F14A93A080D9D1298498325A51F436 L_680;
		L_680 = MarkToBaseAdjustmentRecord_get_markPositionAdjustment_m570715D1D0F84361A90564D4A958394453E1F9AB((&V_165), NULL);
		V_146 = L_680;
		float L_681;
		L_681 = MarkPositionAdjustment_get_yPositionAdjustment_m1F5F7DBBFEB0B52CCC772F68664D06B11D6A9F2C((&V_146), NULL);
		GlyphValueRecord_set_yPlacement_m04DA300FAB827A708CB291DA3B2EA3128279CA2B((&V_74), ((float)il2cpp_codegen_subtract(L_679, L_681)), NULL);
		V_75 = (0.0f);
	}

IL_152e:
	{
	}

IL_152f:
	{
	}

IL_1530:
	{
	}

IL_1531:
	{
		float L_682 = V_68;
		float L_683;
		L_683 = GlyphValueRecord_get_yPlacement_mB6303F8800305F6F96ECCD0CD9AA70A1A30A15DA((&V_74), NULL);
		V_68 = ((float)il2cpp_codegen_add(L_682, L_683));
		float L_684 = V_69;
		float L_685;
		L_685 = GlyphValueRecord_get_yPlacement_mB6303F8800305F6F96ECCD0CD9AA70A1A30A15DA((&V_74), NULL);
		V_69 = ((float)il2cpp_codegen_add(L_684, L_685));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_686 = ___0_generationSettings;
		NullCheck(L_686);
		bool L_687 = L_686->___isRightToLeft;
		V_168 = L_687;
		bool L_688 = V_168;
		if (!L_688)
		{
			goto IL_15a5;
		}
	}
	{
		float L_689 = __this->___m_XAdvance;
		float L_690;
		L_690 = GlyphMetrics_get_horizontalAdvance_m110E66C340A19E672FB1C26DFB875AB6900AFFF1((&V_72), NULL);
		float L_691 = __this->___m_CharWidthAdjDelta;
		float L_692 = V_2;
		__this->___m_XAdvance = ((float)il2cpp_codegen_subtract(L_689, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(L_690, ((float)il2cpp_codegen_subtract((1.0f), L_691)))), L_692))));
		bool L_693 = V_73;
		if (L_693)
		{
			goto IL_1588;
		}
	}
	{
		uint32_t L_694 = V_5;
		G_B179_0 = ((((int32_t)L_694) == ((int32_t)((int32_t)8203)))? 1 : 0);
		goto IL_1589;
	}

IL_1588:
	{
		G_B179_0 = 1;
	}

IL_1589:
	{
		V_169 = (bool)G_B179_0;
		bool L_695 = V_169;
		if (!L_695)
		{
			goto IL_15a4;
		}
	}
	{
		float L_696 = __this->___m_XAdvance;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_697 = ___0_generationSettings;
		NullCheck(L_697);
		float L_698 = L_697->___wordSpacing;
		float L_699 = V_3;
		__this->___m_XAdvance = ((float)il2cpp_codegen_subtract(L_696, ((float)il2cpp_codegen_multiply(L_698, L_699))));
	}

IL_15a4:
	{
	}

IL_15a5:
	{
		V_77 = (0.0f);
		float L_700 = __this->___m_MonoSpacing;
		V_170 = (bool)((((int32_t)((((float)L_700) == ((float)(0.0f)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_701 = V_170;
		if (!L_701)
		{
			goto IL_1606;
		}
	}
	{
		float L_702 = __this->___m_MonoSpacing;
		float L_703;
		L_703 = GlyphMetrics_get_width_m0F9F391E3A98984167E8001D4101BE1CE9354D13((&V_72), NULL);
		float L_704;
		L_704 = GlyphMetrics_get_horizontalBearingX_m9C39B5E6D27FF34B706649AE47EE9390B5D76D6F((&V_72), NULL);
		float L_705 = V_2;
		float L_706 = __this->___m_CharWidthAdjDelta;
		V_77 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_subtract(((float)(L_702/(2.0f))), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)(L_703/(2.0f))), L_704)), L_705)))), ((float)il2cpp_codegen_subtract((1.0f), L_706))));
		float L_707 = __this->___m_XAdvance;
		float L_708 = V_77;
		__this->___m_XAdvance = ((float)il2cpp_codegen_add(L_707, L_708));
	}

IL_1606:
	{
		uint8_t L_709 = __this->___m_TextElementType;
		if ((!(((uint32_t)L_709) == ((uint32_t)1))))
		{
			goto IL_1620;
		}
	}
	{
		bool L_710 = V_64;
		if (L_710)
		{
			goto IL_1620;
		}
	}
	{
		int32_t L_711 = __this->___m_FontStyleInternal;
		G_B188_0 = ((((int32_t)((int32_t)((int32_t)L_711&1))) == ((int32_t)1))? 1 : 0);
		goto IL_1621;
	}

IL_1620:
	{
		G_B188_0 = 0;
	}

IL_1621:
	{
		V_171 = (bool)G_B188_0;
		bool L_712 = V_171;
		if (!L_712)
		{
			goto IL_16bf;
		}
	}
	{
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_713 = __this->___m_CurrentMaterial;
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		bool L_714;
		L_714 = Object_op_Inequality_mD0BE578448EAA61948F25C32F8DD55AB1F778602(L_713, (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C*)NULL, NULL);
		if (!L_714)
		{
			goto IL_164b;
		}
	}
	{
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_715 = __this->___m_CurrentMaterial;
		il2cpp_codegen_runtime_class_init_inline(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var);
		int32_t L_716 = ((TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields*)il2cpp_codegen_static_fields_for(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var))->___ID_GradientScale;
		NullCheck(L_715);
		bool L_717;
		L_717 = Material_HasProperty_m52E2D3BC3049B8B228149E023CD73C34B05A5222(L_715, L_716, NULL);
		G_B192_0 = ((int32_t)(L_717));
		goto IL_164c;
	}

IL_164b:
	{
		G_B192_0 = 0;
	}

IL_164c:
	{
		V_172 = (bool)G_B192_0;
		bool L_718 = V_172;
		if (!L_718)
		{
			goto IL_16a5;
		}
	}
	{
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_719 = __this->___m_CurrentMaterial;
		il2cpp_codegen_runtime_class_init_inline(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var);
		int32_t L_720 = ((TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields*)il2cpp_codegen_static_fields_for(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var))->___ID_GradientScale;
		NullCheck(L_719);
		float L_721;
		L_721 = Material_GetFloat_m52462F4AEDE20758BFB592B11DE83A79D2774932(L_719, L_720, NULL);
		V_173 = L_721;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_722 = __this->___m_CurrentFontAsset;
		NullCheck(L_722);
		float L_723;
		L_723 = FontAsset_get_boldStyleWeight_m804ACC85DD80DC72DB4BCC83C3FB866411F8EFCA(L_722, NULL);
		float L_724 = V_173;
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_725 = __this->___m_CurrentMaterial;
		int32_t L_726 = ((TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields*)il2cpp_codegen_static_fields_for(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var))->___ID_ScaleRatio_A;
		NullCheck(L_725);
		float L_727;
		L_727 = Material_GetFloat_m52462F4AEDE20758BFB592B11DE83A79D2774932(L_725, L_726, NULL);
		V_79 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)(L_723/(4.0f))), L_724)), L_727));
		float L_728 = V_79;
		float L_729 = V_6;
		float L_730 = V_173;
		V_174 = (bool)((((float)((float)il2cpp_codegen_add(L_728, L_729))) > ((float)L_730))? 1 : 0);
		bool L_731 = V_174;
		if (!L_731)
		{
			goto IL_16a2;
		}
	}
	{
		float L_732 = V_173;
		float L_733 = V_79;
		V_6 = ((float)il2cpp_codegen_subtract(L_732, L_733));
	}

IL_16a2:
	{
		goto IL_16ac;
	}

IL_16a5:
	{
		V_79 = (0.0f);
	}

IL_16ac:
	{
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_734 = __this->___m_CurrentFontAsset;
		NullCheck(L_734);
		float L_735;
		L_735 = FontAsset_get_boldStyleSpacing_mB8CF4F4880B110E41D566648FF1D995010CF1FF0(L_734, NULL);
		V_78 = L_735;
		goto IL_175b;
	}

IL_16bf:
	{
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_736 = __this->___m_CurrentMaterial;
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		bool L_737;
		L_737 = Object_op_Inequality_mD0BE578448EAA61948F25C32F8DD55AB1F778602(L_736, (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C*)NULL, NULL);
		if (!L_737)
		{
			goto IL_16f2;
		}
	}
	{
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_738 = __this->___m_CurrentMaterial;
		il2cpp_codegen_runtime_class_init_inline(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var);
		int32_t L_739 = ((TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields*)il2cpp_codegen_static_fields_for(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var))->___ID_GradientScale;
		NullCheck(L_738);
		bool L_740;
		L_740 = Material_HasProperty_m52E2D3BC3049B8B228149E023CD73C34B05A5222(L_738, L_739, NULL);
		if (!L_740)
		{
			goto IL_16f2;
		}
	}
	{
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_741 = __this->___m_CurrentMaterial;
		il2cpp_codegen_runtime_class_init_inline(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var);
		int32_t L_742 = ((TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields*)il2cpp_codegen_static_fields_for(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var))->___ID_ScaleRatio_A;
		NullCheck(L_741);
		bool L_743;
		L_743 = Material_HasProperty_m52E2D3BC3049B8B228149E023CD73C34B05A5222(L_741, L_742, NULL);
		G_B202_0 = ((int32_t)(L_743));
		goto IL_16f3;
	}

IL_16f2:
	{
		G_B202_0 = 0;
	}

IL_16f3:
	{
		V_175 = (bool)G_B202_0;
		bool L_744 = V_175;
		if (!L_744)
		{
			goto IL_174c;
		}
	}
	{
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_745 = __this->___m_CurrentMaterial;
		il2cpp_codegen_runtime_class_init_inline(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var);
		int32_t L_746 = ((TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields*)il2cpp_codegen_static_fields_for(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var))->___ID_GradientScale;
		NullCheck(L_745);
		float L_747;
		L_747 = Material_GetFloat_m52462F4AEDE20758BFB592B11DE83A79D2774932(L_745, L_746, NULL);
		V_176 = L_747;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_748 = __this->___m_CurrentFontAsset;
		NullCheck(L_748);
		float L_749 = L_748->___m_RegularStyleWeight;
		float L_750 = V_176;
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_751 = __this->___m_CurrentMaterial;
		int32_t L_752 = ((TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields*)il2cpp_codegen_static_fields_for(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var))->___ID_ScaleRatio_A;
		NullCheck(L_751);
		float L_753;
		L_753 = Material_GetFloat_m52462F4AEDE20758BFB592B11DE83A79D2774932(L_751, L_752, NULL);
		V_79 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)(L_749/(4.0f))), L_750)), L_753));
		float L_754 = V_79;
		float L_755 = V_6;
		float L_756 = V_176;
		V_177 = (bool)((((float)((float)il2cpp_codegen_add(L_754, L_755))) > ((float)L_756))? 1 : 0);
		bool L_757 = V_177;
		if (!L_757)
		{
			goto IL_1749;
		}
	}
	{
		float L_758 = V_176;
		float L_759 = V_79;
		V_6 = ((float)il2cpp_codegen_subtract(L_758, L_759));
	}

IL_1749:
	{
		goto IL_1753;
	}

IL_174c:
	{
		V_79 = (0.0f);
	}

IL_1753:
	{
		V_78 = (0.0f);
	}

IL_175b:
	{
		float L_760 = __this->___m_XAdvance;
		float L_761;
		L_761 = GlyphMetrics_get_horizontalBearingX_m9C39B5E6D27FF34B706649AE47EE9390B5D76D6F((&V_72), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_762 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&__this->___m_FXScale);
		float L_763 = L_762->___x;
		float L_764 = V_6;
		float L_765 = V_79;
		float L_766;
		L_766 = GlyphValueRecord_get_xPlacement_m5E2B8B05A5DF57B2DC4B3795E71330CDDE1761C8((&V_74), NULL);
		float L_767 = V_2;
		float L_768 = __this->___m_CharWidthAdjDelta;
		(&V_80)->___x = ((float)il2cpp_codegen_add(L_760, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_multiply(L_761, L_763)), L_764)), L_765)), L_766)), L_767)), ((float)il2cpp_codegen_subtract((1.0f), L_768))))));
		float L_769 = V_67;
		float L_770;
		L_770 = GlyphMetrics_get_horizontalBearingY_mD316BDD38A32258256994D6A2BCF0FC051D9B223((&V_72), NULL);
		float L_771 = V_6;
		float L_772;
		L_772 = GlyphValueRecord_get_yPlacement_mB6303F8800305F6F96ECCD0CD9AA70A1A30A15DA((&V_74), NULL);
		float L_773 = V_2;
		float L_774 = __this->___m_LineOffset;
		float L_775 = __this->___m_BaselineOffset;
		(&V_80)->___y = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_769, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_770, L_771)), L_772)), L_773)))), L_774)), L_775));
		(&V_80)->___z = (0.0f);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_776 = V_80;
		float L_777 = L_776.___x;
		(&V_81)->___x = L_777;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_778 = V_80;
		float L_779 = L_778.___y;
		float L_780;
		L_780 = GlyphMetrics_get_height_mE0872B23CE1A20BF78DEACDBD53BAF789D84AD5C((&V_72), NULL);
		float L_781 = V_6;
		float L_782 = V_2;
		(&V_81)->___y = ((float)il2cpp_codegen_subtract(L_779, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_780, ((float)il2cpp_codegen_multiply(L_781, (2.0f))))), L_782))));
		(&V_81)->___z = (0.0f);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_783 = V_81;
		float L_784 = L_783.___x;
		float L_785;
		L_785 = GlyphMetrics_get_width_m0F9F391E3A98984167E8001D4101BE1CE9354D13((&V_72), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_786 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&__this->___m_FXScale);
		float L_787 = L_786->___x;
		float L_788 = V_6;
		float L_789 = V_79;
		float L_790 = V_2;
		float L_791 = __this->___m_CharWidthAdjDelta;
		(&V_82)->___x = ((float)il2cpp_codegen_add(L_784, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_785, L_787)), ((float)il2cpp_codegen_multiply(L_788, (2.0f))))), ((float)il2cpp_codegen_multiply(L_789, (2.0f))))), L_790)), ((float)il2cpp_codegen_subtract((1.0f), L_791))))));
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_792 = V_80;
		float L_793 = L_792.___y;
		(&V_82)->___y = L_793;
		(&V_82)->___z = (0.0f);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_794 = V_82;
		float L_795 = L_794.___x;
		(&V_83)->___x = L_795;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_796 = V_81;
		float L_797 = L_796.___y;
		(&V_83)->___y = L_797;
		(&V_83)->___z = (0.0f);
		uint8_t L_798 = __this->___m_TextElementType;
		if ((!(((uint32_t)L_798) == ((uint32_t)1))))
		{
			goto IL_18ab;
		}
	}
	{
		bool L_799 = V_64;
		if (L_799)
		{
			goto IL_18ab;
		}
	}
	{
		int32_t L_800 = __this->___m_FontStyleInternal;
		G_B212_0 = ((((int32_t)((int32_t)((int32_t)L_800&2))) == ((int32_t)2))? 1 : 0);
		goto IL_18ac;
	}

IL_18ab:
	{
		G_B212_0 = 0;
	}

IL_18ac:
	{
		V_178 = (bool)G_B212_0;
		bool L_801 = V_178;
		if (!L_801)
		{
			goto IL_198e;
		}
	}
	{
		int32_t L_802 = __this->___m_ItalicAngle;
		V_179 = ((float)il2cpp_codegen_multiply(((float)L_802), (0.00999999978f)));
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_803 = __this->___m_CurrentFontAsset;
		NullCheck(L_803);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_804 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_803->___m_FaceInfo);
		float L_805;
		L_805 = FaceInfo_get_capLine_m0D95B5D5CEC5CFB12091F5EB5965DE6E38588C88(L_804, NULL);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_806 = __this->___m_CurrentFontAsset;
		NullCheck(L_806);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_807 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_806->___m_FaceInfo);
		float L_808;
		L_808 = FaceInfo_get_baseline_m934B597D3E0080FEF98CBDD091C457B497179C3A(L_807, NULL);
		float L_809 = __this->___m_BaselineOffset;
		float L_810 = __this->___m_FontScaleMultiplier;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_811 = __this->___m_CurrentFontAsset;
		NullCheck(L_811);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_812 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_811->___m_FaceInfo);
		float L_813;
		L_813 = FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD(L_812, NULL);
		V_180 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)(((float)il2cpp_codegen_subtract(L_805, ((float)il2cpp_codegen_add(L_808, L_809))))/(2.0f))), L_810)), L_813));
		float L_814 = V_179;
		float L_815;
		L_815 = GlyphMetrics_get_horizontalBearingY_mD316BDD38A32258256994D6A2BCF0FC051D9B223((&V_72), NULL);
		float L_816 = V_6;
		float L_817 = V_79;
		float L_818 = V_180;
		float L_819 = V_2;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_181), ((float)il2cpp_codegen_multiply(L_814, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_815, L_816)), L_817)), L_818)), L_819)))), (0.0f), (0.0f), NULL);
		float L_820 = V_179;
		float L_821;
		L_821 = GlyphMetrics_get_horizontalBearingY_mD316BDD38A32258256994D6A2BCF0FC051D9B223((&V_72), NULL);
		float L_822;
		L_822 = GlyphMetrics_get_height_mE0872B23CE1A20BF78DEACDBD53BAF789D84AD5C((&V_72), NULL);
		float L_823 = V_6;
		float L_824 = V_79;
		float L_825 = V_180;
		float L_826 = V_2;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_182), ((float)il2cpp_codegen_multiply(L_820, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(L_821, L_822)), L_823)), L_824)), L_825)), L_826)))), (0.0f), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_827 = V_80;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_828 = V_181;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_829;
		L_829 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_827, L_828, NULL);
		V_80 = L_829;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_830 = V_81;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_831 = V_182;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_832;
		L_832 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_830, L_831, NULL);
		V_81 = L_832;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_833 = V_82;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_834 = V_181;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_835;
		L_835 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_833, L_834, NULL);
		V_82 = L_835;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_836 = V_83;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_837 = V_182;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_838;
		L_838 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_836, L_837, NULL);
		V_83 = L_838;
	}

IL_198e:
	{
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_839 = __this->___m_FXRotation;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_840;
		L_840 = Quaternion_get_identity_m7E701AE095ED10FD5EA0B50ABCFDE2EEFF2173A5_inline(NULL);
		bool L_841;
		L_841 = Quaternion_op_Inequality_m4EC1EF263D0E42432A301F85CB52028D2973F5DA_inline(L_839, L_840, NULL);
		V_183 = L_841;
		bool L_842 = V_183;
		if (!L_842)
		{
			goto IL_1a2f;
		}
	}
	{
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_843 = __this->___m_FXRotation;
		Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 L_844;
		L_844 = Matrix4x4_Rotate_m015442530DFF5651458BBFDFB3CBC9180FC09D9E(L_843, NULL);
		V_184 = L_844;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_845 = V_82;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_846 = V_81;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_847;
		L_847 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_845, L_846, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_848;
		L_848 = Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline(L_847, (2.0f), NULL);
		V_185 = L_848;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_849 = V_80;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_850 = V_185;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_851;
		L_851 = Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline(L_849, L_850, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_852;
		L_852 = Matrix4x4_MultiplyPoint3x4_mACCBD70AFA82C63DA88555780B7B6B01281AB814((&V_184), L_851, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_853 = V_185;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_854;
		L_854 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_852, L_853, NULL);
		V_80 = L_854;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_855 = V_81;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_856 = V_185;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_857;
		L_857 = Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline(L_855, L_856, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_858;
		L_858 = Matrix4x4_MultiplyPoint3x4_mACCBD70AFA82C63DA88555780B7B6B01281AB814((&V_184), L_857, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_859 = V_185;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_860;
		L_860 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_858, L_859, NULL);
		V_81 = L_860;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_861 = V_82;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_862 = V_185;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_863;
		L_863 = Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline(L_861, L_862, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_864;
		L_864 = Matrix4x4_MultiplyPoint3x4_mACCBD70AFA82C63DA88555780B7B6B01281AB814((&V_184), L_863, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_865 = V_185;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_866;
		L_866 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_864, L_865, NULL);
		V_82 = L_866;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_867 = V_83;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_868 = V_185;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_869;
		L_869 = Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline(L_867, L_868, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_870;
		L_870 = Matrix4x4_MultiplyPoint3x4_mACCBD70AFA82C63DA88555780B7B6B01281AB814((&V_184), L_869, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_871 = V_185;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_872;
		L_872 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_870, L_871, NULL);
		V_83 = L_872;
	}

IL_1a2f:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_873 = ___1_textInfo;
		NullCheck(L_873);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_874 = L_873->___textElementInfo;
		int32_t L_875 = __this->___m_CharacterCount;
		NullCheck(L_874);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_876 = V_81;
		((L_874)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_875)))->___bottomLeft = L_876;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_877 = ___1_textInfo;
		NullCheck(L_877);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_878 = L_877->___textElementInfo;
		int32_t L_879 = __this->___m_CharacterCount;
		NullCheck(L_878);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_880 = V_80;
		((L_878)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_879)))->___topLeft = L_880;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_881 = ___1_textInfo;
		NullCheck(L_881);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_882 = L_881->___textElementInfo;
		int32_t L_883 = __this->___m_CharacterCount;
		NullCheck(L_882);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_884 = V_82;
		((L_882)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_883)))->___topRight = L_884;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_885 = ___1_textInfo;
		NullCheck(L_885);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_886 = L_885->___textElementInfo;
		int32_t L_887 = __this->___m_CharacterCount;
		NullCheck(L_886);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_888 = V_83;
		((L_886)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_887)))->___bottomRight = L_888;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_889 = ___1_textInfo;
		NullCheck(L_889);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_890 = L_889->___textElementInfo;
		int32_t L_891 = __this->___m_CharacterCount;
		NullCheck(L_890);
		float L_892 = __this->___m_XAdvance;
		float L_893;
		L_893 = GlyphValueRecord_get_xPlacement_m5E2B8B05A5DF57B2DC4B3795E71330CDDE1761C8((&V_74), NULL);
		float L_894 = V_2;
		((L_890)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_891)))->___origin = ((float)il2cpp_codegen_add(L_892, ((float)il2cpp_codegen_multiply(L_893, L_894))));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_895 = ___1_textInfo;
		NullCheck(L_895);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_896 = L_895->___textElementInfo;
		int32_t L_897 = __this->___m_CharacterCount;
		NullCheck(L_896);
		float L_898 = V_67;
		float L_899 = __this->___m_LineOffset;
		float L_900 = __this->___m_BaselineOffset;
		float L_901;
		L_901 = GlyphValueRecord_get_yPlacement_mB6303F8800305F6F96ECCD0CD9AA70A1A30A15DA((&V_74), NULL);
		float L_902 = V_2;
		((L_896)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_897)))->___baseLine = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(L_898, L_899)), L_900)), ((float)il2cpp_codegen_multiply(L_901, L_902))));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_903 = ___1_textInfo;
		NullCheck(L_903);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_904 = L_903->___textElementInfo;
		int32_t L_905 = __this->___m_CharacterCount;
		NullCheck(L_904);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_906 = V_82;
		float L_907 = L_906.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_908 = V_81;
		float L_909 = L_908.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_910 = V_80;
		float L_911 = L_910.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_912 = V_81;
		float L_913 = L_912.___y;
		((L_904)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_905)))->___aspectRatio = ((float)(((float)il2cpp_codegen_subtract(L_907, L_909))/((float)il2cpp_codegen_subtract(L_911, L_913))));
		uint8_t L_914 = __this->___m_TextElementType;
		if ((((int32_t)L_914) == ((int32_t)1)))
		{
			goto IL_1b30;
		}
	}
	{
		float L_915 = V_68;
		float L_916 = V_2;
		float L_917 = __this->___m_BaselineOffset;
		G_B219_0 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_915, L_916)), L_917));
		goto IL_1b3e;
	}

IL_1b30:
	{
		float L_918 = V_68;
		float L_919 = V_2;
		float L_920 = V_66;
		float L_921 = __this->___m_BaselineOffset;
		G_B219_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_multiply(L_918, L_919))/L_920)), L_921));
	}

IL_1b3e:
	{
		V_84 = G_B219_0;
		uint8_t L_922 = __this->___m_TextElementType;
		if ((((int32_t)L_922) == ((int32_t)1)))
		{
			goto IL_1b56;
		}
	}
	{
		float L_923 = V_69;
		float L_924 = V_2;
		float L_925 = __this->___m_BaselineOffset;
		G_B222_0 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_923, L_924)), L_925));
		goto IL_1b64;
	}

IL_1b56:
	{
		float L_926 = V_69;
		float L_927 = V_2;
		float L_928 = V_66;
		float L_929 = __this->___m_BaselineOffset;
		G_B222_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_multiply(L_926, L_927))/L_928)), L_929));
	}

IL_1b64:
	{
		V_85 = G_B222_0;
		float L_930 = V_84;
		V_86 = L_930;
		float L_931 = V_85;
		V_87 = L_931;
		int32_t L_932 = __this->___m_CharacterCount;
		int32_t L_933 = __this->___m_FirstCharacterOfLine;
		V_88 = (bool)((((int32_t)L_932) == ((int32_t)L_933))? 1 : 0);
		bool L_934 = V_88;
		if (L_934)
		{
			goto IL_1b89;
		}
	}
	{
		bool L_935 = V_73;
		G_B225_0 = ((((int32_t)L_935) == ((int32_t)0))? 1 : 0);
		goto IL_1b8a;
	}

IL_1b89:
	{
		G_B225_0 = 1;
	}

IL_1b8a:
	{
		V_186 = (bool)G_B225_0;
		bool L_936 = V_186;
		if (!L_936)
		{
			goto IL_1c02;
		}
	}
	{
		float L_937 = __this->___m_BaselineOffset;
		V_187 = (bool)((((int32_t)((((float)L_937) == ((float)(0.0f)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_938 = V_187;
		if (!L_938)
		{
			goto IL_1bdb;
		}
	}
	{
		float L_939 = V_84;
		float L_940 = __this->___m_BaselineOffset;
		float L_941 = __this->___m_FontScaleMultiplier;
		float L_942 = V_86;
		float L_943;
		L_943 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(((float)(((float)il2cpp_codegen_subtract(L_939, L_940))/L_941)), L_942, NULL);
		V_86 = L_943;
		float L_944 = V_85;
		float L_945 = __this->___m_BaselineOffset;
		float L_946 = __this->___m_FontScaleMultiplier;
		float L_947 = V_87;
		float L_948;
		L_948 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(((float)(((float)il2cpp_codegen_subtract(L_944, L_945))/L_946)), L_947, NULL);
		V_87 = L_948;
	}

IL_1bdb:
	{
		float L_949 = V_86;
		float L_950 = __this->___m_MaxLineAscender;
		float L_951;
		L_951 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_949, L_950, NULL);
		__this->___m_MaxLineAscender = L_951;
		float L_952 = V_87;
		float L_953 = __this->___m_MaxLineDescender;
		float L_954;
		L_954 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_952, L_953, NULL);
		__this->___m_MaxLineDescender = L_954;
	}

IL_1c02:
	{
		bool L_955 = V_88;
		if (L_955)
		{
			goto IL_1c0d;
		}
	}
	{
		bool L_956 = V_73;
		G_B232_0 = ((((int32_t)L_956) == ((int32_t)0))? 1 : 0);
		goto IL_1c0e;
	}

IL_1c0d:
	{
		G_B232_0 = 1;
	}

IL_1c0e:
	{
		V_188 = (bool)G_B232_0;
		bool L_957 = V_188;
		if (!L_957)
		{
			goto IL_1c97;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_958 = ___1_textInfo;
		NullCheck(L_958);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_959 = L_958->___textElementInfo;
		int32_t L_960 = __this->___m_CharacterCount;
		NullCheck(L_959);
		float L_961 = V_86;
		((L_959)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_960)))->___adjustedAscender = L_961;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_962 = ___1_textInfo;
		NullCheck(L_962);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_963 = L_962->___textElementInfo;
		int32_t L_964 = __this->___m_CharacterCount;
		NullCheck(L_963);
		float L_965 = V_87;
		((L_963)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_964)))->___adjustedDescender = L_965;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_966 = ___1_textInfo;
		NullCheck(L_966);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_967 = L_966->___textElementInfo;
		int32_t L_968 = __this->___m_CharacterCount;
		NullCheck(L_967);
		float L_969 = V_84;
		float L_970 = __this->___m_LineOffset;
		((L_967)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_968)))->___ascender = ((float)il2cpp_codegen_subtract(L_969, L_970));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_971 = ___1_textInfo;
		NullCheck(L_971);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_972 = L_971->___textElementInfo;
		int32_t L_973 = __this->___m_CharacterCount;
		NullCheck(L_972);
		float L_974 = V_85;
		float L_975 = __this->___m_LineOffset;
		float L_976 = ((float)il2cpp_codegen_subtract(L_974, L_975));
		V_189 = L_976;
		((L_972)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_973)))->___descender = L_976;
		float L_977 = V_189;
		__this->___m_MaxDescender = L_977;
		goto IL_1d22;
	}

IL_1c97:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_978 = ___1_textInfo;
		NullCheck(L_978);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_979 = L_978->___textElementInfo;
		int32_t L_980 = __this->___m_CharacterCount;
		NullCheck(L_979);
		float L_981 = __this->___m_MaxLineAscender;
		((L_979)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_980)))->___adjustedAscender = L_981;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_982 = ___1_textInfo;
		NullCheck(L_982);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_983 = L_982->___textElementInfo;
		int32_t L_984 = __this->___m_CharacterCount;
		NullCheck(L_983);
		float L_985 = __this->___m_MaxLineDescender;
		((L_983)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_984)))->___adjustedDescender = L_985;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_986 = ___1_textInfo;
		NullCheck(L_986);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_987 = L_986->___textElementInfo;
		int32_t L_988 = __this->___m_CharacterCount;
		NullCheck(L_987);
		float L_989 = __this->___m_MaxLineAscender;
		float L_990 = __this->___m_LineOffset;
		((L_987)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_988)))->___ascender = ((float)il2cpp_codegen_subtract(L_989, L_990));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_991 = ___1_textInfo;
		NullCheck(L_991);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_992 = L_991->___textElementInfo;
		int32_t L_993 = __this->___m_CharacterCount;
		NullCheck(L_992);
		float L_994 = __this->___m_MaxLineDescender;
		float L_995 = __this->___m_LineOffset;
		float L_996 = ((float)il2cpp_codegen_subtract(L_994, L_995));
		V_189 = L_996;
		((L_992)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_993)))->___descender = L_996;
		float L_997 = V_189;
		__this->___m_MaxDescender = L_997;
	}

IL_1d22:
	{
		int32_t L_998 = __this->___m_LineNumber;
		if (!L_998)
		{
			goto IL_1d32;
		}
	}
	{
		bool L_999 = __this->___m_IsNewPage;
		G_B238_0 = ((int32_t)(L_999));
		goto IL_1d33;
	}

IL_1d32:
	{
		G_B238_0 = 1;
	}

IL_1d33:
	{
		V_190 = (bool)G_B238_0;
		bool L_1000 = V_190;
		if (!L_1000)
		{
			goto IL_1d81;
		}
	}
	{
		bool L_1001 = V_88;
		if (L_1001)
		{
			goto IL_1d45;
		}
	}
	{
		bool L_1002 = V_73;
		G_B242_0 = ((((int32_t)L_1002) == ((int32_t)0))? 1 : 0);
		goto IL_1d46;
	}

IL_1d45:
	{
		G_B242_0 = 1;
	}

IL_1d46:
	{
		V_191 = (bool)G_B242_0;
		bool L_1003 = V_191;
		if (!L_1003)
		{
			goto IL_1d80;
		}
	}
	{
		float L_1004 = __this->___m_MaxLineAscender;
		__this->___m_MaxAscender = L_1004;
		float L_1005 = __this->___m_MaxCapHeight;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1006 = __this->___m_CurrentFontAsset;
		NullCheck(L_1006);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_1007 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_1006->___m_FaceInfo);
		float L_1008;
		L_1008 = FaceInfo_get_capLine_m0D95B5D5CEC5CFB12091F5EB5965DE6E38588C88(L_1007, NULL);
		float L_1009 = V_2;
		float L_1010 = V_66;
		float L_1011;
		L_1011 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_1005, ((float)(((float)il2cpp_codegen_multiply(L_1008, L_1009))/L_1010)), NULL);
		__this->___m_MaxCapHeight = L_1011;
	}

IL_1d80:
	{
	}

IL_1d81:
	{
		float L_1012 = __this->___m_LineOffset;
		V_192 = (bool)((((float)L_1012) == ((float)(0.0f)))? 1 : 0);
		bool L_1013 = V_192;
		if (!L_1013)
		{
			goto IL_1dc2;
		}
	}
	{
		bool L_1014 = V_88;
		if (L_1014)
		{
			goto IL_1da0;
		}
	}
	{
		bool L_1015 = V_73;
		G_B249_0 = ((((int32_t)L_1015) == ((int32_t)0))? 1 : 0);
		goto IL_1da1;
	}

IL_1da0:
	{
		G_B249_0 = 1;
	}

IL_1da1:
	{
		V_193 = (bool)G_B249_0;
		bool L_1016 = V_193;
		if (!L_1016)
		{
			goto IL_1dc1;
		}
	}
	{
		float L_1017 = __this->___m_PageAscender;
		float L_1018 = V_84;
		if ((((float)L_1017) > ((float)L_1018)))
		{
			G_B252_0 = __this;
			goto IL_1db6;
		}
		G_B251_0 = __this;
	}
	{
		float L_1019 = V_84;
		G_B253_0 = L_1019;
		G_B253_1 = G_B251_0;
		goto IL_1dbc;
	}

IL_1db6:
	{
		float L_1020 = __this->___m_PageAscender;
		G_B253_0 = L_1020;
		G_B253_1 = G_B252_0;
	}

IL_1dbc:
	{
		NullCheck(G_B253_1);
		G_B253_1->___m_PageAscender = G_B253_0;
	}

IL_1dc1:
	{
	}

IL_1dc2:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1021 = ___1_textInfo;
		NullCheck(L_1021);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1022 = L_1021->___textElementInfo;
		int32_t L_1023 = __this->___m_CharacterCount;
		NullCheck(L_1022);
		((L_1022)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1023)))->___isVisible = (bool)0;
		int32_t L_1024 = __this->___m_LineJustification;
		if ((((int32_t)((int32_t)((int32_t)L_1024&((int32_t)16)))) == ((int32_t)((int32_t)16))))
		{
			goto IL_1df3;
		}
	}
	{
		int32_t L_1025 = __this->___m_LineJustification;
		G_B258_0 = ((((int32_t)((int32_t)((int32_t)L_1025&8))) == ((int32_t)8))? 1 : 0);
		goto IL_1df4;
	}

IL_1df3:
	{
		G_B258_0 = 1;
	}

IL_1df4:
	{
		V_89 = (bool)G_B258_0;
		uint32_t L_1026 = V_5;
		if ((((int32_t)L_1026) == ((int32_t)((int32_t)9))))
		{
			goto IL_1e46;
		}
	}
	{
		int32_t L_1027 = V_30;
		if ((((int32_t)L_1027) == ((int32_t)2)))
		{
			goto IL_1e06;
		}
	}
	{
		int32_t L_1028 = V_30;
		if ((!(((uint32_t)L_1028) == ((uint32_t)3))))
		{
			goto IL_1e13;
		}
	}

IL_1e06:
	{
		bool L_1029 = V_73;
		if (L_1029)
		{
			goto IL_1e46;
		}
	}
	{
		uint32_t L_1030 = V_5;
		if ((((int32_t)L_1030) == ((int32_t)((int32_t)8203))))
		{
			goto IL_1e46;
		}
	}

IL_1e13:
	{
		bool L_1031 = V_73;
		if (L_1031)
		{
			goto IL_1e2e;
		}
	}
	{
		uint32_t L_1032 = V_5;
		if ((((int32_t)L_1032) == ((int32_t)((int32_t)8203))))
		{
			goto IL_1e2e;
		}
	}
	{
		uint32_t L_1033 = V_5;
		if ((((int32_t)L_1033) == ((int32_t)((int32_t)173))))
		{
			goto IL_1e2e;
		}
	}
	{
		uint32_t L_1034 = V_5;
		if ((!(((uint32_t)L_1034) == ((uint32_t)3))))
		{
			goto IL_1e46;
		}
	}

IL_1e2e:
	{
		uint32_t L_1035 = V_5;
		if ((!(((uint32_t)L_1035) == ((uint32_t)((int32_t)173)))))
		{
			goto IL_1e3b;
		}
	}
	{
		bool L_1036 = V_29;
		if (!L_1036)
		{
			goto IL_1e46;
		}
	}

IL_1e3b:
	{
		uint8_t L_1037 = __this->___m_TextElementType;
		G_B271_0 = ((((int32_t)L_1037) == ((int32_t)2))? 1 : 0);
		goto IL_1e47;
	}

IL_1e46:
	{
		G_B271_0 = 1;
	}

IL_1e47:
	{
		V_194 = (bool)G_B271_0;
		bool L_1038 = V_194;
		if (!L_1038)
		{
			goto IL_2e7e;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1039 = ___1_textInfo;
		NullCheck(L_1039);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1040 = L_1039->___textElementInfo;
		int32_t L_1041 = __this->___m_CharacterCount;
		NullCheck(L_1040);
		((L_1040)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1041)))->___isVisible = (bool)1;
		float L_1042 = __this->___m_MarginLeft;
		V_195 = L_1042;
		float L_1043 = __this->___m_MarginRight;
		V_196 = L_1043;
		bool L_1044 = V_65;
		V_200 = L_1044;
		bool L_1045 = V_200;
		if (!L_1045)
		{
			goto IL_1eb2;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1046 = ___1_textInfo;
		NullCheck(L_1046);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1047 = L_1046->___lineInfo;
		int32_t L_1048 = __this->___m_LineNumber;
		NullCheck(L_1047);
		float L_1049 = ((L_1047)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1048)))->___marginLeft;
		V_195 = L_1049;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1050 = ___1_textInfo;
		NullCheck(L_1050);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1051 = L_1050->___lineInfo;
		int32_t L_1052 = __this->___m_LineNumber;
		NullCheck(L_1051);
		float L_1053 = ((L_1051)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1052)))->___marginRight;
		V_196 = L_1053;
	}

IL_1eb2:
	{
		float L_1054 = __this->___m_Width;
		if ((!(((float)L_1054) == ((float)(-1.0f)))))
		{
			goto IL_1ecf;
		}
	}
	{
		float L_1055 = V_20;
		float L_1056 = V_195;
		float L_1057 = V_196;
		G_B277_0 = ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_1055, (9.99999975E-05f))), L_1056)), L_1057));
		goto IL_1ee8;
	}

IL_1ecf:
	{
		float L_1058 = V_20;
		float L_1059 = V_195;
		float L_1060 = V_196;
		float L_1061 = __this->___m_Width;
		float L_1062;
		L_1062 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_1058, (9.99999975E-05f))), L_1059)), L_1060)), L_1061, NULL);
		G_B277_0 = L_1062;
	}

IL_1ee8:
	{
		V_22 = G_B277_0;
		float L_1063 = __this->___m_XAdvance;
		float L_1064;
		L_1064 = fabsf(L_1063);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1065 = ___0_generationSettings;
		NullCheck(L_1065);
		bool L_1066 = L_1065->___isRightToLeft;
		if (!L_1066)
		{
			G_B279_0 = L_1064;
			goto IL_1f04;
		}
		G_B278_0 = L_1064;
	}
	{
		G_B280_0 = (0.0f);
		G_B280_1 = G_B278_0;
		goto IL_1f0b;
	}

IL_1f04:
	{
		float L_1067;
		L_1067 = GlyphMetrics_get_horizontalAdvance_m110E66C340A19E672FB1C26DFB875AB6900AFFF1((&V_72), NULL);
		G_B280_0 = L_1067;
		G_B280_1 = G_B279_0;
	}

IL_1f0b:
	{
		float L_1068 = __this->___m_CharWidthAdjDelta;
		uint32_t L_1069 = V_5;
		if ((((int32_t)L_1069) == ((int32_t)((int32_t)173))))
		{
			G_B282_0 = ((float)il2cpp_codegen_multiply(G_B280_0, ((float)il2cpp_codegen_subtract((1.0f), L_1068))));
			G_B282_1 = G_B280_1;
			goto IL_1f24;
		}
		G_B281_0 = ((float)il2cpp_codegen_multiply(G_B280_0, ((float)il2cpp_codegen_subtract((1.0f), L_1068))));
		G_B281_1 = G_B280_1;
	}
	{
		float L_1070 = V_2;
		G_B283_0 = L_1070;
		G_B283_1 = G_B281_0;
		G_B283_2 = G_B281_1;
		goto IL_1f26;
	}

IL_1f24:
	{
		float L_1071 = V_70;
		G_B283_0 = L_1071;
		G_B283_1 = G_B282_0;
		G_B283_2 = G_B282_1;
	}

IL_1f26:
	{
		V_197 = ((float)il2cpp_codegen_add(G_B283_2, ((float)il2cpp_codegen_multiply(G_B283_1, G_B283_0))));
		float L_1072 = __this->___m_MaxAscender;
		float L_1073 = __this->___m_MaxLineDescender;
		float L_1074 = __this->___m_LineOffset;
		float L_1075 = __this->___m_LineOffset;
		if ((!(((float)L_1075) > ((float)(0.0f)))))
		{
			G_B285_0 = ((float)il2cpp_codegen_subtract(L_1072, ((float)il2cpp_codegen_subtract(L_1073, L_1074))));
			goto IL_1f53;
		}
		G_B284_0 = ((float)il2cpp_codegen_subtract(L_1072, ((float)il2cpp_codegen_subtract(L_1073, L_1074))));
	}
	{
		bool L_1076 = __this->___m_IsDrivenLineSpacing;
		if (!L_1076)
		{
			G_B286_0 = G_B284_0;
			goto IL_1f5a;
		}
		G_B285_0 = G_B284_0;
	}

IL_1f53:
	{
		G_B287_0 = (0.0f);
		G_B287_1 = G_B285_0;
		goto IL_1f67;
	}

IL_1f5a:
	{
		float L_1077 = __this->___m_MaxLineAscender;
		float L_1078 = __this->___m_StartOfLineAscender;
		G_B287_0 = ((float)il2cpp_codegen_subtract(L_1077, L_1078));
		G_B287_1 = G_B286_0;
	}

IL_1f67:
	{
		V_198 = ((float)il2cpp_codegen_add(G_B287_1, G_B287_0));
		int32_t L_1079 = __this->___m_CharacterCount;
		V_199 = L_1079;
		float L_1080 = V_198;
		float L_1081 = V_21;
		V_201 = (bool)((((float)L_1080) > ((float)((float)il2cpp_codegen_add(L_1081, (9.99999975E-05f)))))? 1 : 0);
		bool L_1082 = V_201;
		if (!L_1082)
		{
			goto IL_22d3;
		}
	}
	{
		int32_t L_1083 = __this->___m_FirstOverflowCharacterIndex;
		V_202 = (bool)((((int32_t)L_1083) == ((int32_t)(-1)))? 1 : 0);
		bool L_1084 = V_202;
		if (!L_1084)
		{
			goto IL_1fa3;
		}
	}
	{
		int32_t L_1085 = __this->___m_CharacterCount;
		__this->___m_FirstOverflowCharacterIndex = L_1085;
	}

IL_1fa3:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1086 = ___0_generationSettings;
		NullCheck(L_1086);
		bool L_1087 = L_1086->___autoSize;
		V_203 = L_1087;
		bool L_1088 = V_203;
		if (!L_1088)
		{
			goto IL_20a7;
		}
	}
	{
		float L_1089 = __this->___m_LineSpacingDelta;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1090 = ___0_generationSettings;
		NullCheck(L_1090);
		float L_1091 = L_1090->___lineSpacingMax;
		if ((!(((float)L_1089) > ((float)L_1091))))
		{
			goto IL_1fde;
		}
	}
	{
		float L_1092 = __this->___m_LineOffset;
		if ((!(((float)L_1092) > ((float)(0.0f)))))
		{
			goto IL_1fde;
		}
	}
	{
		int32_t L_1093 = __this->___m_AutoSizeIterationCount;
		int32_t L_1094 = __this->___m_AutoSizeMaxIterationCount;
		G_B295_0 = ((((int32_t)L_1093) < ((int32_t)L_1094))? 1 : 0);
		goto IL_1fdf;
	}

IL_1fde:
	{
		G_B295_0 = 0;
	}

IL_1fdf:
	{
		V_204 = (bool)G_B295_0;
		bool L_1095 = V_204;
		if (!L_1095)
		{
			goto IL_2016;
		}
	}
	{
		float L_1096 = V_21;
		float L_1097 = V_198;
		int32_t L_1098 = __this->___m_LineNumber;
		V_205 = ((float)(((float)il2cpp_codegen_subtract(L_1096, L_1097))/((float)L_1098)));
		float L_1099 = __this->___m_LineSpacingDelta;
		float L_1100 = V_205;
		float L_1101 = V_1;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1102 = ___0_generationSettings;
		NullCheck(L_1102);
		float L_1103 = L_1102->___lineSpacingMax;
		float L_1104;
		L_1104 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(((float)il2cpp_codegen_add(L_1099, ((float)(L_1100/L_1101)))), L_1103, NULL);
		__this->___m_LineSpacingDelta = L_1104;
		goto IL_88b4;
	}

IL_2016:
	{
		float L_1105 = __this->___m_FontSize;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1106 = ___0_generationSettings;
		NullCheck(L_1106);
		float L_1107 = L_1106->___fontSizeMin;
		if ((!(((float)L_1105) > ((float)L_1107))))
		{
			goto IL_2034;
		}
	}
	{
		int32_t L_1108 = __this->___m_AutoSizeIterationCount;
		int32_t L_1109 = __this->___m_AutoSizeMaxIterationCount;
		G_B300_0 = ((((int32_t)L_1108) < ((int32_t)L_1109))? 1 : 0);
		goto IL_2035;
	}

IL_2034:
	{
		G_B300_0 = 0;
	}

IL_2035:
	{
		V_206 = (bool)G_B300_0;
		bool L_1110 = V_206;
		if (!L_1110)
		{
			goto IL_20a6;
		}
	}
	{
		float L_1111 = __this->___m_FontSize;
		__this->___m_MaxFontSize = L_1111;
		float L_1112 = __this->___m_FontSize;
		float L_1113 = __this->___m_MinFontSize;
		float L_1114;
		L_1114 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(((float)(((float)il2cpp_codegen_subtract(L_1112, L_1113))/(2.0f))), (0.0500000007f), NULL);
		V_207 = L_1114;
		float L_1115 = __this->___m_FontSize;
		float L_1116 = V_207;
		__this->___m_FontSize = ((float)il2cpp_codegen_subtract(L_1115, L_1116));
		float L_1117 = __this->___m_FontSize;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1118 = ___0_generationSettings;
		NullCheck(L_1118);
		float L_1119 = L_1118->___fontSizeMin;
		float L_1120;
		L_1120 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(((float)(((float)il2cpp_codegen_cast_double_to_int<int32_t>(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_1117, (20.0f))), (0.5f)))))/(20.0f))), L_1119, NULL);
		__this->___m_FontSize = L_1120;
		goto IL_88b4;
	}

IL_20a6:
	{
	}

IL_20a7:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1121 = ___0_generationSettings;
		NullCheck(L_1121);
		int32_t L_1122 = L_1121->___overflowMode;
		V_209 = L_1122;
		int32_t L_1123 = V_209;
		V_208 = L_1123;
		int32_t L_1124 = V_208;
		switch (L_1124)
		{
			case 0:
			{
				goto IL_20db;
			}
			case 1:
			{
				goto IL_20fd;
			}
			case 2:
			{
				goto IL_20db;
			}
			case 3:
			{
				goto IL_20e0;
			}
			case 4:
			{
				goto IL_20db;
			}
			case 5:
			{
				goto IL_21c5;
			}
			case 6:
			{
				goto IL_21a0;
			}
		}
	}
	{
		goto IL_22d2;
	}

IL_20db:
	{
		goto IL_22d2;
	}

IL_20e0:
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1125 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedLastValidState);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1126 = ___1_textInfo;
		int32_t L_1127;
		L_1127 = TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61(__this, L_1125, L_1126, NULL);
		V_62 = L_1127;
		int32_t L_1128 = V_199;
		(&V_28)->___index = L_1128;
		goto IL_43d7;
	}

IL_20fd:
	{
		int32_t L_1129 = __this->___m_LineNumber;
		V_210 = (bool)((((int32_t)L_1129) > ((int32_t)0))? 1 : 0);
		bool L_1130 = V_210;
		if (!L_1130)
		{
			goto IL_219b;
		}
	}
	{
		TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9* L_1131 = (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9*)(&__this->___m_EllipsisInsertionCandidateStack);
		int32_t L_1132;
		L_1132 = TextProcessingStack_1_get_Count_m019E4780B26C3C62C2C3E1BA49A5B47266DC65AC(L_1131, TextProcessingStack_1_get_Count_m019E4780B26C3C62C2C3E1BA49A5B47266DC65AC_RuntimeMethod_var);
		V_212 = (bool)((((int32_t)L_1132) == ((int32_t)0))? 1 : 0);
		bool L_1133 = V_212;
		if (!L_1133)
		{
			goto IL_214b;
		}
	}
	{
		V_62 = (-1);
		__this->___m_CharacterCount = 0;
		(&V_28)->___index = 0;
		(&V_28)->___unicode = 3;
		__this->___m_FirstCharacterOfLine = 0;
		goto IL_43d7;
	}

IL_214b:
	{
		TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9* L_1134 = (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9*)(&__this->___m_EllipsisInsertionCandidateStack);
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 L_1135;
		L_1135 = TextProcessingStack_1_Pop_mBDDB87E018CFAAA932187B334ABB0237AB9D73B8(L_1134, TextProcessingStack_1_Pop_mBDDB87E018CFAAA932187B334ABB0237AB9D73B8_RuntimeMethod_var);
		V_211 = L_1135;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1136 = ___1_textInfo;
		int32_t L_1137;
		L_1137 = TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61(__this, (&V_211), L_1136, NULL);
		V_62 = L_1137;
		int32_t L_1138 = V_62;
		V_62 = ((int32_t)il2cpp_codegen_subtract(L_1138, 1));
		int32_t L_1139 = __this->___m_CharacterCount;
		__this->___m_CharacterCount = ((int32_t)il2cpp_codegen_subtract(L_1139, 1));
		int32_t L_1140 = __this->___m_CharacterCount;
		(&V_28)->___index = L_1140;
		(&V_28)->___unicode = ((int32_t)8230);
		int32_t L_1141 = V_32;
		V_32 = ((int32_t)il2cpp_codegen_add(L_1141, 1));
		goto IL_43d7;
	}

IL_219b:
	{
		goto IL_22d2;
	}

IL_21a0:
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1142 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedLastValidState);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1143 = ___1_textInfo;
		int32_t L_1144;
		L_1144 = TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61(__this, L_1142, L_1143, NULL);
		V_62 = L_1144;
		int32_t L_1145 = V_199;
		(&V_28)->___index = L_1145;
		(&V_28)->___unicode = 3;
		goto IL_43d7;
	}

IL_21c5:
	{
		int32_t L_1146 = V_62;
		if ((((int32_t)L_1146) < ((int32_t)0)))
		{
			goto IL_21d1;
		}
	}
	{
		int32_t L_1147 = V_199;
		G_B316_0 = ((((int32_t)L_1147) == ((int32_t)0))? 1 : 0);
		goto IL_21d2;
	}

IL_21d1:
	{
		G_B316_0 = 1;
	}

IL_21d2:
	{
		V_213 = (bool)G_B316_0;
		bool L_1148 = V_213;
		if (!L_1148)
		{
			goto IL_21f8;
		}
	}
	{
		V_62 = (-1);
		__this->___m_CharacterCount = 0;
		(&V_28)->___index = 0;
		(&V_28)->___unicode = 3;
		goto IL_43d7;
	}

IL_21f8:
	{
		float L_1149 = __this->___m_MaxLineAscender;
		float L_1150 = __this->___m_MaxLineDescender;
		float L_1151 = V_21;
		V_214 = (bool)((((float)((float)il2cpp_codegen_subtract(L_1149, L_1150))) > ((float)((float)il2cpp_codegen_add(L_1151, (9.99999975E-05f)))))? 1 : 0);
		bool L_1152 = V_214;
		if (!L_1152)
		{
			goto IL_223b;
		}
	}
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1153 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedLineState);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1154 = ___1_textInfo;
		int32_t L_1155;
		L_1155 = TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61(__this, L_1153, L_1154, NULL);
		V_62 = L_1155;
		int32_t L_1156 = V_199;
		(&V_28)->___index = L_1156;
		(&V_28)->___unicode = 3;
		goto IL_43d7;
	}

IL_223b:
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1157 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedLineState);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1158 = ___1_textInfo;
		int32_t L_1159;
		L_1159 = TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61(__this, L_1157, L_1158, NULL);
		V_62 = L_1159;
		__this->___m_IsNewPage = (bool)1;
		int32_t L_1160 = __this->___m_CharacterCount;
		__this->___m_FirstCharacterOfLine = L_1160;
		__this->___m_MaxLineAscender = (-32767.0f);
		__this->___m_MaxLineDescender = (32767.0f);
		__this->___m_StartOfLineAscender = (0.0f);
		float L_1161 = __this->___m_TagIndent;
		__this->___m_XAdvance = ((float)il2cpp_codegen_add((0.0f), L_1161));
		__this->___m_LineOffset = (0.0f);
		__this->___m_MaxAscender = (0.0f);
		__this->___m_PageAscender = (0.0f);
		int32_t L_1162 = __this->___m_LineNumber;
		__this->___m_LineNumber = ((int32_t)il2cpp_codegen_add(L_1162, 1));
		int32_t L_1163 = __this->___m_PageNumber;
		__this->___m_PageNumber = ((int32_t)il2cpp_codegen_add(L_1163, 1));
		goto IL_43d7;
	}

IL_22d2:
	{
	}

IL_22d3:
	{
		bool L_1164 = V_76;
		if (!L_1164)
		{
			goto IL_22f0;
		}
	}
	{
		float L_1165 = V_197;
		float L_1166 = V_22;
		bool L_1167 = V_89;
		if (L_1167)
		{
			G_B325_0 = L_1166;
			G_B325_1 = L_1165;
			goto IL_22e6;
		}
		G_B324_0 = L_1166;
		G_B324_1 = L_1165;
	}
	{
		G_B326_0 = (1.0f);
		G_B326_1 = G_B324_0;
		G_B326_2 = G_B324_1;
		goto IL_22eb;
	}

IL_22e6:
	{
		G_B326_0 = (1.04999995f);
		G_B326_1 = G_B325_0;
		G_B326_2 = G_B325_1;
	}

IL_22eb:
	{
		G_B328_0 = ((((float)G_B326_2) > ((float)((float)il2cpp_codegen_multiply(G_B326_1, G_B326_0))))? 1 : 0);
		goto IL_22f1;
	}

IL_22f0:
	{
		G_B328_0 = 0;
	}

IL_22f1:
	{
		V_215 = (bool)G_B328_0;
		bool L_1168 = V_215;
		if (!L_1168)
		{
			goto IL_2c8f;
		}
	}
	{
		int32_t L_1169 = V_30;
		if (!L_1169)
		{
			goto IL_2317;
		}
	}
	{
		int32_t L_1170 = V_30;
		if ((((int32_t)L_1170) == ((int32_t)3)))
		{
			goto IL_2317;
		}
	}
	{
		int32_t L_1171 = __this->___m_CharacterCount;
		int32_t L_1172 = __this->___m_FirstCharacterOfLine;
		G_B333_0 = ((((int32_t)((((int32_t)L_1171) == ((int32_t)L_1172))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_2318;
	}

IL_2317:
	{
		G_B333_0 = 0;
	}

IL_2318:
	{
		V_216 = (bool)G_B333_0;
		bool L_1173 = V_216;
		if (!L_1173)
		{
			goto IL_2a12;
		}
	}
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1174 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedWordWrapState);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1175 = ___1_textInfo;
		int32_t L_1176;
		L_1176 = TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61(__this, L_1174, L_1175, NULL);
		V_62 = L_1176;
		V_217 = (0.0f);
		float L_1177 = __this->___m_LineHeight;
		V_220 = (bool)((((float)L_1177) == ((float)(-32767.0f)))? 1 : 0);
		bool L_1178 = V_220;
		if (!L_1178)
		{
			goto IL_23b1;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1179 = ___1_textInfo;
		NullCheck(L_1179);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1180 = L_1179->___textElementInfo;
		int32_t L_1181 = __this->___m_CharacterCount;
		NullCheck(L_1180);
		float L_1182 = ((L_1180)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1181)))->___adjustedAscender;
		V_221 = L_1182;
		float L_1183 = __this->___m_LineOffset;
		if ((!(((float)L_1183) > ((float)(0.0f)))))
		{
			goto IL_2379;
		}
	}
	{
		bool L_1184 = __this->___m_IsDrivenLineSpacing;
		if (!L_1184)
		{
			goto IL_2380;
		}
	}

IL_2379:
	{
		G_B339_0 = (0.0f);
		goto IL_238d;
	}

IL_2380:
	{
		float L_1185 = __this->___m_MaxLineAscender;
		float L_1186 = __this->___m_StartOfLineAscender;
		G_B339_0 = ((float)il2cpp_codegen_subtract(L_1185, L_1186));
	}

IL_238d:
	{
		float L_1187 = __this->___m_MaxLineDescender;
		float L_1188 = V_221;
		float L_1189 = V_16;
		float L_1190 = __this->___m_LineSpacingDelta;
		float L_1191 = V_1;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1192 = ___0_generationSettings;
		NullCheck(L_1192);
		float L_1193 = L_1192->___lineSpacing;
		float L_1194 = V_3;
		V_217 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(G_B339_0, L_1187)), L_1188)), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_1189, L_1190)), L_1191)))), ((float)il2cpp_codegen_multiply(L_1193, L_1194))));
		goto IL_23cb;
	}

IL_23b1:
	{
		float L_1195 = __this->___m_LineHeight;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1196 = ___0_generationSettings;
		NullCheck(L_1196);
		float L_1197 = L_1196->___lineSpacing;
		float L_1198 = V_3;
		V_217 = ((float)il2cpp_codegen_add(L_1195, ((float)il2cpp_codegen_multiply(L_1197, L_1198))));
		__this->___m_IsDrivenLineSpacing = (bool)1;
	}

IL_23cb:
	{
		float L_1199 = __this->___m_MaxAscender;
		float L_1200 = V_217;
		float L_1201 = __this->___m_LineOffset;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1202 = ___1_textInfo;
		NullCheck(L_1202);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1203 = L_1202->___textElementInfo;
		int32_t L_1204 = __this->___m_CharacterCount;
		NullCheck(L_1203);
		float L_1205 = ((L_1203)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1204)))->___adjustedDescender;
		V_218 = ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_1199, L_1200)), L_1201)), L_1205));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1206 = ___1_textInfo;
		NullCheck(L_1206);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1207 = L_1206->___textElementInfo;
		int32_t L_1208 = __this->___m_CharacterCount;
		NullCheck(L_1207);
		Il2CppChar L_1209 = ((L_1207)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_1208, 1)))))->___character;
		if ((!(((uint32_t)L_1209) == ((uint32_t)((int32_t)173)))))
		{
			goto IL_241a;
		}
	}
	{
		bool L_1210 = V_29;
		G_B344_0 = ((((int32_t)L_1210) == ((int32_t)0))? 1 : 0);
		goto IL_241b;
	}

IL_241a:
	{
		G_B344_0 = 0;
	}

IL_241b:
	{
		V_222 = (bool)G_B344_0;
		bool L_1211 = V_222;
		if (!L_1211)
		{
			goto IL_2472;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1212 = ___0_generationSettings;
		NullCheck(L_1212);
		int32_t L_1213 = L_1212->___overflowMode;
		if (!L_1213)
		{
			goto IL_2438;
		}
	}
	{
		float L_1214 = V_218;
		float L_1215 = V_21;
		G_B348_0 = ((((float)L_1214) < ((float)((float)il2cpp_codegen_add(L_1215, (9.99999975E-05f)))))? 1 : 0);
		goto IL_2439;
	}

IL_2438:
	{
		G_B348_0 = 1;
	}

IL_2439:
	{
		V_223 = (bool)G_B348_0;
		bool L_1216 = V_223;
		if (!L_1216)
		{
			goto IL_2471;
		}
	}
	{
		int32_t L_1217 = __this->___m_CharacterCount;
		(&V_28)->___index = ((int32_t)il2cpp_codegen_subtract(L_1217, 1));
		(&V_28)->___unicode = ((int32_t)45);
		int32_t L_1218 = V_62;
		V_62 = ((int32_t)il2cpp_codegen_subtract(L_1218, 1));
		int32_t L_1219 = __this->___m_CharacterCount;
		__this->___m_CharacterCount = ((int32_t)il2cpp_codegen_subtract(L_1219, 1));
		goto IL_43d7;
	}

IL_2471:
	{
	}

IL_2472:
	{
		V_29 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1220 = ___1_textInfo;
		NullCheck(L_1220);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1221 = L_1220->___textElementInfo;
		int32_t L_1222 = __this->___m_CharacterCount;
		NullCheck(L_1221);
		Il2CppChar L_1223 = ((L_1221)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1222)))->___character;
		V_224 = (bool)((((int32_t)L_1223) == ((int32_t)((int32_t)173)))? 1 : 0);
		bool L_1224 = V_224;
		if (!L_1224)
		{
			goto IL_24a1;
		}
	}
	{
		V_29 = (bool)1;
		goto IL_43d7;
	}

IL_24a1:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1225 = ___0_generationSettings;
		NullCheck(L_1225);
		bool L_1226 = L_1225->___autoSize;
		bool L_1227 = V_25;
		V_225 = (bool)((int32_t)((int32_t)L_1226&(int32_t)L_1227));
		bool L_1228 = V_225;
		if (!L_1228)
		{
			goto IL_25eb;
		}
	}
	{
		float L_1229 = __this->___m_CharWidthAdjDelta;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1230 = ___0_generationSettings;
		NullCheck(L_1230);
		float L_1231 = L_1230->___charWidthMaxAdj;
		if ((!(((float)L_1229) < ((float)((float)(L_1231/(100.0f)))))))
		{
			goto IL_24d8;
		}
	}
	{
		int32_t L_1232 = __this->___m_AutoSizeIterationCount;
		int32_t L_1233 = __this->___m_AutoSizeMaxIterationCount;
		G_B357_0 = ((((int32_t)L_1232) < ((int32_t)L_1233))? 1 : 0);
		goto IL_24d9;
	}

IL_24d8:
	{
		G_B357_0 = 0;
	}

IL_24d9:
	{
		V_226 = (bool)G_B357_0;
		bool L_1234 = V_226;
		if (!L_1234)
		{
			goto IL_255a;
		}
	}
	{
		float L_1235 = V_197;
		V_227 = L_1235;
		float L_1236 = __this->___m_CharWidthAdjDelta;
		V_229 = (bool)((((float)L_1236) > ((float)(0.0f)))? 1 : 0);
		bool L_1237 = V_229;
		if (!L_1237)
		{
			goto IL_2508;
		}
	}
	{
		float L_1238 = V_227;
		float L_1239 = __this->___m_CharWidthAdjDelta;
		V_227 = ((float)(L_1238/((float)il2cpp_codegen_subtract((1.0f), L_1239))));
	}

IL_2508:
	{
		float L_1240 = V_197;
		float L_1241 = V_22;
		bool L_1242 = V_89;
		if (L_1242)
		{
			G_B362_0 = ((float)il2cpp_codegen_subtract(L_1241, (9.99999975E-05f)));
			G_B362_1 = L_1240;
			goto IL_251d;
		}
		G_B361_0 = ((float)il2cpp_codegen_subtract(L_1241, (9.99999975E-05f)));
		G_B361_1 = L_1240;
	}
	{
		G_B363_0 = (1.0f);
		G_B363_1 = G_B361_0;
		G_B363_2 = G_B361_1;
		goto IL_2522;
	}

IL_251d:
	{
		G_B363_0 = (1.04999995f);
		G_B363_1 = G_B362_0;
		G_B363_2 = G_B362_1;
	}

IL_2522:
	{
		V_228 = ((float)il2cpp_codegen_subtract(G_B363_2, ((float)il2cpp_codegen_multiply(G_B363_1, G_B363_0))));
		float L_1243 = __this->___m_CharWidthAdjDelta;
		float L_1244 = V_228;
		float L_1245 = V_227;
		__this->___m_CharWidthAdjDelta = ((float)il2cpp_codegen_add(L_1243, ((float)(L_1244/L_1245))));
		float L_1246 = __this->___m_CharWidthAdjDelta;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1247 = ___0_generationSettings;
		NullCheck(L_1247);
		float L_1248 = L_1247->___charWidthMaxAdj;
		float L_1249;
		L_1249 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_1246, ((float)(L_1248/(100.0f))), NULL);
		__this->___m_CharWidthAdjDelta = L_1249;
		goto IL_88b4;
	}

IL_255a:
	{
		float L_1250 = __this->___m_FontSize;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1251 = ___0_generationSettings;
		NullCheck(L_1251);
		float L_1252 = L_1251->___fontSizeMin;
		if ((!(((float)L_1250) > ((float)L_1252))))
		{
			goto IL_2578;
		}
	}
	{
		int32_t L_1253 = __this->___m_AutoSizeIterationCount;
		int32_t L_1254 = __this->___m_AutoSizeMaxIterationCount;
		G_B367_0 = ((((int32_t)L_1253) < ((int32_t)L_1254))? 1 : 0);
		goto IL_2579;
	}

IL_2578:
	{
		G_B367_0 = 0;
	}

IL_2579:
	{
		V_230 = (bool)G_B367_0;
		bool L_1255 = V_230;
		if (!L_1255)
		{
			goto IL_25ea;
		}
	}
	{
		float L_1256 = __this->___m_FontSize;
		__this->___m_MaxFontSize = L_1256;
		float L_1257 = __this->___m_FontSize;
		float L_1258 = __this->___m_MinFontSize;
		float L_1259;
		L_1259 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(((float)(((float)il2cpp_codegen_subtract(L_1257, L_1258))/(2.0f))), (0.0500000007f), NULL);
		V_231 = L_1259;
		float L_1260 = __this->___m_FontSize;
		float L_1261 = V_231;
		__this->___m_FontSize = ((float)il2cpp_codegen_subtract(L_1260, L_1261));
		float L_1262 = __this->___m_FontSize;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1263 = ___0_generationSettings;
		NullCheck(L_1263);
		float L_1264 = L_1263->___fontSizeMin;
		float L_1265;
		L_1265 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(((float)(((float)il2cpp_codegen_cast_double_to_int<int32_t>(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_1262, (20.0f))), (0.5f)))))/(20.0f))), L_1264, NULL);
		__this->___m_FontSize = L_1265;
		goto IL_88b4;
	}

IL_25ea:
	{
	}

IL_25eb:
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1266 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedSoftLineBreakState);
		int32_t L_1267 = L_1266->___previousWordBreak;
		V_219 = L_1267;
		bool L_1268 = V_25;
		if (!L_1268)
		{
			goto IL_2606;
		}
	}
	{
		int32_t L_1269 = V_219;
		G_B373_0 = ((((int32_t)((((int32_t)L_1269) == ((int32_t)(-1)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_2607;
	}

IL_2606:
	{
		G_B373_0 = 0;
	}

IL_2607:
	{
		V_232 = (bool)G_B373_0;
		bool L_1270 = V_232;
		if (!L_1270)
		{
			goto IL_268a;
		}
	}
	{
		int32_t L_1271 = V_219;
		int32_t L_1272 = V_27;
		V_233 = (bool)((((int32_t)((((int32_t)L_1271) == ((int32_t)L_1272))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_1273 = V_233;
		if (!L_1273)
		{
			goto IL_2689;
		}
	}
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1274 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedSoftLineBreakState);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1275 = ___1_textInfo;
		int32_t L_1276;
		L_1276 = TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61(__this, L_1274, L_1275, NULL);
		V_62 = L_1276;
		int32_t L_1277 = V_219;
		V_27 = L_1277;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1278 = ___1_textInfo;
		NullCheck(L_1278);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1279 = L_1278->___textElementInfo;
		int32_t L_1280 = __this->___m_CharacterCount;
		NullCheck(L_1279);
		Il2CppChar L_1281 = ((L_1279)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_1280, 1)))))->___character;
		V_234 = (bool)((((int32_t)L_1281) == ((int32_t)((int32_t)173)))? 1 : 0);
		bool L_1282 = V_234;
		if (!L_1282)
		{
			goto IL_2688;
		}
	}
	{
		int32_t L_1283 = __this->___m_CharacterCount;
		(&V_28)->___index = ((int32_t)il2cpp_codegen_subtract(L_1283, 1));
		(&V_28)->___unicode = ((int32_t)45);
		int32_t L_1284 = V_62;
		V_62 = ((int32_t)il2cpp_codegen_subtract(L_1284, 1));
		int32_t L_1285 = __this->___m_CharacterCount;
		__this->___m_CharacterCount = ((int32_t)il2cpp_codegen_subtract(L_1285, 1));
		goto IL_43d7;
	}

IL_2688:
	{
	}

IL_2689:
	{
	}

IL_268a:
	{
		float L_1286 = V_218;
		float L_1287 = V_21;
		V_235 = (bool)((((float)L_1286) > ((float)((float)il2cpp_codegen_add(L_1287, (9.99999975E-05f)))))? 1 : 0);
		bool L_1288 = V_235;
		if (!L_1288)
		{
			goto IL_29e6;
		}
	}
	{
		int32_t L_1289 = __this->___m_FirstOverflowCharacterIndex;
		V_236 = (bool)((((int32_t)L_1289) == ((int32_t)(-1)))? 1 : 0);
		bool L_1290 = V_236;
		if (!L_1290)
		{
			goto IL_26bb;
		}
	}
	{
		int32_t L_1291 = __this->___m_CharacterCount;
		__this->___m_FirstOverflowCharacterIndex = L_1291;
	}

IL_26bb:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1292 = ___0_generationSettings;
		NullCheck(L_1292);
		bool L_1293 = L_1292->___autoSize;
		V_237 = L_1293;
		bool L_1294 = V_237;
		if (!L_1294)
		{
			goto IL_285a;
		}
	}
	{
		float L_1295 = __this->___m_LineSpacingDelta;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1296 = ___0_generationSettings;
		NullCheck(L_1296);
		float L_1297 = L_1296->___lineSpacingMax;
		if ((!(((float)L_1295) > ((float)L_1297))))
		{
			goto IL_26e9;
		}
	}
	{
		int32_t L_1298 = __this->___m_AutoSizeIterationCount;
		int32_t L_1299 = __this->___m_AutoSizeMaxIterationCount;
		G_B386_0 = ((((int32_t)L_1298) < ((int32_t)L_1299))? 1 : 0);
		goto IL_26ea;
	}

IL_26e9:
	{
		G_B386_0 = 0;
	}

IL_26ea:
	{
		V_238 = (bool)G_B386_0;
		bool L_1300 = V_238;
		if (!L_1300)
		{
			goto IL_2723;
		}
	}
	{
		float L_1301 = V_21;
		float L_1302 = V_218;
		int32_t L_1303 = __this->___m_LineNumber;
		V_239 = ((float)(((float)il2cpp_codegen_subtract(L_1301, L_1302))/((float)((int32_t)il2cpp_codegen_add(L_1303, 1)))));
		float L_1304 = __this->___m_LineSpacingDelta;
		float L_1305 = V_239;
		float L_1306 = V_1;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1307 = ___0_generationSettings;
		NullCheck(L_1307);
		float L_1308 = L_1307->___lineSpacingMax;
		float L_1309;
		L_1309 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(((float)il2cpp_codegen_add(L_1304, ((float)(L_1305/L_1306)))), L_1308, NULL);
		__this->___m_LineSpacingDelta = L_1309;
		goto IL_88b4;
	}

IL_2723:
	{
		float L_1310 = __this->___m_CharWidthAdjDelta;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1311 = ___0_generationSettings;
		NullCheck(L_1311);
		float L_1312 = L_1311->___charWidthMaxAdj;
		if ((!(((float)L_1310) < ((float)((float)(L_1312/(100.0f)))))))
		{
			goto IL_2747;
		}
	}
	{
		int32_t L_1313 = __this->___m_AutoSizeIterationCount;
		int32_t L_1314 = __this->___m_AutoSizeMaxIterationCount;
		G_B391_0 = ((((int32_t)L_1313) < ((int32_t)L_1314))? 1 : 0);
		goto IL_2748;
	}

IL_2747:
	{
		G_B391_0 = 0;
	}

IL_2748:
	{
		V_240 = (bool)G_B391_0;
		bool L_1315 = V_240;
		if (!L_1315)
		{
			goto IL_27c9;
		}
	}
	{
		float L_1316 = V_197;
		V_241 = L_1316;
		float L_1317 = __this->___m_CharWidthAdjDelta;
		V_243 = (bool)((((float)L_1317) > ((float)(0.0f)))? 1 : 0);
		bool L_1318 = V_243;
		if (!L_1318)
		{
			goto IL_2777;
		}
	}
	{
		float L_1319 = V_241;
		float L_1320 = __this->___m_CharWidthAdjDelta;
		V_241 = ((float)(L_1319/((float)il2cpp_codegen_subtract((1.0f), L_1320))));
	}

IL_2777:
	{
		float L_1321 = V_197;
		float L_1322 = V_22;
		bool L_1323 = V_89;
		if (L_1323)
		{
			G_B396_0 = ((float)il2cpp_codegen_subtract(L_1322, (9.99999975E-05f)));
			G_B396_1 = L_1321;
			goto IL_278c;
		}
		G_B395_0 = ((float)il2cpp_codegen_subtract(L_1322, (9.99999975E-05f)));
		G_B395_1 = L_1321;
	}
	{
		G_B397_0 = (1.0f);
		G_B397_1 = G_B395_0;
		G_B397_2 = G_B395_1;
		goto IL_2791;
	}

IL_278c:
	{
		G_B397_0 = (1.04999995f);
		G_B397_1 = G_B396_0;
		G_B397_2 = G_B396_1;
	}

IL_2791:
	{
		V_242 = ((float)il2cpp_codegen_subtract(G_B397_2, ((float)il2cpp_codegen_multiply(G_B397_1, G_B397_0))));
		float L_1324 = __this->___m_CharWidthAdjDelta;
		float L_1325 = V_242;
		float L_1326 = V_241;
		__this->___m_CharWidthAdjDelta = ((float)il2cpp_codegen_add(L_1324, ((float)(L_1325/L_1326))));
		float L_1327 = __this->___m_CharWidthAdjDelta;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1328 = ___0_generationSettings;
		NullCheck(L_1328);
		float L_1329 = L_1328->___charWidthMaxAdj;
		float L_1330;
		L_1330 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_1327, ((float)(L_1329/(100.0f))), NULL);
		__this->___m_CharWidthAdjDelta = L_1330;
		goto IL_88b4;
	}

IL_27c9:
	{
		float L_1331 = __this->___m_FontSize;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1332 = ___0_generationSettings;
		NullCheck(L_1332);
		float L_1333 = L_1332->___fontSizeMin;
		if ((!(((float)L_1331) > ((float)L_1333))))
		{
			goto IL_27e7;
		}
	}
	{
		int32_t L_1334 = __this->___m_AutoSizeIterationCount;
		int32_t L_1335 = __this->___m_AutoSizeMaxIterationCount;
		G_B401_0 = ((((int32_t)L_1334) < ((int32_t)L_1335))? 1 : 0);
		goto IL_27e8;
	}

IL_27e7:
	{
		G_B401_0 = 0;
	}

IL_27e8:
	{
		V_244 = (bool)G_B401_0;
		bool L_1336 = V_244;
		if (!L_1336)
		{
			goto IL_2859;
		}
	}
	{
		float L_1337 = __this->___m_FontSize;
		__this->___m_MaxFontSize = L_1337;
		float L_1338 = __this->___m_FontSize;
		float L_1339 = __this->___m_MinFontSize;
		float L_1340;
		L_1340 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(((float)(((float)il2cpp_codegen_subtract(L_1338, L_1339))/(2.0f))), (0.0500000007f), NULL);
		V_245 = L_1340;
		float L_1341 = __this->___m_FontSize;
		float L_1342 = V_245;
		__this->___m_FontSize = ((float)il2cpp_codegen_subtract(L_1341, L_1342));
		float L_1343 = __this->___m_FontSize;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1344 = ___0_generationSettings;
		NullCheck(L_1344);
		float L_1345 = L_1344->___fontSizeMin;
		float L_1346;
		L_1346 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(((float)(((float)il2cpp_codegen_cast_double_to_int<int32_t>(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_1343, (20.0f))), (0.5f)))))/(20.0f))), L_1345, NULL);
		__this->___m_FontSize = L_1346;
		goto IL_88b4;
	}

IL_2859:
	{
	}

IL_285a:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1347 = ___0_generationSettings;
		NullCheck(L_1347);
		int32_t L_1348 = L_1347->___overflowMode;
		V_248 = L_1348;
		int32_t L_1349 = V_248;
		V_247 = L_1349;
		int32_t L_1350 = V_247;
		switch (L_1350)
		{
			case 0:
			{
				goto IL_288e;
			}
			case 1:
			{
				goto IL_28d8;
			}
			case 2:
			{
				goto IL_288e;
			}
			case 3:
			{
				goto IL_28b3;
			}
			case 4:
			{
				goto IL_288e;
			}
			case 5:
			{
				goto IL_297d;
			}
			case 6:
			{
				goto IL_2963;
			}
		}
	}
	{
		goto IL_29e3;
	}

IL_288e:
	{
		int32_t L_1351 = V_62;
		float L_1352 = V_1;
		float L_1353 = V_2;
		float L_1354 = V_3;
		float L_1355 = V_78;
		float L_1356 = V_75;
		float L_1357 = V_22;
		float L_1358 = V_16;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1359 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1360 = ___1_textInfo;
		TextGenerator_InsertNewLine_m00109EA00343212A7FD05D49E7DBF81DBFE4B5E4(__this, L_1351, L_1352, L_1353, L_1354, L_1355, L_1356, L_1357, L_1358, (&V_24), (&V_23), L_1359, L_1360, NULL);
		V_17 = (bool)1;
		V_25 = (bool)1;
		goto IL_43d7;
	}

IL_28b3:
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1361 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedLastValidState);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1362 = ___1_textInfo;
		int32_t L_1363;
		L_1363 = TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61(__this, L_1361, L_1362, NULL);
		V_62 = L_1363;
		int32_t L_1364 = V_199;
		(&V_28)->___index = L_1364;
		(&V_28)->___unicode = 3;
		goto IL_43d7;
	}

IL_28d8:
	{
		TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9* L_1365 = (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9*)(&__this->___m_EllipsisInsertionCandidateStack);
		int32_t L_1366;
		L_1366 = TextProcessingStack_1_get_Count_m019E4780B26C3C62C2C3E1BA49A5B47266DC65AC(L_1365, TextProcessingStack_1_get_Count_m019E4780B26C3C62C2C3E1BA49A5B47266DC65AC_RuntimeMethod_var);
		V_249 = (bool)((((int32_t)L_1366) == ((int32_t)0))? 1 : 0);
		bool L_1367 = V_249;
		if (!L_1367)
		{
			goto IL_2913;
		}
	}
	{
		V_62 = (-1);
		__this->___m_CharacterCount = 0;
		(&V_28)->___index = 0;
		(&V_28)->___unicode = 3;
		__this->___m_FirstCharacterOfLine = 0;
		goto IL_43d7;
	}

IL_2913:
	{
		TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9* L_1368 = (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9*)(&__this->___m_EllipsisInsertionCandidateStack);
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 L_1369;
		L_1369 = TextProcessingStack_1_Pop_mBDDB87E018CFAAA932187B334ABB0237AB9D73B8(L_1368, TextProcessingStack_1_Pop_mBDDB87E018CFAAA932187B334ABB0237AB9D73B8_RuntimeMethod_var);
		V_246 = L_1369;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1370 = ___1_textInfo;
		int32_t L_1371;
		L_1371 = TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61(__this, (&V_246), L_1370, NULL);
		V_62 = L_1371;
		int32_t L_1372 = V_62;
		V_62 = ((int32_t)il2cpp_codegen_subtract(L_1372, 1));
		int32_t L_1373 = __this->___m_CharacterCount;
		__this->___m_CharacterCount = ((int32_t)il2cpp_codegen_subtract(L_1373, 1));
		int32_t L_1374 = __this->___m_CharacterCount;
		(&V_28)->___index = L_1374;
		(&V_28)->___unicode = ((int32_t)8230);
		int32_t L_1375 = V_32;
		V_32 = ((int32_t)il2cpp_codegen_add(L_1375, 1));
		goto IL_43d7;
	}

IL_2963:
	{
		int32_t L_1376 = __this->___m_CharacterCount;
		(&V_28)->___index = L_1376;
		(&V_28)->___unicode = 3;
		goto IL_43d7;
	}

IL_297d:
	{
		__this->___m_IsNewPage = (bool)1;
		int32_t L_1377 = V_62;
		float L_1378 = V_1;
		float L_1379 = V_2;
		float L_1380 = V_3;
		float L_1381 = V_78;
		float L_1382 = V_75;
		float L_1383 = V_22;
		float L_1384 = V_16;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1385 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1386 = ___1_textInfo;
		TextGenerator_InsertNewLine_m00109EA00343212A7FD05D49E7DBF81DBFE4B5E4(__this, L_1377, L_1378, L_1379, L_1380, L_1381, L_1382, L_1383, L_1384, (&V_24), (&V_23), L_1385, L_1386, NULL);
		__this->___m_StartOfLineAscender = (0.0f);
		__this->___m_LineOffset = (0.0f);
		__this->___m_MaxAscender = (0.0f);
		__this->___m_PageAscender = (0.0f);
		int32_t L_1387 = __this->___m_PageNumber;
		__this->___m_PageNumber = ((int32_t)il2cpp_codegen_add(L_1387, 1));
		V_17 = (bool)1;
		V_25 = (bool)1;
		goto IL_43d7;
	}

IL_29e3:
	{
		goto IL_2a0c;
	}

IL_29e6:
	{
		int32_t L_1388 = V_62;
		float L_1389 = V_1;
		float L_1390 = V_2;
		float L_1391 = V_3;
		float L_1392 = V_78;
		float L_1393 = V_75;
		float L_1394 = V_22;
		float L_1395 = V_16;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1396 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1397 = ___1_textInfo;
		TextGenerator_InsertNewLine_m00109EA00343212A7FD05D49E7DBF81DBFE4B5E4(__this, L_1388, L_1389, L_1390, L_1391, L_1392, L_1393, L_1394, L_1395, (&V_24), (&V_23), L_1396, L_1397, NULL);
		V_17 = (bool)1;
		V_25 = (bool)1;
		goto IL_43d7;
	}

IL_2a0c:
	{
		goto IL_2c8e;
	}

IL_2a12:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1398 = ___0_generationSettings;
		NullCheck(L_1398);
		bool L_1399 = L_1398->___autoSize;
		if (!L_1399)
		{
			goto IL_2a2b;
		}
	}
	{
		int32_t L_1400 = __this->___m_AutoSizeIterationCount;
		int32_t L_1401 = __this->___m_AutoSizeMaxIterationCount;
		G_B419_0 = ((((int32_t)L_1400) < ((int32_t)L_1401))? 1 : 0);
		goto IL_2a2c;
	}

IL_2a2b:
	{
		G_B419_0 = 0;
	}

IL_2a2c:
	{
		V_250 = (bool)G_B419_0;
		bool L_1402 = V_250;
		if (!L_1402)
		{
			goto IL_2b5b;
		}
	}
	{
		float L_1403 = __this->___m_CharWidthAdjDelta;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1404 = ___0_generationSettings;
		NullCheck(L_1404);
		float L_1405 = L_1404->___charWidthMaxAdj;
		V_251 = (bool)((((float)L_1403) < ((float)((float)(L_1405/(100.0f)))))? 1 : 0);
		bool L_1406 = V_251;
		if (!L_1406)
		{
			goto IL_2acb;
		}
	}
	{
		float L_1407 = V_197;
		V_252 = L_1407;
		float L_1408 = __this->___m_CharWidthAdjDelta;
		V_254 = (bool)((((float)L_1408) > ((float)(0.0f)))? 1 : 0);
		bool L_1409 = V_254;
		if (!L_1409)
		{
			goto IL_2a79;
		}
	}
	{
		float L_1410 = V_252;
		float L_1411 = __this->___m_CharWidthAdjDelta;
		V_252 = ((float)(L_1410/((float)il2cpp_codegen_subtract((1.0f), L_1411))));
	}

IL_2a79:
	{
		float L_1412 = V_197;
		float L_1413 = V_22;
		bool L_1414 = V_89;
		if (L_1414)
		{
			G_B425_0 = ((float)il2cpp_codegen_subtract(L_1413, (9.99999975E-05f)));
			G_B425_1 = L_1412;
			goto IL_2a8e;
		}
		G_B424_0 = ((float)il2cpp_codegen_subtract(L_1413, (9.99999975E-05f)));
		G_B424_1 = L_1412;
	}
	{
		G_B426_0 = (1.0f);
		G_B426_1 = G_B424_0;
		G_B426_2 = G_B424_1;
		goto IL_2a93;
	}

IL_2a8e:
	{
		G_B426_0 = (1.04999995f);
		G_B426_1 = G_B425_0;
		G_B426_2 = G_B425_1;
	}

IL_2a93:
	{
		V_253 = ((float)il2cpp_codegen_subtract(G_B426_2, ((float)il2cpp_codegen_multiply(G_B426_1, G_B426_0))));
		float L_1415 = __this->___m_CharWidthAdjDelta;
		float L_1416 = V_253;
		float L_1417 = V_252;
		__this->___m_CharWidthAdjDelta = ((float)il2cpp_codegen_add(L_1415, ((float)(L_1416/L_1417))));
		float L_1418 = __this->___m_CharWidthAdjDelta;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1419 = ___0_generationSettings;
		NullCheck(L_1419);
		float L_1420 = L_1419->___charWidthMaxAdj;
		float L_1421;
		L_1421 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_1418, ((float)(L_1420/(100.0f))), NULL);
		__this->___m_CharWidthAdjDelta = L_1421;
		goto IL_88b4;
	}

IL_2acb:
	{
		float L_1422 = __this->___m_FontSize;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1423 = ___0_generationSettings;
		NullCheck(L_1423);
		float L_1424 = L_1423->___fontSizeMin;
		V_255 = (bool)((((float)L_1422) > ((float)L_1424))? 1 : 0);
		bool L_1425 = V_255;
		if (!L_1425)
		{
			goto IL_2b5a;
		}
	}
	{
		float L_1426 = __this->___m_FontSize;
		__this->___m_MaxFontSize = L_1426;
		float L_1427 = __this->___m_FontSize;
		float L_1428 = __this->___m_MinFontSize;
		float L_1429;
		L_1429 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(((float)(((float)il2cpp_codegen_subtract(L_1427, L_1428))/(2.0f))), (0.0500000007f), NULL);
		V_256 = L_1429;
		float L_1430 = __this->___m_FontSize;
		float L_1431 = V_256;
		__this->___m_FontSize = ((float)il2cpp_codegen_subtract(L_1430, L_1431));
		float L_1432 = __this->___m_FontSize;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1433 = ___0_generationSettings;
		NullCheck(L_1433);
		float L_1434 = L_1433->___fontSizeMin;
		float L_1435;
		L_1435 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(((float)(((float)il2cpp_codegen_cast_double_to_int<int32_t>(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_1432, (20.0f))), (0.5f)))))/(20.0f))), L_1434, NULL);
		__this->___m_FontSize = L_1435;
		goto IL_88b4;
	}

IL_2b5a:
	{
	}

IL_2b5b:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1436 = ___0_generationSettings;
		NullCheck(L_1436);
		int32_t L_1437 = L_1436->___overflowMode;
		V_259 = L_1437;
		int32_t L_1438 = V_259;
		V_258 = L_1438;
		int32_t L_1439 = V_258;
		switch (L_1439)
		{
			case 0:
			{
				goto IL_2b9f;
			}
			case 1:
			{
				goto IL_2bc9;
			}
			case 2:
			{
				goto IL_2b9f;
			}
			case 3:
			{
				goto IL_2ba4;
			}
			case 4:
			{
				goto IL_2b9f;
			}
			case 5:
			{
				goto IL_2c8d;
			}
			case 6:
			{
				goto IL_2c64;
			}
		}
	}
	{
		goto IL_2c8d;
	}

IL_2b9f:
	{
		goto IL_2c8d;
	}

IL_2ba4:
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1440 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedWordWrapState);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1441 = ___1_textInfo;
		int32_t L_1442;
		L_1442 = TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61(__this, L_1440, L_1441, NULL);
		V_62 = L_1442;
		int32_t L_1443 = V_199;
		(&V_28)->___index = L_1443;
		(&V_28)->___unicode = 3;
		goto IL_43d7;
	}

IL_2bc9:
	{
		TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9* L_1444 = (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9*)(&__this->___m_EllipsisInsertionCandidateStack);
		int32_t L_1445;
		L_1445 = TextProcessingStack_1_get_Count_m019E4780B26C3C62C2C3E1BA49A5B47266DC65AC(L_1444, TextProcessingStack_1_get_Count_m019E4780B26C3C62C2C3E1BA49A5B47266DC65AC_RuntimeMethod_var);
		V_260 = (bool)((((int32_t)L_1445) == ((int32_t)0))? 1 : 0);
		bool L_1446 = V_260;
		if (!L_1446)
		{
			goto IL_2c0c;
		}
	}
	{
		V_62 = (-1);
		__this->___m_CharacterCount = 0;
		(&V_28)->___index = 0;
		(&V_28)->___unicode = 3;
		__this->___m_FirstCharacterOfLine = 0;
		goto IL_43d7;
	}

IL_2c0c:
	{
		TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9* L_1447 = (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9*)(&__this->___m_EllipsisInsertionCandidateStack);
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 L_1448;
		L_1448 = TextProcessingStack_1_Pop_mBDDB87E018CFAAA932187B334ABB0237AB9D73B8(L_1447, TextProcessingStack_1_Pop_mBDDB87E018CFAAA932187B334ABB0237AB9D73B8_RuntimeMethod_var);
		V_257 = L_1448;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1449 = ___1_textInfo;
		int32_t L_1450;
		L_1450 = TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61(__this, (&V_257), L_1449, NULL);
		V_62 = L_1450;
		int32_t L_1451 = V_62;
		V_62 = ((int32_t)il2cpp_codegen_subtract(L_1451, 1));
		int32_t L_1452 = __this->___m_CharacterCount;
		__this->___m_CharacterCount = ((int32_t)il2cpp_codegen_subtract(L_1452, 1));
		int32_t L_1453 = __this->___m_CharacterCount;
		(&V_28)->___index = L_1453;
		(&V_28)->___unicode = ((int32_t)8230);
		int32_t L_1454 = V_32;
		V_32 = ((int32_t)il2cpp_codegen_add(L_1454, 1));
		goto IL_43d7;
	}

IL_2c64:
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1455 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedWordWrapState);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1456 = ___1_textInfo;
		int32_t L_1457;
		L_1457 = TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61(__this, L_1455, L_1456, NULL);
		V_62 = L_1457;
		int32_t L_1458 = __this->___m_CharacterCount;
		(&V_28)->___index = L_1458;
		(&V_28)->___unicode = 3;
		goto IL_43d7;
	}

IL_2c8d:
	{
	}

IL_2c8e:
	{
	}

IL_2c8f:
	{
		bool L_1459 = V_73;
		V_261 = L_1459;
		bool L_1460 = V_261;
		if (!L_1460)
		{
			goto IL_2d52;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1461 = ___1_textInfo;
		NullCheck(L_1461);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1462 = L_1461->___textElementInfo;
		int32_t L_1463 = __this->___m_CharacterCount;
		NullCheck(L_1462);
		((L_1462)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1463)))->___isVisible = (bool)0;
		int32_t L_1464 = __this->___m_CharacterCount;
		__this->___m_LastVisibleCharacterOfLine = L_1464;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1465 = ___1_textInfo;
		NullCheck(L_1465);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1466 = L_1465->___lineInfo;
		int32_t L_1467 = __this->___m_LineNumber;
		NullCheck(L_1466);
		int32_t* L_1468 = (int32_t*)(&((L_1466)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1467)))->___spaceCount);
		V_262 = L_1468;
		int32_t* L_1469 = V_262;
		int32_t* L_1470 = V_262;
		int32_t L_1471 = *((int32_t*)L_1470);
		int32_t L_1472 = ((int32_t)il2cpp_codegen_add(L_1471, 1));
		V_158 = L_1472;
		*((int32_t*)L_1469) = (int32_t)L_1472;
		int32_t L_1473 = V_158;
		__this->___m_LineVisibleSpaceCount = L_1473;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1474 = ___1_textInfo;
		NullCheck(L_1474);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1475 = L_1474->___lineInfo;
		int32_t L_1476 = __this->___m_LineNumber;
		NullCheck(L_1475);
		float L_1477 = V_195;
		((L_1475)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1476)))->___marginLeft = L_1477;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1478 = ___1_textInfo;
		NullCheck(L_1478);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1479 = L_1478->___lineInfo;
		int32_t L_1480 = __this->___m_LineNumber;
		NullCheck(L_1479);
		float L_1481 = V_196;
		((L_1479)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1480)))->___marginRight = L_1481;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1482 = ___1_textInfo;
		V_263 = L_1482;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1483 = V_263;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1484 = V_263;
		NullCheck(L_1484);
		int32_t L_1485 = L_1484->___spaceCount;
		NullCheck(L_1483);
		L_1483->___spaceCount = ((int32_t)il2cpp_codegen_add(L_1485, 1));
		goto IL_2e78;
	}

IL_2d52:
	{
		uint32_t L_1486 = V_5;
		V_264 = (bool)((((int32_t)L_1486) == ((int32_t)((int32_t)173)))? 1 : 0);
		bool L_1487 = V_264;
		if (!L_1487)
		{
			goto IL_2d87;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1488 = ___1_textInfo;
		NullCheck(L_1488);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1489 = L_1488->___textElementInfo;
		int32_t L_1490 = __this->___m_CharacterCount;
		NullCheck(L_1489);
		((L_1489)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1490)))->___isVisible = (bool)0;
		goto IL_2e78;
	}

IL_2d87:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1491 = ___0_generationSettings;
		NullCheck(L_1491);
		bool L_1492 = L_1491->___overrideRichTextColors;
		V_266 = L_1492;
		bool L_1493 = V_266;
		if (!L_1493)
		{
			goto IL_2daa;
		}
	}
	{
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_1494 = __this->___m_FontColor32;
		V_265 = L_1494;
		goto IL_2db6;
	}

IL_2daa:
	{
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_1495 = __this->___m_HtmlColor;
		V_265 = L_1495;
	}

IL_2db6:
	{
		uint8_t L_1496 = __this->___m_TextElementType;
		V_267 = (bool)((((int32_t)L_1496) == ((int32_t)1))? 1 : 0);
		bool L_1497 = V_267;
		if (!L_1497)
		{
			goto IL_2de4;
		}
	}
	{
		float L_1498 = V_6;
		float L_1499 = V_79;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_1500 = V_265;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1501 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1502 = ___1_textInfo;
		TextGenerator_SaveGlyphVertexInfo_m0CD6E1D45488FFC6675294AC64F40AC23C986A09(__this, L_1498, L_1499, L_1500, L_1501, L_1502, NULL);
		goto IL_2e0c;
	}

IL_2de4:
	{
		uint8_t L_1503 = __this->___m_TextElementType;
		V_268 = (bool)((((int32_t)L_1503) == ((int32_t)2))? 1 : 0);
		bool L_1504 = V_268;
		if (!L_1504)
		{
			goto IL_2e0c;
		}
	}
	{
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_1505 = V_265;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1506 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1507 = ___1_textInfo;
		TextGenerator_SaveSpriteVertexInfo_m4B47901F01927E7CC4E486A1C4354AFBF4D138A5(__this, L_1505, L_1506, L_1507, NULL);
	}

IL_2e0c:
	{
		bool L_1508 = V_17;
		V_269 = L_1508;
		bool L_1509 = V_269;
		if (!L_1509)
		{
			goto IL_2e2d;
		}
	}
	{
		V_17 = (bool)0;
		int32_t L_1510 = __this->___m_CharacterCount;
		__this->___m_FirstVisibleCharacterOfLine = L_1510;
	}

IL_2e2d:
	{
		int32_t L_1511 = __this->___m_LineVisibleCharacterCount;
		__this->___m_LineVisibleCharacterCount = ((int32_t)il2cpp_codegen_add(L_1511, 1));
		int32_t L_1512 = __this->___m_CharacterCount;
		__this->___m_LastVisibleCharacterOfLine = L_1512;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1513 = ___1_textInfo;
		NullCheck(L_1513);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1514 = L_1513->___lineInfo;
		int32_t L_1515 = __this->___m_LineNumber;
		NullCheck(L_1514);
		float L_1516 = V_195;
		((L_1514)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1515)))->___marginLeft = L_1516;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1517 = ___1_textInfo;
		NullCheck(L_1517);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1518 = L_1517->___lineInfo;
		int32_t L_1519 = __this->___m_LineNumber;
		NullCheck(L_1518);
		float L_1520 = V_196;
		((L_1518)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1519)))->___marginRight = L_1520;
	}

IL_2e78:
	{
		goto IL_3062;
	}

IL_2e7e:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1521 = ___0_generationSettings;
		NullCheck(L_1521);
		int32_t L_1522 = L_1521->___overflowMode;
		if ((!(((uint32_t)L_1522) == ((uint32_t)6))))
		{
			goto IL_2e99;
		}
	}
	{
		uint32_t L_1523 = V_5;
		if ((((int32_t)L_1523) == ((int32_t)((int32_t)10))))
		{
			goto IL_2e96;
		}
	}
	{
		uint32_t L_1524 = V_5;
		G_B459_0 = ((((int32_t)L_1524) == ((int32_t)((int32_t)11)))? 1 : 0);
		goto IL_2e97;
	}

IL_2e96:
	{
		G_B459_0 = 1;
	}

IL_2e97:
	{
		G_B461_0 = G_B459_0;
		goto IL_2e9a;
	}

IL_2e99:
	{
		G_B461_0 = 0;
	}

IL_2e9a:
	{
		V_270 = (bool)G_B461_0;
		bool L_1525 = V_270;
		if (!L_1525)
		{
			goto IL_2f68;
		}
	}
	{
		float L_1526 = __this->___m_MaxAscender;
		float L_1527 = __this->___m_MaxLineDescender;
		float L_1528 = __this->___m_LineOffset;
		float L_1529 = __this->___m_LineOffset;
		if ((!(((float)L_1529) > ((float)(0.0f)))))
		{
			G_B464_0 = ((float)il2cpp_codegen_subtract(L_1526, ((float)il2cpp_codegen_subtract(L_1527, L_1528))));
			goto IL_2ed5;
		}
		G_B463_0 = ((float)il2cpp_codegen_subtract(L_1526, ((float)il2cpp_codegen_subtract(L_1527, L_1528))));
	}
	{
		bool L_1530 = __this->___m_IsDrivenLineSpacing;
		if (!L_1530)
		{
			G_B465_0 = G_B463_0;
			goto IL_2edc;
		}
		G_B464_0 = G_B463_0;
	}

IL_2ed5:
	{
		G_B466_0 = (0.0f);
		G_B466_1 = G_B464_0;
		goto IL_2ee9;
	}

IL_2edc:
	{
		float L_1531 = __this->___m_MaxLineAscender;
		float L_1532 = __this->___m_StartOfLineAscender;
		G_B466_0 = ((float)il2cpp_codegen_subtract(L_1531, L_1532));
		G_B466_1 = G_B465_0;
	}

IL_2ee9:
	{
		V_271 = ((float)il2cpp_codegen_add(G_B466_1, G_B466_0));
		int32_t L_1533 = __this->___m_CharacterCount;
		V_272 = L_1533;
		float L_1534 = V_271;
		float L_1535 = V_21;
		V_273 = (bool)((((float)L_1534) > ((float)((float)il2cpp_codegen_add(L_1535, (9.99999975E-05f)))))? 1 : 0);
		bool L_1536 = V_273;
		if (!L_1536)
		{
			goto IL_2f67;
		}
	}
	{
		int32_t L_1537 = __this->___m_FirstOverflowCharacterIndex;
		V_274 = (bool)((((int32_t)L_1537) == ((int32_t)(-1)))? 1 : 0);
		bool L_1538 = V_274;
		if (!L_1538)
		{
			goto IL_2f3e;
		}
	}
	{
		int32_t L_1539 = __this->___m_CharacterCount;
		__this->___m_FirstOverflowCharacterIndex = L_1539;
	}

IL_2f3e:
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1540 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedLastValidState);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1541 = ___1_textInfo;
		int32_t L_1542;
		L_1542 = TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61(__this, L_1540, L_1541, NULL);
		V_62 = L_1542;
		int32_t L_1543 = V_272;
		(&V_28)->___index = L_1543;
		(&V_28)->___unicode = 3;
		goto IL_43d7;
	}

IL_2f67:
	{
	}

IL_2f68:
	{
		uint32_t L_1544 = V_5;
		if ((((int32_t)L_1544) == ((int32_t)((int32_t)10))))
		{
			goto IL_2fa2;
		}
	}
	{
		uint32_t L_1545 = V_5;
		if ((((int32_t)L_1545) == ((int32_t)((int32_t)11))))
		{
			goto IL_2fa2;
		}
	}
	{
		uint32_t L_1546 = V_5;
		if ((((int32_t)L_1546) == ((int32_t)((int32_t)160))))
		{
			goto IL_2fa2;
		}
	}
	{
		uint32_t L_1547 = V_5;
		if ((((int32_t)L_1547) == ((int32_t)((int32_t)8199))))
		{
			goto IL_2fa2;
		}
	}
	{
		uint32_t L_1548 = V_5;
		if ((((int32_t)L_1548) == ((int32_t)((int32_t)8232))))
		{
			goto IL_2fa2;
		}
	}
	{
		uint32_t L_1549 = V_5;
		if ((((int32_t)L_1549) == ((int32_t)((int32_t)8233))))
		{
			goto IL_2fa2;
		}
	}
	{
		uint32_t L_1550 = V_5;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_1551;
		L_1551 = Char_IsSeparator_m8DBA05CCFA10131140E40057E6553F7AC7397BF9(((int32_t)(uint16_t)L_1550), NULL);
		if (!L_1551)
		{
			goto IL_2fc2;
		}
	}

IL_2fa2:
	{
		uint32_t L_1552 = V_5;
		if ((((int32_t)L_1552) == ((int32_t)((int32_t)173))))
		{
			goto IL_2fc2;
		}
	}
	{
		uint32_t L_1553 = V_5;
		if ((((int32_t)L_1553) == ((int32_t)((int32_t)8203))))
		{
			goto IL_2fc2;
		}
	}
	{
		uint32_t L_1554 = V_5;
		G_B482_0 = ((((int32_t)((((int32_t)L_1554) == ((int32_t)((int32_t)8288)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_2fc3;
	}

IL_2fc2:
	{
		G_B482_0 = 0;
	}

IL_2fc3:
	{
		V_275 = (bool)G_B482_0;
		bool L_1555 = V_275;
		if (!L_1555)
		{
			goto IL_301e;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1556 = ___1_textInfo;
		NullCheck(L_1556);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1557 = L_1556->___lineInfo;
		int32_t L_1558 = __this->___m_LineNumber;
		NullCheck(L_1557);
		int32_t* L_1559 = (int32_t*)(&((L_1557)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1558)))->___spaceCount);
		V_262 = L_1559;
		int32_t* L_1560 = V_262;
		int32_t* L_1561 = V_262;
		int32_t L_1562 = *((int32_t*)L_1561);
		*((int32_t*)L_1560) = (int32_t)((int32_t)il2cpp_codegen_add(L_1562, 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1563 = ___1_textInfo;
		V_263 = L_1563;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1564 = V_263;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1565 = V_263;
		NullCheck(L_1565);
		int32_t L_1566 = L_1565->___spaceCount;
		NullCheck(L_1564);
		L_1564->___spaceCount = ((int32_t)il2cpp_codegen_add(L_1566, 1));
	}

IL_301e:
	{
		uint32_t L_1567 = V_5;
		V_276 = (bool)((((int32_t)L_1567) == ((int32_t)((int32_t)160)))? 1 : 0);
		bool L_1568 = V_276;
		if (!L_1568)
		{
			goto IL_3061;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1569 = ___1_textInfo;
		NullCheck(L_1569);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1570 = L_1569->___lineInfo;
		int32_t L_1571 = __this->___m_LineNumber;
		NullCheck(L_1570);
		int32_t* L_1572 = (int32_t*)(&((L_1570)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1571)))->___controlCharacterCount);
		V_262 = L_1572;
		int32_t* L_1573 = V_262;
		int32_t* L_1574 = V_262;
		int32_t L_1575 = *((int32_t*)L_1574);
		*((int32_t*)L_1573) = (int32_t)((int32_t)il2cpp_codegen_add(L_1575, 1));
	}

IL_3061:
	{
	}

IL_3062:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1576 = ___0_generationSettings;
		NullCheck(L_1576);
		int32_t L_1577 = L_1576->___overflowMode;
		if ((!(((uint32_t)L_1577) == ((uint32_t)1))))
		{
			goto IL_307a;
		}
	}
	{
		bool L_1578 = V_65;
		if (!L_1578)
		{
			goto IL_3077;
		}
	}
	{
		uint32_t L_1579 = V_5;
		G_B491_0 = ((((int32_t)L_1579) == ((int32_t)((int32_t)45)))? 1 : 0);
		goto IL_3078;
	}

IL_3077:
	{
		G_B491_0 = 1;
	}

IL_3078:
	{
		G_B493_0 = G_B491_0;
		goto IL_307b;
	}

IL_307a:
	{
		G_B493_0 = 0;
	}

IL_307b:
	{
		V_277 = (bool)G_B493_0;
		bool L_1580 = V_277;
		if (!L_1580)
		{
			goto IL_3367;
		}
	}
	{
		float L_1581 = __this->___m_CurrentFontSize;
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_1582 = (SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD*)(&__this->___m_Ellipsis);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1583 = L_1582->___fontAsset;
		NullCheck(L_1583);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_1584 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_1583->___m_FaceInfo);
		int32_t L_1585;
		L_1585 = FaceInfo_get_pointSize_m7EF7429A4725AB715931A220F6BB498C3D6BF7CB(L_1584, NULL);
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_1586 = (SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD*)(&__this->___m_Ellipsis);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1587 = L_1586->___fontAsset;
		NullCheck(L_1587);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_1588 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_1587->___m_FaceInfo);
		float L_1589;
		L_1589 = FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD(L_1588, NULL);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1590 = ___0_generationSettings;
		NullCheck(L_1590);
		bool L_1591 = L_1590->___isOrthographic;
		if (L_1591)
		{
			G_B496_0 = ((float)il2cpp_codegen_multiply(((float)(L_1581/((float)L_1585))), L_1589));
			goto IL_30cf;
		}
		G_B495_0 = ((float)il2cpp_codegen_multiply(((float)(L_1581/((float)L_1585))), L_1589));
	}
	{
		G_B497_0 = (0.100000001f);
		G_B497_1 = G_B495_0;
		goto IL_30d4;
	}

IL_30cf:
	{
		G_B497_0 = (1.0f);
		G_B497_1 = G_B496_0;
	}

IL_30d4:
	{
		V_278 = ((float)il2cpp_codegen_multiply(G_B497_1, G_B497_0));
		float L_1592 = V_278;
		float L_1593 = __this->___m_FontScaleMultiplier;
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_1594 = (SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD*)(&__this->___m_Ellipsis);
		Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* L_1595 = L_1594->___character;
		NullCheck(L_1595);
		float L_1596 = ((TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA*)L_1595)->___m_Scale;
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_1597 = (SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD*)(&__this->___m_Ellipsis);
		Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* L_1598 = L_1597->___character;
		NullCheck(L_1598);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_1599 = ((TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA*)L_1598)->___m_Glyph;
		NullCheck(L_1599);
		float L_1600;
		L_1600 = Glyph_get_scale_m3ED738CBB032247526DB38161E180759B2D06F29(L_1599, NULL);
		V_279 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(L_1592, L_1593)), L_1596)), L_1600));
		float L_1601 = __this->___m_MarginLeft;
		V_280 = L_1601;
		float L_1602 = __this->___m_MarginRight;
		V_281 = L_1602;
		uint32_t L_1603 = V_5;
		if ((!(((uint32_t)L_1603) == ((uint32_t)((int32_t)10)))))
		{
			goto IL_3146;
		}
	}
	{
		int32_t L_1604 = __this->___m_CharacterCount;
		int32_t L_1605 = __this->___m_FirstCharacterOfLine;
		G_B500_0 = ((((int32_t)((((int32_t)L_1604) == ((int32_t)L_1605))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_3147;
	}

IL_3146:
	{
		G_B500_0 = 0;
	}

IL_3147:
	{
		V_285 = (bool)G_B500_0;
		bool L_1606 = V_285;
		if (!L_1606)
		{
			goto IL_322c;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1607 = ___1_textInfo;
		NullCheck(L_1607);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1608 = L_1607->___textElementInfo;
		int32_t L_1609 = __this->___m_CharacterCount;
		NullCheck(L_1608);
		float L_1610 = ((L_1608)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_1609, 1)))))->___pointSize;
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_1611 = (SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD*)(&__this->___m_Ellipsis);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1612 = L_1611->___fontAsset;
		NullCheck(L_1612);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_1613 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_1612->___m_FaceInfo);
		int32_t L_1614;
		L_1614 = FaceInfo_get_pointSize_m7EF7429A4725AB715931A220F6BB498C3D6BF7CB(L_1613, NULL);
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_1615 = (SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD*)(&__this->___m_Ellipsis);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1616 = L_1615->___fontAsset;
		NullCheck(L_1616);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_1617 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_1616->___m_FaceInfo);
		float L_1618;
		L_1618 = FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD(L_1617, NULL);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1619 = ___0_generationSettings;
		NullCheck(L_1619);
		bool L_1620 = L_1619->___isOrthographic;
		if (L_1620)
		{
			G_B503_0 = ((float)il2cpp_codegen_multiply(((float)(L_1610/((float)L_1614))), L_1618));
			goto IL_31ad;
		}
		G_B502_0 = ((float)il2cpp_codegen_multiply(((float)(L_1610/((float)L_1614))), L_1618));
	}
	{
		G_B504_0 = (0.100000001f);
		G_B504_1 = G_B502_0;
		goto IL_31b2;
	}

IL_31ad:
	{
		G_B504_0 = (1.0f);
		G_B504_1 = G_B503_0;
	}

IL_31b2:
	{
		V_278 = ((float)il2cpp_codegen_multiply(G_B504_1, G_B504_0));
		float L_1621 = V_278;
		float L_1622 = __this->___m_FontScaleMultiplier;
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_1623 = (SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD*)(&__this->___m_Ellipsis);
		Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* L_1624 = L_1623->___character;
		NullCheck(L_1624);
		float L_1625 = ((TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA*)L_1624)->___m_Scale;
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_1626 = (SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD*)(&__this->___m_Ellipsis);
		Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* L_1627 = L_1626->___character;
		NullCheck(L_1627);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_1628 = ((TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA*)L_1627)->___m_Glyph;
		NullCheck(L_1628);
		float L_1629;
		L_1629 = Glyph_get_scale_m3ED738CBB032247526DB38161E180759B2D06F29(L_1628, NULL);
		V_279 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(L_1621, L_1622)), L_1625)), L_1629));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1630 = ___1_textInfo;
		NullCheck(L_1630);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1631 = L_1630->___lineInfo;
		int32_t L_1632 = __this->___m_LineNumber;
		NullCheck(L_1631);
		float L_1633 = ((L_1631)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1632)))->___marginLeft;
		V_280 = L_1633;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1634 = ___1_textInfo;
		NullCheck(L_1634);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1635 = L_1634->___lineInfo;
		int32_t L_1636 = __this->___m_LineNumber;
		NullCheck(L_1635);
		float L_1637 = ((L_1635)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1636)))->___marginRight;
		V_281 = L_1637;
	}

IL_322c:
	{
		float L_1638 = __this->___m_MaxAscender;
		float L_1639 = __this->___m_MaxLineDescender;
		float L_1640 = __this->___m_LineOffset;
		float L_1641 = __this->___m_LineOffset;
		if ((!(((float)L_1641) > ((float)(0.0f)))))
		{
			G_B507_0 = ((float)il2cpp_codegen_subtract(L_1638, ((float)il2cpp_codegen_subtract(L_1639, L_1640))));
			goto IL_3255;
		}
		G_B506_0 = ((float)il2cpp_codegen_subtract(L_1638, ((float)il2cpp_codegen_subtract(L_1639, L_1640))));
	}
	{
		bool L_1642 = __this->___m_IsDrivenLineSpacing;
		if (!L_1642)
		{
			G_B508_0 = G_B506_0;
			goto IL_325c;
		}
		G_B507_0 = G_B506_0;
	}

IL_3255:
	{
		G_B509_0 = (0.0f);
		G_B509_1 = G_B507_0;
		goto IL_3269;
	}

IL_325c:
	{
		float L_1643 = __this->___m_MaxLineAscender;
		float L_1644 = __this->___m_StartOfLineAscender;
		G_B509_0 = ((float)il2cpp_codegen_subtract(L_1643, L_1644));
		G_B509_1 = G_B508_0;
	}

IL_3269:
	{
		V_282 = ((float)il2cpp_codegen_add(G_B509_1, G_B509_0));
		float L_1645 = __this->___m_XAdvance;
		float L_1646;
		L_1646 = fabsf(L_1645);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1647 = ___0_generationSettings;
		NullCheck(L_1647);
		bool L_1648 = L_1647->___isRightToLeft;
		if (!L_1648)
		{
			G_B511_0 = L_1646;
			goto IL_328a;
		}
		G_B510_0 = L_1646;
	}
	{
		G_B512_0 = (0.0f);
		G_B512_1 = G_B510_0;
		goto IL_32a8;
	}

IL_328a:
	{
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_1649 = (SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD*)(&__this->___m_Ellipsis);
		Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* L_1650 = L_1649->___character;
		NullCheck(L_1650);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_1651 = ((TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA*)L_1650)->___m_Glyph;
		NullCheck(L_1651);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_1652;
		L_1652 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_1651, NULL);
		V_116 = L_1652;
		float L_1653;
		L_1653 = GlyphMetrics_get_horizontalAdvance_m110E66C340A19E672FB1C26DFB875AB6900AFFF1((&V_116), NULL);
		G_B512_0 = L_1653;
		G_B512_1 = G_B511_0;
	}

IL_32a8:
	{
		float L_1654 = __this->___m_CharWidthAdjDelta;
		float L_1655 = V_279;
		V_283 = ((float)il2cpp_codegen_add(G_B512_1, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(G_B512_0, ((float)il2cpp_codegen_subtract((1.0f), L_1654)))), L_1655))));
		float L_1656 = __this->___m_Width;
		if ((!(((float)L_1656) == ((float)(-1.0f)))))
		{
			goto IL_32e8;
		}
	}
	{
		float L_1657 = V_20;
		float L_1658 = V_280;
		float L_1659 = V_281;
		G_B515_0 = ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_1657, (9.99999975E-05f))), L_1658)), L_1659));
		goto IL_3309;
	}

IL_32e8:
	{
		float L_1660 = V_20;
		float L_1661 = V_280;
		float L_1662 = V_281;
		float L_1663 = __this->___m_Width;
		float L_1664;
		L_1664 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_1660, (9.99999975E-05f))), L_1661)), L_1662)), L_1663, NULL);
		G_B515_0 = L_1664;
	}

IL_3309:
	{
		V_284 = G_B515_0;
		float L_1665 = V_283;
		float L_1666 = V_284;
		bool L_1667 = V_89;
		if (L_1667)
		{
			G_B517_0 = L_1666;
			G_B517_1 = L_1665;
			goto IL_3326;
		}
		G_B516_0 = L_1666;
		G_B516_1 = L_1665;
	}
	{
		G_B518_0 = (1.0f);
		G_B518_1 = G_B516_0;
		G_B518_2 = G_B516_1;
		goto IL_332b;
	}

IL_3326:
	{
		G_B518_0 = (1.04999995f);
		G_B518_1 = G_B517_0;
		G_B518_2 = G_B517_1;
	}

IL_332b:
	{
		V_286 = (bool)((((float)G_B518_2) < ((float)((float)il2cpp_codegen_multiply(G_B518_1, G_B518_0))))? 1 : 0);
		bool L_1668 = V_286;
		if (!L_1668)
		{
			goto IL_3366;
		}
	}
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1669 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedEllipsisState);
		int32_t L_1670 = V_62;
		int32_t L_1671 = __this->___m_CharacterCount;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1672 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_1669, L_1670, L_1671, L_1672, NULL);
		TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9* L_1673 = (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9*)(&__this->___m_EllipsisInsertionCandidateStack);
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 L_1674 = __this->___m_SavedEllipsisState;
		TextProcessingStack_1_Push_mD1A26596D8C31C64D82246093BF86E91410DD8BC(L_1673, L_1674, TextProcessingStack_1_Push_mD1A26596D8C31C64D82246093BF86E91410DD8BC_RuntimeMethod_var);
	}

IL_3366:
	{
	}

IL_3367:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1675 = ___1_textInfo;
		NullCheck(L_1675);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1676 = L_1675->___textElementInfo;
		int32_t L_1677 = __this->___m_CharacterCount;
		NullCheck(L_1676);
		int32_t L_1678 = __this->___m_LineNumber;
		((L_1676)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1677)))->___lineNumber = L_1678;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1679 = ___1_textInfo;
		NullCheck(L_1679);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1680 = L_1679->___textElementInfo;
		int32_t L_1681 = __this->___m_CharacterCount;
		NullCheck(L_1680);
		int32_t L_1682 = __this->___m_PageNumber;
		((L_1680)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1681)))->___pageNumber = L_1682;
		uint32_t L_1683 = V_5;
		if ((((int32_t)L_1683) == ((int32_t)((int32_t)10))))
		{
			goto IL_33b5;
		}
	}
	{
		uint32_t L_1684 = V_5;
		if ((((int32_t)L_1684) == ((int32_t)((int32_t)11))))
		{
			goto IL_33b5;
		}
	}
	{
		uint32_t L_1685 = V_5;
		if ((((int32_t)L_1685) == ((int32_t)((int32_t)13))))
		{
			goto IL_33b5;
		}
	}
	{
		bool L_1686 = V_65;
		if (!L_1686)
		{
			goto IL_33d0;
		}
	}

IL_33b5:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1687 = ___1_textInfo;
		NullCheck(L_1687);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1688 = L_1687->___lineInfo;
		int32_t L_1689 = __this->___m_LineNumber;
		NullCheck(L_1688);
		int32_t L_1690 = ((L_1688)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1689)))->___characterCount;
		G_B527_0 = ((((int32_t)L_1690) == ((int32_t)1))? 1 : 0);
		goto IL_33d1;
	}

IL_33d0:
	{
		G_B527_0 = 1;
	}

IL_33d1:
	{
		V_287 = (bool)G_B527_0;
		bool L_1691 = V_287;
		if (!L_1691)
		{
			goto IL_33fb;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1692 = ___1_textInfo;
		NullCheck(L_1692);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1693 = L_1692->___lineInfo;
		int32_t L_1694 = __this->___m_LineNumber;
		NullCheck(L_1693);
		int32_t L_1695 = __this->___m_LineJustification;
		((L_1693)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1694)))->___alignment = L_1695;
	}

IL_33fb:
	{
		uint32_t L_1696 = V_5;
		V_288 = (bool)((((int32_t)((((int32_t)L_1696) == ((int32_t)((int32_t)8203)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_1697 = V_288;
		if (!L_1697)
		{
			goto IL_3648;
		}
	}
	{
		uint32_t L_1698 = V_5;
		V_289 = (bool)((((int32_t)L_1698) == ((int32_t)((int32_t)9)))? 1 : 0);
		bool L_1699 = V_289;
		if (!L_1699)
		{
			goto IL_34a1;
		}
	}
	{
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1700 = __this->___m_CurrentFontAsset;
		NullCheck(L_1700);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* L_1701 = (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756*)(&L_1700->___m_FaceInfo);
		float L_1702;
		L_1702 = FaceInfo_get_tabWidth_mC6D9F42C40EDD767DE22050E4FBE3878AC96B161(L_1701, NULL);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1703 = __this->___m_CurrentFontAsset;
		NullCheck(L_1703);
		uint8_t L_1704;
		L_1704 = FontAsset_get_tabMultiple_m9C0422A00BFCF82091F14F4E303E2717247350AE(L_1703, NULL);
		float L_1705 = V_2;
		V_290 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(L_1702, ((float)L_1704))), L_1705));
		float L_1706 = __this->___m_XAdvance;
		float L_1707 = V_290;
		float L_1708;
		L_1708 = ceilf(((float)(L_1706/L_1707)));
		float L_1709 = V_290;
		V_291 = ((float)il2cpp_codegen_multiply(L_1708, L_1709));
		float L_1710 = V_291;
		float L_1711 = __this->___m_XAdvance;
		if ((((float)L_1710) > ((float)L_1711)))
		{
			G_B533_0 = __this;
			goto IL_3490;
		}
		G_B532_0 = __this;
	}
	{
		float L_1712 = __this->___m_XAdvance;
		float L_1713 = V_290;
		G_B534_0 = ((float)il2cpp_codegen_add(L_1712, L_1713));
		G_B534_1 = G_B532_0;
		goto IL_3496;
	}

IL_3490:
	{
		float L_1714 = V_291;
		G_B534_0 = L_1714;
		G_B534_1 = G_B533_0;
	}

IL_3496:
	{
		NullCheck(G_B534_1);
		G_B534_1->___m_XAdvance = G_B534_0;
		goto IL_3647;
	}

IL_34a1:
	{
		float L_1715 = __this->___m_MonoSpacing;
		V_292 = (bool)((((int32_t)((((float)L_1715) == ((float)(0.0f)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_1716 = V_292;
		if (!L_1716)
		{
			goto IL_3534;
		}
	}
	{
		float L_1717 = __this->___m_XAdvance;
		float L_1718 = __this->___m_MonoSpacing;
		float L_1719 = V_77;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1720 = __this->___m_CurrentFontAsset;
		NullCheck(L_1720);
		float L_1721;
		L_1721 = FontAsset_get_regularStyleSpacing_mB7EEEA236312F5AC31FD3B787808279206F521B1(L_1720, NULL);
		float L_1722 = V_75;
		float L_1723 = V_3;
		float L_1724 = __this->___m_CSpacing;
		float L_1725 = __this->___m_CharWidthAdjDelta;
		__this->___m_XAdvance = ((float)il2cpp_codegen_add(L_1717, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(L_1718, L_1719)), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_1721, L_1722)), L_1723)))), L_1724)), ((float)il2cpp_codegen_subtract((1.0f), L_1725))))));
		bool L_1726 = V_73;
		if (L_1726)
		{
			goto IL_350a;
		}
	}
	{
		uint32_t L_1727 = V_5;
		G_B539_0 = ((((int32_t)L_1727) == ((int32_t)((int32_t)8203)))? 1 : 0);
		goto IL_350b;
	}

IL_350a:
	{
		G_B539_0 = 1;
	}

IL_350b:
	{
		V_293 = (bool)G_B539_0;
		bool L_1728 = V_293;
		if (!L_1728)
		{
			goto IL_352e;
		}
	}
	{
		float L_1729 = __this->___m_XAdvance;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1730 = ___0_generationSettings;
		NullCheck(L_1730);
		float L_1731 = L_1730->___wordSpacing;
		float L_1732 = V_3;
		__this->___m_XAdvance = ((float)il2cpp_codegen_add(L_1729, ((float)il2cpp_codegen_multiply(L_1731, L_1732))));
	}

IL_352e:
	{
		goto IL_3647;
	}

IL_3534:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1733 = ___0_generationSettings;
		NullCheck(L_1733);
		bool L_1734 = L_1733->___isRightToLeft;
		V_294 = L_1734;
		bool L_1735 = V_294;
		if (!L_1735)
		{
			goto IL_35c0;
		}
	}
	{
		float L_1736 = __this->___m_XAdvance;
		float L_1737;
		L_1737 = GlyphValueRecord_get_xAdvance_m6C392027FA91E0705C1585C5EF40D984AAA0013E((&V_74), NULL);
		float L_1738 = V_2;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1739 = __this->___m_CurrentFontAsset;
		NullCheck(L_1739);
		float L_1740;
		L_1740 = FontAsset_get_regularStyleSpacing_mB7EEEA236312F5AC31FD3B787808279206F521B1(L_1739, NULL);
		float L_1741 = V_75;
		float L_1742 = V_78;
		float L_1743 = V_3;
		float L_1744 = __this->___m_CSpacing;
		float L_1745 = __this->___m_CharWidthAdjDelta;
		__this->___m_XAdvance = ((float)il2cpp_codegen_subtract(L_1736, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_1737, L_1738)), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_1740, L_1741)), L_1742)), L_1743)))), L_1744)), ((float)il2cpp_codegen_subtract((1.0f), L_1745))))));
		bool L_1746 = V_73;
		if (L_1746)
		{
			goto IL_3596;
		}
	}
	{
		uint32_t L_1747 = V_5;
		G_B546_0 = ((((int32_t)L_1747) == ((int32_t)((int32_t)8203)))? 1 : 0);
		goto IL_3597;
	}

IL_3596:
	{
		G_B546_0 = 1;
	}

IL_3597:
	{
		V_295 = (bool)G_B546_0;
		bool L_1748 = V_295;
		if (!L_1748)
		{
			goto IL_35ba;
		}
	}
	{
		float L_1749 = __this->___m_XAdvance;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1750 = ___0_generationSettings;
		NullCheck(L_1750);
		float L_1751 = L_1750->___wordSpacing;
		float L_1752 = V_3;
		__this->___m_XAdvance = ((float)il2cpp_codegen_subtract(L_1749, ((float)il2cpp_codegen_multiply(L_1751, L_1752))));
	}

IL_35ba:
	{
		goto IL_3647;
	}

IL_35c0:
	{
		float L_1753 = __this->___m_XAdvance;
		float L_1754;
		L_1754 = GlyphMetrics_get_horizontalAdvance_m110E66C340A19E672FB1C26DFB875AB6900AFFF1((&V_72), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_1755 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&__this->___m_FXScale);
		float L_1756 = L_1755->___x;
		float L_1757;
		L_1757 = GlyphValueRecord_get_xAdvance_m6C392027FA91E0705C1585C5EF40D984AAA0013E((&V_74), NULL);
		float L_1758 = V_2;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1759 = __this->___m_CurrentFontAsset;
		NullCheck(L_1759);
		float L_1760;
		L_1760 = FontAsset_get_regularStyleSpacing_mB7EEEA236312F5AC31FD3B787808279206F521B1(L_1759, NULL);
		float L_1761 = V_75;
		float L_1762 = V_78;
		float L_1763 = V_3;
		float L_1764 = __this->___m_CSpacing;
		float L_1765 = __this->___m_CharWidthAdjDelta;
		__this->___m_XAdvance = ((float)il2cpp_codegen_add(L_1753, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_1754, L_1756)), L_1757)), L_1758)), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_1760, L_1761)), L_1762)), L_1763)))), L_1764)), ((float)il2cpp_codegen_subtract((1.0f), L_1765))))));
		bool L_1766 = V_73;
		if (L_1766)
		{
			goto IL_3622;
		}
	}
	{
		uint32_t L_1767 = V_5;
		G_B552_0 = ((((int32_t)L_1767) == ((int32_t)((int32_t)8203)))? 1 : 0);
		goto IL_3623;
	}

IL_3622:
	{
		G_B552_0 = 1;
	}

IL_3623:
	{
		V_296 = (bool)G_B552_0;
		bool L_1768 = V_296;
		if (!L_1768)
		{
			goto IL_3646;
		}
	}
	{
		float L_1769 = __this->___m_XAdvance;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1770 = ___0_generationSettings;
		NullCheck(L_1770);
		float L_1771 = L_1770->___wordSpacing;
		float L_1772 = V_3;
		__this->___m_XAdvance = ((float)il2cpp_codegen_add(L_1769, ((float)il2cpp_codegen_multiply(L_1771, L_1772))));
	}

IL_3646:
	{
	}

IL_3647:
	{
	}

IL_3648:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1773 = ___1_textInfo;
		NullCheck(L_1773);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1774 = L_1773->___textElementInfo;
		int32_t L_1775 = __this->___m_CharacterCount;
		NullCheck(L_1774);
		float L_1776 = __this->___m_XAdvance;
		((L_1774)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1775)))->___xAdvance = L_1776;
		uint32_t L_1777 = V_5;
		V_297 = (bool)((((int32_t)L_1777) == ((int32_t)((int32_t)13)))? 1 : 0);
		bool L_1778 = V_297;
		if (!L_1778)
		{
			goto IL_368c;
		}
	}
	{
		float L_1779 = __this->___m_TagIndent;
		__this->___m_XAdvance = ((float)il2cpp_codegen_add((0.0f), L_1779));
	}

IL_368c:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1780 = ___0_generationSettings;
		NullCheck(L_1780);
		int32_t L_1781 = L_1780->___overflowMode;
		if ((!(((uint32_t)L_1781) == ((uint32_t)5))))
		{
			goto IL_36be;
		}
	}
	{
		uint32_t L_1782 = V_5;
		if ((((int32_t)L_1782) == ((int32_t)((int32_t)10))))
		{
			goto IL_36be;
		}
	}
	{
		uint32_t L_1783 = V_5;
		if ((((int32_t)L_1783) == ((int32_t)((int32_t)11))))
		{
			goto IL_36be;
		}
	}
	{
		uint32_t L_1784 = V_5;
		if ((((int32_t)L_1784) == ((int32_t)((int32_t)13))))
		{
			goto IL_36be;
		}
	}
	{
		uint32_t L_1785 = V_5;
		if ((((int32_t)L_1785) == ((int32_t)((int32_t)8232))))
		{
			goto IL_36be;
		}
	}
	{
		uint32_t L_1786 = V_5;
		G_B565_0 = ((((int32_t)((((int32_t)L_1786) == ((int32_t)((int32_t)8233)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_36bf;
	}

IL_36be:
	{
		G_B565_0 = 0;
	}

IL_36bf:
	{
		V_298 = (bool)G_B565_0;
		bool L_1787 = V_298;
		if (!L_1787)
		{
			goto IL_37ca;
		}
	}
	{
		int32_t L_1788 = __this->___m_PageNumber;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1789 = ___1_textInfo;
		NullCheck(L_1789);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1790 = L_1789->___pageInfo;
		NullCheck(L_1790);
		V_299 = (bool)((((int32_t)((int32_t)il2cpp_codegen_add(L_1788, 1))) > ((int32_t)((int32_t)(((RuntimeArray*)L_1790)->max_length))))? 1 : 0);
		bool L_1791 = V_299;
		if (!L_1791)
		{
			goto IL_3706;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1792 = ___1_textInfo;
		NullCheck(L_1792);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4** L_1793 = (PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4**)(&L_1792->___pageInfo);
		int32_t L_1794 = __this->___m_PageNumber;
		il2cpp_codegen_runtime_class_init_inline(TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09_il2cpp_TypeInfo_var);
		TextInfo_Resize_TisPageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909_m356AAB6CAA9298FF4C0E067A3ACE9A0AD2D78DE8(L_1793, ((int32_t)il2cpp_codegen_add(L_1794, 1)), (bool)1, TextInfo_Resize_TisPageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909_m356AAB6CAA9298FF4C0E067A3ACE9A0AD2D78DE8_RuntimeMethod_var);
	}

IL_3706:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1795 = ___1_textInfo;
		NullCheck(L_1795);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1796 = L_1795->___pageInfo;
		int32_t L_1797 = __this->___m_PageNumber;
		NullCheck(L_1796);
		float L_1798 = __this->___m_PageAscender;
		((L_1796)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1797)))->___ascender = L_1798;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1799 = ___1_textInfo;
		NullCheck(L_1799);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1800 = L_1799->___pageInfo;
		int32_t L_1801 = __this->___m_PageNumber;
		NullCheck(L_1800);
		float L_1802 = __this->___m_MaxDescender;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1803 = ___1_textInfo;
		NullCheck(L_1803);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1804 = L_1803->___pageInfo;
		int32_t L_1805 = __this->___m_PageNumber;
		NullCheck(L_1804);
		float L_1806 = ((L_1804)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1805)))->___descender;
		if ((((float)L_1802) < ((float)L_1806)))
		{
			G_B570_0 = ((L_1800)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1801)));
			goto IL_3769;
		}
		G_B569_0 = ((L_1800)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1801)));
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1807 = ___1_textInfo;
		NullCheck(L_1807);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1808 = L_1807->___pageInfo;
		int32_t L_1809 = __this->___m_PageNumber;
		NullCheck(L_1808);
		float L_1810 = ((L_1808)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1809)))->___descender;
		G_B571_0 = L_1810;
		G_B571_1 = G_B569_0;
		goto IL_376f;
	}

IL_3769:
	{
		float L_1811 = __this->___m_MaxDescender;
		G_B571_0 = L_1811;
		G_B571_1 = G_B570_0;
	}

IL_376f:
	{
		G_B571_1->___descender = G_B571_0;
		bool L_1812 = __this->___m_IsNewPage;
		V_300 = L_1812;
		bool L_1813 = V_300;
		if (!L_1813)
		{
			goto IL_37ad;
		}
	}
	{
		__this->___m_IsNewPage = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1814 = ___1_textInfo;
		NullCheck(L_1814);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1815 = L_1814->___pageInfo;
		int32_t L_1816 = __this->___m_PageNumber;
		NullCheck(L_1815);
		int32_t L_1817 = __this->___m_CharacterCount;
		((L_1815)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1816)))->___firstCharacterIndex = L_1817;
	}

IL_37ad:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1818 = ___1_textInfo;
		NullCheck(L_1818);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1819 = L_1818->___pageInfo;
		int32_t L_1820 = __this->___m_PageNumber;
		NullCheck(L_1819);
		int32_t L_1821 = __this->___m_CharacterCount;
		((L_1819)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1820)))->___lastCharacterIndex = L_1821;
	}

IL_37ca:
	{
		uint32_t L_1822 = V_5;
		if ((((int32_t)L_1822) == ((int32_t)((int32_t)10))))
		{
			goto IL_3805;
		}
	}
	{
		uint32_t L_1823 = V_5;
		if ((((int32_t)L_1823) == ((int32_t)((int32_t)11))))
		{
			goto IL_3805;
		}
	}
	{
		uint32_t L_1824 = V_5;
		if ((((int32_t)L_1824) == ((int32_t)3)))
		{
			goto IL_3805;
		}
	}
	{
		uint32_t L_1825 = V_5;
		if ((((int32_t)L_1825) == ((int32_t)((int32_t)8232))))
		{
			goto IL_3805;
		}
	}
	{
		uint32_t L_1826 = V_5;
		if ((((int32_t)L_1826) == ((int32_t)((int32_t)8233))))
		{
			goto IL_3805;
		}
	}
	{
		uint32_t L_1827 = V_5;
		bool L_1828 = V_65;
		if (((int32_t)(((((int32_t)L_1827) == ((int32_t)((int32_t)45)))? 1 : 0)&(int32_t)L_1828)))
		{
			goto IL_3805;
		}
	}
	{
		int32_t L_1829 = __this->___m_CharacterCount;
		int32_t L_1830 = V_0;
		G_B582_0 = ((((int32_t)L_1829) == ((int32_t)((int32_t)il2cpp_codegen_subtract(L_1830, 1))))? 1 : 0);
		goto IL_3806;
	}

IL_3805:
	{
		G_B582_0 = 1;
	}

IL_3806:
	{
		V_301 = (bool)G_B582_0;
		bool L_1831 = V_301;
		if (!L_1831)
		{
			goto IL_3fc3;
		}
	}
	{
		float L_1832 = __this->___m_MaxLineAscender;
		float L_1833 = __this->___m_StartOfLineAscender;
		V_302 = ((float)il2cpp_codegen_subtract(L_1832, L_1833));
		float L_1834 = __this->___m_LineOffset;
		if ((!(((float)L_1834) > ((float)(0.0f)))))
		{
			goto IL_385d;
		}
	}
	{
		float L_1835 = V_302;
		il2cpp_codegen_runtime_class_init_inline(Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var);
		float L_1836;
		L_1836 = fabsf(L_1835);
		if ((!(((float)L_1836) > ((float)(0.00999999978f)))))
		{
			goto IL_385d;
		}
	}
	{
		bool L_1837 = __this->___m_IsDrivenLineSpacing;
		if (L_1837)
		{
			goto IL_385d;
		}
	}
	{
		bool L_1838 = __this->___m_IsNewPage;
		G_B588_0 = ((((int32_t)L_1838) == ((int32_t)0))? 1 : 0);
		goto IL_385e;
	}

IL_385d:
	{
		G_B588_0 = 0;
	}

IL_385e:
	{
		V_306 = (bool)G_B588_0;
		bool L_1839 = V_306;
		if (!L_1839)
		{
			goto IL_3942;
		}
	}
	{
		int32_t L_1840 = __this->___m_FirstCharacterOfLine;
		int32_t L_1841 = __this->___m_CharacterCount;
		float L_1842 = V_302;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1843 = ___1_textInfo;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		TextGeneratorUtilities_AdjustLineOffset_m811C187EA3E41781116F0C7A679B05BB27874123(L_1840, L_1841, L_1842, L_1843, NULL);
		float L_1844 = __this->___m_MaxDescender;
		float L_1845 = V_302;
		__this->___m_MaxDescender = ((float)il2cpp_codegen_subtract(L_1844, L_1845));
		float L_1846 = __this->___m_LineOffset;
		float L_1847 = V_302;
		__this->___m_LineOffset = ((float)il2cpp_codegen_add(L_1846, L_1847));
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1848 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedEllipsisState);
		int32_t L_1849 = L_1848->___lineNumber;
		int32_t L_1850 = __this->___m_LineNumber;
		V_307 = (bool)((((int32_t)L_1849) == ((int32_t)L_1850))? 1 : 0);
		bool L_1851 = V_307;
		if (!L_1851)
		{
			goto IL_3941;
		}
	}
	{
		TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9* L_1852 = (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9*)(&__this->___m_EllipsisInsertionCandidateStack);
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 L_1853;
		L_1853 = TextProcessingStack_1_Pop_mBDDB87E018CFAAA932187B334ABB0237AB9D73B8(L_1852, TextProcessingStack_1_Pop_mBDDB87E018CFAAA932187B334ABB0237AB9D73B8_RuntimeMethod_var);
		__this->___m_SavedEllipsisState = L_1853;
		Il2CppCodeGenWriteBarrier((void**)&(((&__this->___m_SavedEllipsisState))->___textInfo), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&__this->___m_SavedEllipsisState))->___italicAngleStack))->___itemStack), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&__this->___m_SavedEllipsisState))->___colorStack))->___itemStack), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&__this->___m_SavedEllipsisState))->___underlineColorStack))->___itemStack), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&__this->___m_SavedEllipsisState))->___strikethroughColorStack))->___itemStack), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&__this->___m_SavedEllipsisState))->___highlightColorStack))->___itemStack), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&__this->___m_SavedEllipsisState))->___highlightStateStack))->___itemStack), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&__this->___m_SavedEllipsisState))->___colorGradientStack))->___itemStack), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&__this->___m_SavedEllipsisState))->___colorGradientStack))->___m_DefaultItem), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&__this->___m_SavedEllipsisState))->___sizeStack))->___itemStack), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&__this->___m_SavedEllipsisState))->___indentStack))->___itemStack), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&__this->___m_SavedEllipsisState))->___fontWeightStack))->___itemStack), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&__this->___m_SavedEllipsisState))->___styleStack))->___itemStack), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&__this->___m_SavedEllipsisState))->___baselineStack))->___itemStack), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&__this->___m_SavedEllipsisState))->___actionStack))->___itemStack), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&__this->___m_SavedEllipsisState))->___materialReferenceStack))->___itemStack), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&__this->___m_SavedEllipsisState))->___materialReferenceStack))->___m_DefaultItem))->___fontAsset), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&__this->___m_SavedEllipsisState))->___materialReferenceStack))->___m_DefaultItem))->___spriteAsset), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&__this->___m_SavedEllipsisState))->___materialReferenceStack))->___m_DefaultItem))->___material), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&__this->___m_SavedEllipsisState))->___materialReferenceStack))->___m_DefaultItem))->___fallbackMaterial), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&__this->___m_SavedEllipsisState))->___lineJustificationStack))->___itemStack), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&__this->___m_SavedEllipsisState))->___currentFontAsset), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&__this->___m_SavedEllipsisState))->___currentSpriteAsset), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&__this->___m_SavedEllipsisState))->___currentMaterial), (void*)NULL);
		#endif
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1854 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedEllipsisState);
		float* L_1855 = (float*)(&L_1854->___startOfLineAscender);
		V_308 = L_1855;
		float* L_1856 = V_308;
		float* L_1857 = V_308;
		float L_1858 = *((float*)L_1857);
		float L_1859 = V_302;
		*((float*)L_1856) = (float)((float)il2cpp_codegen_add(L_1858, L_1859));
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1860 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedEllipsisState);
		float* L_1861 = (float*)(&L_1860->___lineOffset);
		V_308 = L_1861;
		float* L_1862 = V_308;
		float* L_1863 = V_308;
		float L_1864 = *((float*)L_1863);
		float L_1865 = V_302;
		*((float*)L_1862) = (float)((float)il2cpp_codegen_add(L_1864, L_1865));
		TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9* L_1866 = (TextProcessingStack_1_t8814E7908ACCB94AA483D50DE909AFC9826508C9*)(&__this->___m_EllipsisInsertionCandidateStack);
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 L_1867 = __this->___m_SavedEllipsisState;
		TextProcessingStack_1_Push_mD1A26596D8C31C64D82246093BF86E91410DD8BC(L_1866, L_1867, TextProcessingStack_1_Push_mD1A26596D8C31C64D82246093BF86E91410DD8BC_RuntimeMethod_var);
	}

IL_3941:
	{
	}

IL_3942:
	{
		__this->___m_IsNewPage = (bool)0;
		float L_1868 = __this->___m_MaxLineAscender;
		float L_1869 = __this->___m_LineOffset;
		V_303 = ((float)il2cpp_codegen_subtract(L_1868, L_1869));
		float L_1870 = __this->___m_MaxLineDescender;
		float L_1871 = __this->___m_LineOffset;
		V_304 = ((float)il2cpp_codegen_subtract(L_1870, L_1871));
		float L_1872 = __this->___m_MaxDescender;
		float L_1873 = V_304;
		if ((((float)L_1872) < ((float)L_1873)))
		{
			G_B594_0 = __this;
			goto IL_3986;
		}
		G_B593_0 = __this;
	}
	{
		float L_1874 = V_304;
		G_B595_0 = L_1874;
		G_B595_1 = G_B593_0;
		goto IL_398c;
	}

IL_3986:
	{
		float L_1875 = __this->___m_MaxDescender;
		G_B595_0 = L_1875;
		G_B595_1 = G_B594_0;
	}

IL_398c:
	{
		NullCheck(G_B595_1);
		G_B595_1->___m_MaxDescender = G_B595_0;
		bool L_1876 = V_24;
		V_309 = (bool)((((int32_t)L_1876) == ((int32_t)0))? 1 : 0);
		bool L_1877 = V_309;
		if (!L_1877)
		{
			goto IL_39ac;
		}
	}
	{
		float L_1878 = __this->___m_MaxDescender;
		V_23 = L_1878;
	}

IL_39ac:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1879 = ___0_generationSettings;
		NullCheck(L_1879);
		bool L_1880 = L_1879->___useMaxVisibleDescender;
		if (!L_1880)
		{
			goto IL_39d8;
		}
	}
	{
		int32_t L_1881 = __this->___m_CharacterCount;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1882 = ___0_generationSettings;
		NullCheck(L_1882);
		int32_t L_1883 = L_1882->___maxVisibleCharacters;
		if ((((int32_t)L_1881) >= ((int32_t)L_1883)))
		{
			goto IL_39d5;
		}
	}
	{
		int32_t L_1884 = __this->___m_LineNumber;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1885 = ___0_generationSettings;
		NullCheck(L_1885);
		int32_t L_1886 = L_1885->___maxVisibleLines;
		G_B601_0 = ((((int32_t)((((int32_t)L_1884) < ((int32_t)L_1886))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_39d6;
	}

IL_39d5:
	{
		G_B601_0 = 1;
	}

IL_39d6:
	{
		G_B603_0 = G_B601_0;
		goto IL_39d9;
	}

IL_39d8:
	{
		G_B603_0 = 0;
	}

IL_39d9:
	{
		V_310 = (bool)G_B603_0;
		bool L_1887 = V_310;
		if (!L_1887)
		{
			goto IL_39ea;
		}
	}
	{
		V_24 = (bool)1;
	}

IL_39ea:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1888 = ___1_textInfo;
		NullCheck(L_1888);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1889 = L_1888->___lineInfo;
		int32_t L_1890 = __this->___m_LineNumber;
		NullCheck(L_1889);
		int32_t L_1891 = __this->___m_FirstCharacterOfLine;
		((L_1889)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1890)))->___firstCharacterIndex = L_1891;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1892 = ___1_textInfo;
		NullCheck(L_1892);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1893 = L_1892->___lineInfo;
		int32_t L_1894 = __this->___m_LineNumber;
		NullCheck(L_1893);
		int32_t L_1895 = __this->___m_FirstCharacterOfLine;
		int32_t L_1896 = __this->___m_FirstVisibleCharacterOfLine;
		if ((((int32_t)L_1895) > ((int32_t)L_1896)))
		{
			G_B607_0 = __this;
			G_B607_1 = ((L_1893)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1894)));
			goto IL_3a2e;
		}
		G_B606_0 = __this;
		G_B606_1 = ((L_1893)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1894)));
	}
	{
		int32_t L_1897 = __this->___m_FirstVisibleCharacterOfLine;
		G_B608_0 = L_1897;
		G_B608_1 = G_B606_0;
		G_B608_2 = G_B606_1;
		goto IL_3a34;
	}

IL_3a2e:
	{
		int32_t L_1898 = __this->___m_FirstCharacterOfLine;
		G_B608_0 = L_1898;
		G_B608_1 = G_B607_0;
		G_B608_2 = G_B607_1;
	}

IL_3a34:
	{
		int32_t L_1899 = G_B608_0;
		V_158 = L_1899;
		NullCheck(G_B608_1);
		G_B608_1->___m_FirstVisibleCharacterOfLine = L_1899;
		int32_t L_1900 = V_158;
		G_B608_2->___firstVisibleCharacterIndex = L_1900;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1901 = ___1_textInfo;
		NullCheck(L_1901);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1902 = L_1901->___lineInfo;
		int32_t L_1903 = __this->___m_LineNumber;
		NullCheck(L_1902);
		int32_t L_1904 = __this->___m_CharacterCount;
		int32_t L_1905 = L_1904;
		V_158 = L_1905;
		__this->___m_LastCharacterOfLine = L_1905;
		int32_t L_1906 = V_158;
		((L_1902)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1903)))->___lastCharacterIndex = L_1906;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1907 = ___1_textInfo;
		NullCheck(L_1907);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1908 = L_1907->___lineInfo;
		int32_t L_1909 = __this->___m_LineNumber;
		NullCheck(L_1908);
		int32_t L_1910 = __this->___m_LastVisibleCharacterOfLine;
		int32_t L_1911 = __this->___m_FirstVisibleCharacterOfLine;
		if ((((int32_t)L_1910) < ((int32_t)L_1911)))
		{
			G_B610_0 = __this;
			G_B610_1 = ((L_1908)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1909)));
			goto IL_3a92;
		}
		G_B609_0 = __this;
		G_B609_1 = ((L_1908)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1909)));
	}
	{
		int32_t L_1912 = __this->___m_LastVisibleCharacterOfLine;
		G_B611_0 = L_1912;
		G_B611_1 = G_B609_0;
		G_B611_2 = G_B609_1;
		goto IL_3a98;
	}

IL_3a92:
	{
		int32_t L_1913 = __this->___m_FirstVisibleCharacterOfLine;
		G_B611_0 = L_1913;
		G_B611_1 = G_B610_0;
		G_B611_2 = G_B610_1;
	}

IL_3a98:
	{
		int32_t L_1914 = G_B611_0;
		V_158 = L_1914;
		NullCheck(G_B611_1);
		G_B611_1->___m_LastVisibleCharacterOfLine = L_1914;
		int32_t L_1915 = V_158;
		G_B611_2->___lastVisibleCharacterIndex = L_1915;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1916 = ___1_textInfo;
		NullCheck(L_1916);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1917 = L_1916->___lineInfo;
		int32_t L_1918 = __this->___m_LineNumber;
		NullCheck(L_1917);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1919 = ___1_textInfo;
		NullCheck(L_1919);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1920 = L_1919->___lineInfo;
		int32_t L_1921 = __this->___m_LineNumber;
		NullCheck(L_1920);
		int32_t L_1922 = ((L_1920)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1921)))->___lastCharacterIndex;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1923 = ___1_textInfo;
		NullCheck(L_1923);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1924 = L_1923->___lineInfo;
		int32_t L_1925 = __this->___m_LineNumber;
		NullCheck(L_1924);
		int32_t L_1926 = ((L_1924)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1925)))->___firstCharacterIndex;
		((L_1917)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1918)))->___characterCount = ((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_subtract(L_1922, L_1926)), 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1927 = ___1_textInfo;
		NullCheck(L_1927);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1928 = L_1927->___lineInfo;
		int32_t L_1929 = __this->___m_LineNumber;
		NullCheck(L_1928);
		int32_t L_1930 = __this->___m_LineVisibleCharacterCount;
		((L_1928)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1929)))->___visibleCharacterCount = L_1930;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1931 = ___1_textInfo;
		NullCheck(L_1931);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1932 = L_1931->___lineInfo;
		int32_t L_1933 = __this->___m_LineNumber;
		NullCheck(L_1932);
		int32_t L_1934 = __this->___m_LineVisibleSpaceCount;
		((L_1932)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1933)))->___visibleSpaceCount = L_1934;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1935 = ___1_textInfo;
		NullCheck(L_1935);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1936 = L_1935->___lineInfo;
		int32_t L_1937 = __this->___m_LineNumber;
		NullCheck(L_1936);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1938 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&((L_1936)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1937)))->___lineExtents);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1939 = ___1_textInfo;
		NullCheck(L_1939);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1940 = L_1939->___textElementInfo;
		int32_t L_1941 = __this->___m_FirstVisibleCharacterOfLine;
		NullCheck(L_1940);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_1942 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_1940)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1941)))->___bottomLeft);
		float L_1943 = L_1942->___x;
		float L_1944 = V_304;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_1945;
		memset((&L_1945), 0, sizeof(L_1945));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_1945), L_1943, L_1944, NULL);
		L_1938->___min = L_1945;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1946 = ___1_textInfo;
		NullCheck(L_1946);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1947 = L_1946->___lineInfo;
		int32_t L_1948 = __this->___m_LineNumber;
		NullCheck(L_1947);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1949 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&((L_1947)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1948)))->___lineExtents);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1950 = ___1_textInfo;
		NullCheck(L_1950);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1951 = L_1950->___textElementInfo;
		int32_t L_1952 = __this->___m_LastVisibleCharacterOfLine;
		NullCheck(L_1951);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_1953 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_1951)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1952)))->___topRight);
		float L_1954 = L_1953->___x;
		float L_1955 = V_303;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_1956;
		memset((&L_1956), 0, sizeof(L_1956));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_1956), L_1954, L_1955, NULL);
		L_1949->___max = L_1956;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1957 = ___1_textInfo;
		NullCheck(L_1957);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1958 = L_1957->___lineInfo;
		int32_t L_1959 = __this->___m_LineNumber;
		NullCheck(L_1958);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1960 = ___1_textInfo;
		NullCheck(L_1960);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1961 = L_1960->___lineInfo;
		int32_t L_1962 = __this->___m_LineNumber;
		NullCheck(L_1961);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1963 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&((L_1961)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1962)))->___lineExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1964 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_1963->___max);
		float L_1965 = L_1964->___x;
		float L_1966 = V_6;
		float L_1967 = V_2;
		((L_1958)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1959)))->___length = ((float)il2cpp_codegen_subtract(L_1965, ((float)il2cpp_codegen_multiply(L_1966, L_1967))));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1968 = ___1_textInfo;
		NullCheck(L_1968);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1969 = L_1968->___lineInfo;
		int32_t L_1970 = __this->___m_LineNumber;
		NullCheck(L_1969);
		float L_1971 = V_22;
		((L_1969)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1970)))->___width = L_1971;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1972 = ___1_textInfo;
		NullCheck(L_1972);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1973 = L_1972->___lineInfo;
		int32_t L_1974 = __this->___m_LineNumber;
		NullCheck(L_1973);
		int32_t L_1975 = ((L_1973)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1974)))->___characterCount;
		V_311 = (bool)((((int32_t)L_1975) == ((int32_t)1))? 1 : 0);
		bool L_1976 = V_311;
		if (!L_1976)
		{
			goto IL_3c3c;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1977 = ___1_textInfo;
		NullCheck(L_1977);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1978 = L_1977->___lineInfo;
		int32_t L_1979 = __this->___m_LineNumber;
		NullCheck(L_1978);
		int32_t L_1980 = __this->___m_LineJustification;
		((L_1978)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1979)))->___alignment = L_1980;
	}

IL_3c3c:
	{
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1981 = __this->___m_CurrentFontAsset;
		NullCheck(L_1981);
		float L_1982;
		L_1982 = FontAsset_get_regularStyleSpacing_mB7EEEA236312F5AC31FD3B787808279206F521B1(L_1981, NULL);
		float L_1983 = V_75;
		float L_1984 = V_78;
		float L_1985 = V_3;
		float L_1986 = __this->___m_CSpacing;
		float L_1987 = __this->___m_CharWidthAdjDelta;
		V_305 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_1982, L_1983)), L_1984)), L_1985)), L_1986)), ((float)il2cpp_codegen_subtract((1.0f), L_1987))));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1988 = ___1_textInfo;
		NullCheck(L_1988);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1989 = L_1988->___textElementInfo;
		int32_t L_1990 = __this->___m_LastVisibleCharacterOfLine;
		NullCheck(L_1989);
		bool L_1991 = ((L_1989)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1990)))->___isVisible;
		V_312 = L_1991;
		bool L_1992 = V_312;
		if (!L_1992)
		{
			goto IL_3cd3;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1993 = ___1_textInfo;
		NullCheck(L_1993);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1994 = L_1993->___lineInfo;
		int32_t L_1995 = __this->___m_LineNumber;
		NullCheck(L_1994);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1996 = ___1_textInfo;
		NullCheck(L_1996);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1997 = L_1996->___textElementInfo;
		int32_t L_1998 = __this->___m_LastVisibleCharacterOfLine;
		NullCheck(L_1997);
		float L_1999 = ((L_1997)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1998)))->___xAdvance;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2000 = ___0_generationSettings;
		NullCheck(L_2000);
		bool L_2001 = L_2000->___isRightToLeft;
		if (L_2001)
		{
			G_B616_0 = L_1999;
			G_B616_1 = ((L_1994)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1995)));
			goto IL_3cc5;
		}
		G_B615_0 = L_1999;
		G_B615_1 = ((L_1994)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1995)));
	}
	{
		float L_2002 = V_305;
		G_B617_0 = ((-L_2002));
		G_B617_1 = G_B615_0;
		G_B617_2 = G_B615_1;
		goto IL_3ccb;
	}

IL_3cc5:
	{
		float L_2003 = V_305;
		G_B617_0 = L_2003;
		G_B617_1 = G_B616_0;
		G_B617_2 = G_B616_1;
	}

IL_3ccb:
	{
		G_B617_2->___maxAdvance = ((float)il2cpp_codegen_add(G_B617_1, G_B617_0));
		goto IL_3d17;
	}

IL_3cd3:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2004 = ___1_textInfo;
		NullCheck(L_2004);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_2005 = L_2004->___lineInfo;
		int32_t L_2006 = __this->___m_LineNumber;
		NullCheck(L_2005);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2007 = ___1_textInfo;
		NullCheck(L_2007);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2008 = L_2007->___textElementInfo;
		int32_t L_2009 = __this->___m_LastCharacterOfLine;
		NullCheck(L_2008);
		float L_2010 = ((L_2008)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2009)))->___xAdvance;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2011 = ___0_generationSettings;
		NullCheck(L_2011);
		bool L_2012 = L_2011->___isRightToLeft;
		if (L_2012)
		{
			G_B620_0 = L_2010;
			G_B620_1 = ((L_2005)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2006)));
			goto IL_3d0b;
		}
		G_B619_0 = L_2010;
		G_B619_1 = ((L_2005)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2006)));
	}
	{
		float L_2013 = V_305;
		G_B621_0 = ((-L_2013));
		G_B621_1 = G_B619_0;
		G_B621_2 = G_B619_1;
		goto IL_3d11;
	}

IL_3d0b:
	{
		float L_2014 = V_305;
		G_B621_0 = L_2014;
		G_B621_1 = G_B620_0;
		G_B621_2 = G_B620_1;
	}

IL_3d11:
	{
		G_B621_2->___maxAdvance = ((float)il2cpp_codegen_add(G_B621_1, G_B621_0));
	}

IL_3d17:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2015 = ___1_textInfo;
		NullCheck(L_2015);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_2016 = L_2015->___lineInfo;
		int32_t L_2017 = __this->___m_LineNumber;
		NullCheck(L_2016);
		float L_2018 = __this->___m_LineOffset;
		((L_2016)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2017)))->___baseline = ((float)il2cpp_codegen_subtract((0.0f), L_2018));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2019 = ___1_textInfo;
		NullCheck(L_2019);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_2020 = L_2019->___lineInfo;
		int32_t L_2021 = __this->___m_LineNumber;
		NullCheck(L_2020);
		float L_2022 = V_303;
		((L_2020)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2021)))->___ascender = L_2022;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2023 = ___1_textInfo;
		NullCheck(L_2023);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_2024 = L_2023->___lineInfo;
		int32_t L_2025 = __this->___m_LineNumber;
		NullCheck(L_2024);
		float L_2026 = V_304;
		((L_2024)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2025)))->___descender = L_2026;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2027 = ___1_textInfo;
		NullCheck(L_2027);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_2028 = L_2027->___lineInfo;
		int32_t L_2029 = __this->___m_LineNumber;
		NullCheck(L_2028);
		float L_2030 = V_303;
		float L_2031 = V_304;
		float L_2032 = V_16;
		float L_2033 = V_1;
		((L_2028)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2029)))->___lineHeight = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(L_2030, L_2031)), ((float)il2cpp_codegen_multiply(L_2032, L_2033))));
		uint32_t L_2034 = V_5;
		if ((((int32_t)L_2034) == ((int32_t)((int32_t)10))))
		{
			goto IL_3dbf;
		}
	}
	{
		uint32_t L_2035 = V_5;
		if ((((int32_t)L_2035) == ((int32_t)((int32_t)11))))
		{
			goto IL_3dbf;
		}
	}
	{
		uint32_t L_2036 = V_5;
		if ((((int32_t)L_2036) == ((int32_t)((int32_t)45))))
		{
			goto IL_3dbf;
		}
	}
	{
		uint32_t L_2037 = V_5;
		if ((((int32_t)L_2037) == ((int32_t)((int32_t)8232))))
		{
			goto IL_3dbf;
		}
	}
	{
		uint32_t L_2038 = V_5;
		G_B628_0 = ((((int32_t)L_2038) == ((int32_t)((int32_t)8233)))? 1 : 0);
		goto IL_3dc0;
	}

IL_3dbf:
	{
		G_B628_0 = 1;
	}

IL_3dc0:
	{
		V_313 = (bool)G_B628_0;
		bool L_2039 = V_313;
		if (!L_2039)
		{
			goto IL_3fa5;
		}
	}
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_2040 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedLineState);
		int32_t L_2041 = V_62;
		int32_t L_2042 = __this->___m_CharacterCount;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2043 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_2040, L_2041, L_2042, L_2043, NULL);
		int32_t L_2044 = __this->___m_LineNumber;
		__this->___m_LineNumber = ((int32_t)il2cpp_codegen_add(L_2044, 1));
		V_17 = (bool)1;
		V_26 = (bool)0;
		V_25 = (bool)1;
		int32_t L_2045 = __this->___m_CharacterCount;
		__this->___m_FirstCharacterOfLine = ((int32_t)il2cpp_codegen_add(L_2045, 1));
		__this->___m_LineVisibleCharacterCount = 0;
		__this->___m_LineVisibleSpaceCount = 0;
		int32_t L_2046 = __this->___m_LineNumber;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2047 = ___1_textInfo;
		NullCheck(L_2047);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_2048 = L_2047->___lineInfo;
		NullCheck(L_2048);
		V_315 = (bool)((((int32_t)((((int32_t)L_2046) < ((int32_t)((int32_t)(((RuntimeArray*)L_2048)->max_length))))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_2049 = V_315;
		if (!L_2049)
		{
			goto IL_3e49;
		}
	}
	{
		int32_t L_2050 = __this->___m_LineNumber;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2051 = ___1_textInfo;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		TextGeneratorUtilities_ResizeLineExtents_m2EA9BE32A38D5E075DEF8EDA9EC01766E45C0F85(L_2050, L_2051, NULL);
	}

IL_3e49:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2052 = ___1_textInfo;
		NullCheck(L_2052);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2053 = L_2052->___textElementInfo;
		int32_t L_2054 = __this->___m_CharacterCount;
		NullCheck(L_2053);
		float L_2055 = ((L_2053)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2054)))->___adjustedAscender;
		V_314 = L_2055;
		float L_2056 = __this->___m_LineHeight;
		V_316 = (bool)((((float)L_2056) == ((float)(-32767.0f)))? 1 : 0);
		bool L_2057 = V_316;
		if (!L_2057)
		{
			goto IL_3ee9;
		}
	}
	{
		float L_2058 = __this->___m_MaxLineDescender;
		float L_2059 = V_314;
		float L_2060 = V_16;
		float L_2061 = __this->___m_LineSpacingDelta;
		float L_2062 = V_1;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2063 = ___0_generationSettings;
		NullCheck(L_2063);
		float L_2064 = L_2063->___lineSpacing;
		uint32_t L_2065 = V_5;
		if ((((int32_t)L_2065) == ((int32_t)((int32_t)10))))
		{
			G_B635_0 = L_2064;
			G_B635_1 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract((0.0f), L_2058)), L_2059)), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_2060, L_2061)), L_2062))));
			goto IL_3ebc;
		}
		G_B633_0 = L_2064;
		G_B633_1 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract((0.0f), L_2058)), L_2059)), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_2060, L_2061)), L_2062))));
	}
	{
		uint32_t L_2066 = V_5;
		if ((((int32_t)L_2066) == ((int32_t)((int32_t)8233))))
		{
			G_B635_0 = G_B633_0;
			G_B635_1 = G_B633_1;
			goto IL_3ebc;
		}
		G_B634_0 = G_B633_0;
		G_B634_1 = G_B633_1;
	}
	{
		G_B636_0 = (0.0f);
		G_B636_1 = G_B634_0;
		G_B636_2 = G_B634_1;
		goto IL_3ec2;
	}

IL_3ebc:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2067 = ___0_generationSettings;
		NullCheck(L_2067);
		float L_2068 = L_2067->___paragraphSpacing;
		G_B636_0 = L_2068;
		G_B636_1 = G_B635_0;
		G_B636_2 = G_B635_1;
	}

IL_3ec2:
	{
		float L_2069 = V_3;
		V_317 = ((float)il2cpp_codegen_add(G_B636_2, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(G_B636_1, G_B636_0)), L_2069))));
		float L_2070 = __this->___m_LineOffset;
		float L_2071 = V_317;
		__this->___m_LineOffset = ((float)il2cpp_codegen_add(L_2070, L_2071));
		__this->___m_IsDrivenLineSpacing = (bool)0;
		goto IL_3f2b;
	}

IL_3ee9:
	{
		float L_2072 = __this->___m_LineOffset;
		float L_2073 = __this->___m_LineHeight;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2074 = ___0_generationSettings;
		NullCheck(L_2074);
		float L_2075 = L_2074->___lineSpacing;
		uint32_t L_2076 = V_5;
		if ((((int32_t)L_2076) == ((int32_t)((int32_t)10))))
		{
			G_B640_0 = L_2075;
			G_B640_1 = L_2073;
			G_B640_2 = L_2072;
			G_B640_3 = __this;
			goto IL_3f13;
		}
		G_B638_0 = L_2075;
		G_B638_1 = L_2073;
		G_B638_2 = L_2072;
		G_B638_3 = __this;
	}
	{
		uint32_t L_2077 = V_5;
		if ((((int32_t)L_2077) == ((int32_t)((int32_t)8233))))
		{
			G_B640_0 = G_B638_0;
			G_B640_1 = G_B638_1;
			G_B640_2 = G_B638_2;
			G_B640_3 = G_B638_3;
			goto IL_3f13;
		}
		G_B639_0 = G_B638_0;
		G_B639_1 = G_B638_1;
		G_B639_2 = G_B638_2;
		G_B639_3 = G_B638_3;
	}
	{
		G_B641_0 = (0.0f);
		G_B641_1 = G_B639_0;
		G_B641_2 = G_B639_1;
		G_B641_3 = G_B639_2;
		G_B641_4 = G_B639_3;
		goto IL_3f19;
	}

IL_3f13:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2078 = ___0_generationSettings;
		NullCheck(L_2078);
		float L_2079 = L_2078->___paragraphSpacing;
		G_B641_0 = L_2079;
		G_B641_1 = G_B640_0;
		G_B641_2 = G_B640_1;
		G_B641_3 = G_B640_2;
		G_B641_4 = G_B640_3;
	}

IL_3f19:
	{
		float L_2080 = V_3;
		NullCheck(G_B641_4);
		G_B641_4->___m_LineOffset = ((float)il2cpp_codegen_add(G_B641_3, ((float)il2cpp_codegen_add(G_B641_2, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(G_B641_1, G_B641_0)), L_2080))))));
		__this->___m_IsDrivenLineSpacing = (bool)1;
	}

IL_3f2b:
	{
		__this->___m_MaxLineAscender = (-32767.0f);
		__this->___m_MaxLineDescender = (32767.0f);
		float L_2081 = V_314;
		__this->___m_StartOfLineAscender = L_2081;
		float L_2082 = __this->___m_TagLineIndent;
		float L_2083 = __this->___m_TagIndent;
		__this->___m_XAdvance = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_add((0.0f), L_2082)), L_2083));
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_2084 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedWordWrapState);
		int32_t L_2085 = V_62;
		int32_t L_2086 = __this->___m_CharacterCount;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2087 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_2084, L_2085, L_2086, L_2087, NULL);
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_2088 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedLastValidState);
		int32_t L_2089 = V_62;
		int32_t L_2090 = __this->___m_CharacterCount;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2091 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_2088, L_2089, L_2090, L_2091, NULL);
		int32_t L_2092 = __this->___m_CharacterCount;
		__this->___m_CharacterCount = ((int32_t)il2cpp_codegen_add(L_2092, 1));
		goto IL_43d7;
	}

IL_3fa5:
	{
		uint32_t L_2093 = V_5;
		V_318 = (bool)((((int32_t)L_2093) == ((int32_t)3))? 1 : 0);
		bool L_2094 = V_318;
		if (!L_2094)
		{
			goto IL_3fc2;
		}
	}
	{
		TextProcessingElementU5BU5D_t24A1E4C8745577D794FE856B4236875595E7FD22* L_2095 = __this->___m_TextProcessingArray;
		NullCheck(L_2095);
		V_62 = ((int32_t)(((RuntimeArray*)L_2095)->max_length));
	}

IL_3fc2:
	{
	}

IL_3fc3:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2096 = ___1_textInfo;
		NullCheck(L_2096);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2097 = L_2096->___textElementInfo;
		int32_t L_2098 = __this->___m_CharacterCount;
		NullCheck(L_2097);
		bool L_2099 = ((L_2097)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2098)))->___isVisible;
		V_319 = L_2099;
		bool L_2100 = V_319;
		if (!L_2100)
		{
			goto IL_40ec;
		}
	}
	{
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2101 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2102 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2101->___min);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2103 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2104 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2103->___min);
		float L_2105 = L_2104->___x;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2106 = ___1_textInfo;
		NullCheck(L_2106);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2107 = L_2106->___textElementInfo;
		int32_t L_2108 = __this->___m_CharacterCount;
		NullCheck(L_2107);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2109 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_2107)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2108)))->___bottomLeft);
		float L_2110 = L_2109->___x;
		float L_2111;
		L_2111 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_2105, L_2110, NULL);
		L_2102->___x = L_2111;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2112 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2113 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2112->___min);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2114 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2115 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2114->___min);
		float L_2116 = L_2115->___y;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2117 = ___1_textInfo;
		NullCheck(L_2117);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2118 = L_2117->___textElementInfo;
		int32_t L_2119 = __this->___m_CharacterCount;
		NullCheck(L_2118);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2120 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_2118)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2119)))->___bottomLeft);
		float L_2121 = L_2120->___y;
		float L_2122;
		L_2122 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_2116, L_2121, NULL);
		L_2113->___y = L_2122;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2123 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2124 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2123->___max);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2125 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2126 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2125->___max);
		float L_2127 = L_2126->___x;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2128 = ___1_textInfo;
		NullCheck(L_2128);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2129 = L_2128->___textElementInfo;
		int32_t L_2130 = __this->___m_CharacterCount;
		NullCheck(L_2129);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2131 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_2129)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2130)))->___topRight);
		float L_2132 = L_2131->___x;
		float L_2133;
		L_2133 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_2127, L_2132, NULL);
		L_2124->___x = L_2133;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2134 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2135 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2134->___max);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2136 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2137 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2136->___max);
		float L_2138 = L_2137->___y;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2139 = ___1_textInfo;
		NullCheck(L_2139);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2140 = L_2139->___textElementInfo;
		int32_t L_2141 = __this->___m_CharacterCount;
		NullCheck(L_2140);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2142 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_2140)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2141)))->___topRight);
		float L_2143 = L_2142->___y;
		float L_2144;
		L_2144 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_2138, L_2143, NULL);
		L_2135->___y = L_2144;
	}

IL_40ec:
	{
		int32_t L_2145 = V_30;
		if (!L_2145)
		{
			goto IL_40f5;
		}
	}
	{
		int32_t L_2146 = V_30;
		if ((!(((uint32_t)L_2146) == ((uint32_t)3))))
		{
			goto IL_4112;
		}
	}

IL_40f5:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2147 = ___0_generationSettings;
		NullCheck(L_2147);
		int32_t L_2148 = L_2147->___overflowMode;
		if ((((int32_t)L_2148) == ((int32_t)3)))
		{
			goto IL_4112;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2149 = ___0_generationSettings;
		NullCheck(L_2149);
		int32_t L_2150 = L_2149->___overflowMode;
		if ((((int32_t)L_2150) == ((int32_t)1)))
		{
			goto IL_4112;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2151 = ___0_generationSettings;
		NullCheck(L_2151);
		int32_t L_2152 = L_2151->___overflowMode;
		G_B654_0 = ((((int32_t)L_2152) == ((int32_t)6))? 1 : 0);
		goto IL_4113;
	}

IL_4112:
	{
		G_B654_0 = 1;
	}

IL_4113:
	{
		V_320 = (bool)G_B654_0;
		bool L_2153 = V_320;
		if (!L_2153)
		{
			goto IL_43b2;
		}
	}
	{
		bool L_2154 = V_73;
		if (L_2154)
		{
			goto IL_4141;
		}
	}
	{
		uint32_t L_2155 = V_5;
		if ((((int32_t)L_2155) == ((int32_t)((int32_t)8203))))
		{
			goto IL_4141;
		}
	}
	{
		uint32_t L_2156 = V_5;
		if ((((int32_t)L_2156) == ((int32_t)((int32_t)45))))
		{
			goto IL_4141;
		}
	}
	{
		uint32_t L_2157 = V_5;
		if ((!(((uint32_t)L_2157) == ((uint32_t)((int32_t)173)))))
		{
			goto IL_4181;
		}
	}

IL_4141:
	{
		bool L_2158 = __this->___m_IsNonBreakingSpace;
		bool L_2159 = V_26;
		if (!((int32_t)(((((int32_t)L_2158) == ((int32_t)0))? 1 : 0)|(int32_t)L_2159)))
		{
			goto IL_4181;
		}
	}
	{
		uint32_t L_2160 = V_5;
		if ((((int32_t)L_2160) == ((int32_t)((int32_t)160))))
		{
			goto IL_4181;
		}
	}
	{
		uint32_t L_2161 = V_5;
		if ((((int32_t)L_2161) == ((int32_t)((int32_t)8199))))
		{
			goto IL_4181;
		}
	}
	{
		uint32_t L_2162 = V_5;
		if ((((int32_t)L_2162) == ((int32_t)((int32_t)8209))))
		{
			goto IL_4181;
		}
	}
	{
		uint32_t L_2163 = V_5;
		if ((((int32_t)L_2163) == ((int32_t)((int32_t)8239))))
		{
			goto IL_4181;
		}
	}
	{
		uint32_t L_2164 = V_5;
		G_B666_0 = ((((int32_t)((((int32_t)L_2164) == ((int32_t)((int32_t)8288)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_4182;
	}

IL_4181:
	{
		G_B666_0 = 0;
	}

IL_4182:
	{
		V_321 = (bool)G_B666_0;
		bool L_2165 = V_321;
		if (!L_2165)
		{
			goto IL_41bc;
		}
	}
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_2166 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedWordWrapState);
		int32_t L_2167 = V_62;
		int32_t L_2168 = __this->___m_CharacterCount;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2169 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_2166, L_2167, L_2168, L_2169, NULL);
		V_25 = (bool)0;
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_2170 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedSoftLineBreakState);
		L_2170->___previousWordBreak = (-1);
		goto IL_43b1;
	}

IL_41bc:
	{
		bool L_2171 = __this->___m_IsNonBreakingSpace;
		if (L_2171)
		{
			goto IL_41e7;
		}
	}
	{
		uint32_t L_2172 = V_5;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		bool L_2173;
		L_2173 = TextGeneratorUtilities_IsHangul_m5A23BA8E0EBE57243E2E96A248B3F6570A87A966(L_2172, NULL);
		if (!L_2173)
		{
			goto IL_41db;
		}
	}
	{
		TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64* L_2174 = V_31;
		NullCheck(L_2174);
		UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* L_2175;
		L_2175 = TextSettings_get_lineBreakingRules_m96E2C32D4F08309D904B0BCD83CEBE8CD6716A04(L_2174, NULL);
		NullCheck(L_2175);
		bool L_2176;
		L_2176 = UnicodeLineBreakingRules_get_useModernHangulLineBreakingRules_mD86D283CE7BA23A0174B9227A7BD915D3D9FD464_inline(L_2175, NULL);
		if (!L_2176)
		{
			goto IL_41e4;
		}
	}

IL_41db:
	{
		uint32_t L_2177 = V_5;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		bool L_2178;
		L_2178 = TextGeneratorUtilities_IsCJK_m2F2718B1203271CC2C501C5054590299FBCA5B7D(L_2177, NULL);
		G_B673_0 = ((int32_t)(L_2178));
		goto IL_41e5;
	}

IL_41e4:
	{
		G_B673_0 = 1;
	}

IL_41e5:
	{
		G_B675_0 = G_B673_0;
		goto IL_41e8;
	}

IL_41e7:
	{
		G_B675_0 = 0;
	}

IL_41e8:
	{
		V_322 = (bool)G_B675_0;
		bool L_2179 = V_322;
		if (!L_2179)
		{
			goto IL_4344;
		}
	}
	{
		TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64* L_2180 = V_31;
		NullCheck(L_2180);
		UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* L_2181;
		L_2181 = TextSettings_get_lineBreakingRules_m96E2C32D4F08309D904B0BCD83CEBE8CD6716A04(L_2180, NULL);
		NullCheck(L_2181);
		HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* L_2182;
		L_2182 = UnicodeLineBreakingRules_get_leadingCharactersLookup_m1DAC015D7E37112EAE0437E6472AEA0719DFF3DC(L_2181, NULL);
		uint32_t L_2183 = V_5;
		NullCheck(L_2182);
		bool L_2184;
		L_2184 = HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9(L_2182, L_2183, HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9_RuntimeMethod_var);
		V_323 = L_2184;
		int32_t L_2185 = __this->___m_CharacterCount;
		int32_t L_2186 = V_0;
		if ((((int32_t)L_2185) >= ((int32_t)((int32_t)il2cpp_codegen_subtract(L_2186, 1)))))
		{
			goto IL_4249;
		}
	}
	{
		TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64* L_2187 = V_31;
		NullCheck(L_2187);
		UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* L_2188;
		L_2188 = TextSettings_get_lineBreakingRules_m96E2C32D4F08309D904B0BCD83CEBE8CD6716A04(L_2187, NULL);
		NullCheck(L_2188);
		HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* L_2189;
		L_2189 = UnicodeLineBreakingRules_get_followingCharactersLookup_m5510A21873DC5DA66F4A2DFA4C26A5EFAD494D8B(L_2188, NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2190 = ___1_textInfo;
		NullCheck(L_2190);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2191 = L_2190->___textElementInfo;
		int32_t L_2192 = __this->___m_CharacterCount;
		NullCheck(L_2191);
		Il2CppChar L_2193 = ((L_2191)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_2192, 1)))))->___character;
		NullCheck(L_2189);
		bool L_2194;
		L_2194 = HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9(L_2189, L_2193, HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9_RuntimeMethod_var);
		G_B679_0 = ((int32_t)(L_2194));
		goto IL_424a;
	}

IL_4249:
	{
		G_B679_0 = 0;
	}

IL_424a:
	{
		V_324 = (bool)G_B679_0;
		bool L_2195 = V_323;
		V_325 = (bool)((((int32_t)L_2195) == ((int32_t)0))? 1 : 0);
		bool L_2196 = V_325;
		if (!L_2196)
		{
			goto IL_42ee;
		}
	}
	{
		bool L_2197 = V_324;
		V_326 = (bool)((((int32_t)L_2197) == ((int32_t)0))? 1 : 0);
		bool L_2198 = V_326;
		if (!L_2198)
		{
			goto IL_429d;
		}
	}
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_2199 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedWordWrapState);
		int32_t L_2200 = V_62;
		int32_t L_2201 = __this->___m_CharacterCount;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2202 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_2199, L_2200, L_2201, L_2202, NULL);
		V_25 = (bool)0;
	}

IL_429d:
	{
		bool L_2203 = V_25;
		V_327 = L_2203;
		bool L_2204 = V_327;
		if (!L_2204)
		{
			goto IL_42eb;
		}
	}
	{
		bool L_2205 = V_73;
		V_328 = L_2205;
		bool L_2206 = V_328;
		if (!L_2206)
		{
			goto IL_42d4;
		}
	}
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_2207 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedSoftLineBreakState);
		int32_t L_2208 = V_62;
		int32_t L_2209 = __this->___m_CharacterCount;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2210 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_2207, L_2208, L_2209, L_2210, NULL);
	}

IL_42d4:
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_2211 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedWordWrapState);
		int32_t L_2212 = V_62;
		int32_t L_2213 = __this->___m_CharacterCount;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2214 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_2211, L_2212, L_2213, L_2214, NULL);
	}

IL_42eb:
	{
		goto IL_4341;
	}

IL_42ee:
	{
		bool L_2215 = V_25;
		bool L_2216 = V_88;
		V_329 = (bool)((int32_t)((int32_t)L_2215&(int32_t)L_2216));
		bool L_2217 = V_329;
		if (!L_2217)
		{
			goto IL_4340;
		}
	}
	{
		bool L_2218 = V_73;
		V_330 = L_2218;
		bool L_2219 = V_330;
		if (!L_2219)
		{
			goto IL_4329;
		}
	}
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_2220 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedSoftLineBreakState);
		int32_t L_2221 = V_62;
		int32_t L_2222 = __this->___m_CharacterCount;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2223 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_2220, L_2221, L_2222, L_2223, NULL);
	}

IL_4329:
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_2224 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedWordWrapState);
		int32_t L_2225 = V_62;
		int32_t L_2226 = __this->___m_CharacterCount;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2227 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_2224, L_2225, L_2226, L_2227, NULL);
	}

IL_4340:
	{
	}

IL_4341:
	{
		goto IL_43b1;
	}

IL_4344:
	{
		bool L_2228 = V_25;
		V_331 = L_2228;
		bool L_2229 = V_331;
		if (!L_2229)
		{
			goto IL_43b1;
		}
	}
	{
		bool L_2230 = V_73;
		if (!L_2230)
		{
			goto IL_4362;
		}
	}
	{
		uint32_t L_2231 = V_5;
		if ((!(((uint32_t)L_2231) == ((uint32_t)((int32_t)160)))))
		{
			goto IL_4375;
		}
	}

IL_4362:
	{
		uint32_t L_2232 = V_5;
		if ((!(((uint32_t)L_2232) == ((uint32_t)((int32_t)173)))))
		{
			goto IL_4372;
		}
	}
	{
		bool L_2233 = V_29;
		G_B699_0 = ((((int32_t)L_2233) == ((int32_t)0))? 1 : 0);
		goto IL_4373;
	}

IL_4372:
	{
		G_B699_0 = 0;
	}

IL_4373:
	{
		G_B701_0 = G_B699_0;
		goto IL_4376;
	}

IL_4375:
	{
		G_B701_0 = 1;
	}

IL_4376:
	{
		V_332 = (bool)G_B701_0;
		bool L_2234 = V_332;
		if (!L_2234)
		{
			goto IL_439a;
		}
	}
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_2235 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedSoftLineBreakState);
		int32_t L_2236 = V_62;
		int32_t L_2237 = __this->___m_CharacterCount;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2238 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_2235, L_2236, L_2237, L_2238, NULL);
	}

IL_439a:
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_2239 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedWordWrapState);
		int32_t L_2240 = V_62;
		int32_t L_2241 = __this->___m_CharacterCount;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2242 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_2239, L_2240, L_2241, L_2242, NULL);
	}

IL_43b1:
	{
	}

IL_43b2:
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_2243 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedLastValidState);
		int32_t L_2244 = V_62;
		int32_t L_2245 = __this->___m_CharacterCount;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2246 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_2243, L_2244, L_2245, L_2246, NULL);
		int32_t L_2247 = __this->___m_CharacterCount;
		__this->___m_CharacterCount = ((int32_t)il2cpp_codegen_add(L_2247, 1));
	}

IL_43d7:
	{
		int32_t L_2248 = V_62;
		V_158 = L_2248;
		int32_t L_2249 = V_158;
		V_62 = ((int32_t)il2cpp_codegen_add(L_2249, 1));
	}

IL_43e1:
	{
		int32_t L_2250 = V_62;
		TextProcessingElementU5BU5D_t24A1E4C8745577D794FE856B4236875595E7FD22* L_2251 = __this->___m_TextProcessingArray;
		NullCheck(L_2251);
		if ((((int32_t)L_2250) >= ((int32_t)((int32_t)(((RuntimeArray*)L_2251)->max_length)))))
		{
			goto IL_4404;
		}
	}
	{
		TextProcessingElementU5BU5D_t24A1E4C8745577D794FE856B4236875595E7FD22* L_2252 = __this->___m_TextProcessingArray;
		int32_t L_2253 = V_62;
		NullCheck(L_2252);
		uint32_t L_2254 = ((L_2252)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2253)))->___unicode;
		G_B710_0 = ((!(((uint32_t)L_2254) <= ((uint32_t)0)))? 1 : 0);
		goto IL_4405;
	}

IL_4404:
	{
		G_B710_0 = 0;
	}

IL_4405:
	{
		V_333 = (bool)G_B710_0;
		bool L_2255 = V_333;
		if (L_2255)
		{
			goto IL_05e7;
		}
	}
	{
		float L_2256 = __this->___m_MaxFontSize;
		float L_2257 = __this->___m_MinFontSize;
		V_4 = ((float)il2cpp_codegen_subtract(L_2256, L_2257));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2258 = ___0_generationSettings;
		NullCheck(L_2258);
		bool L_2259 = L_2258->___autoSize;
		if (!L_2259)
		{
			goto IL_4454;
		}
	}
	{
		float L_2260 = V_4;
		if ((!(((float)L_2260) > ((float)(0.050999999f)))))
		{
			goto IL_4454;
		}
	}
	{
		float L_2261 = __this->___m_FontSize;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2262 = ___0_generationSettings;
		NullCheck(L_2262);
		float L_2263 = L_2262->___fontSizeMax;
		if ((!(((float)L_2261) < ((float)L_2263))))
		{
			goto IL_4454;
		}
	}
	{
		int32_t L_2264 = __this->___m_AutoSizeIterationCount;
		int32_t L_2265 = __this->___m_AutoSizeMaxIterationCount;
		G_B716_0 = ((((int32_t)L_2264) < ((int32_t)L_2265))? 1 : 0);
		goto IL_4455;
	}

IL_4454:
	{
		G_B716_0 = 0;
	}

IL_4455:
	{
		V_334 = (bool)G_B716_0;
		bool L_2266 = V_334;
		if (!L_2266)
		{
			goto IL_4506;
		}
	}
	{
		float L_2267 = __this->___m_CharWidthAdjDelta;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2268 = ___0_generationSettings;
		NullCheck(L_2268);
		float L_2269 = L_2268->___charWidthMaxAdj;
		V_336 = (bool)((((float)L_2267) < ((float)((float)(L_2269/(100.0f)))))? 1 : 0);
		bool L_2270 = V_336;
		if (!L_2270)
		{
			goto IL_4494;
		}
	}
	{
		__this->___m_CharWidthAdjDelta = (0.0f);
	}

IL_4494:
	{
		float L_2271 = __this->___m_FontSize;
		__this->___m_MinFontSize = L_2271;
		float L_2272 = __this->___m_MaxFontSize;
		float L_2273 = __this->___m_FontSize;
		float L_2274;
		L_2274 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(((float)(((float)il2cpp_codegen_subtract(L_2272, L_2273))/(2.0f))), (0.0500000007f), NULL);
		V_335 = L_2274;
		float L_2275 = __this->___m_FontSize;
		float L_2276 = V_335;
		__this->___m_FontSize = ((float)il2cpp_codegen_add(L_2275, L_2276));
		float L_2277 = __this->___m_FontSize;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2278 = ___0_generationSettings;
		NullCheck(L_2278);
		float L_2279 = L_2278->___charWidthMaxAdj;
		float L_2280;
		L_2280 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(((float)(((float)il2cpp_codegen_cast_double_to_int<int32_t>(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_2277, (20.0f))), (0.5f)))))/(20.0f))), L_2279, NULL);
		__this->___m_FontSize = L_2280;
		goto IL_88b4;
	}

IL_4506:
	{
		__this->___m_IsAutoSizePointSizeSet = (bool)1;
		int32_t L_2281 = __this->___m_AutoSizeIterationCount;
		int32_t L_2282 = __this->___m_AutoSizeMaxIterationCount;
		V_337 = (bool)((((int32_t)((((int32_t)L_2281) < ((int32_t)L_2282))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_2283 = V_337;
		if (!L_2283)
		{
			goto IL_4557;
		}
	}
	{
		int32_t* L_2284 = (int32_t*)(&__this->___m_AutoSizeIterationCount);
		String_t* L_2285;
		L_2285 = Int32_ToString_m030E01C24E294D6762FB0B6F37CB541581F55CA5(L_2284, NULL);
		float* L_2286 = (float*)(&__this->___m_FontSize);
		String_t* L_2287;
		L_2287 = Single_ToString_mE282EDA9CA4F7DF88432D807732837A629D04972(L_2286, NULL);
		String_t* L_2288;
		L_2288 = String_Concat_m093934F71A9B351911EE46311674ED463B180006(_stringLiteralFE37C361B118D899F298E7DBBEDF126B8808060D, L_2285, _stringLiteral4D24EAAEA041EAFA17400A5C3BEA644DA7F8067F, L_2287, NULL);
		il2cpp_codegen_runtime_class_init_inline(Debug_t8394C7EEAECA3689C2C9B9DE9C7166D73596276F_il2cpp_TypeInfo_var);
		Debug_Log_m87A9A3C761FF5C43ED8A53B16190A53D08F818BB(L_2288, NULL);
	}

IL_4557:
	{
		int32_t L_2289 = __this->___m_CharacterCount;
		if (!L_2289)
		{
			goto IL_4572;
		}
	}
	{
		int32_t L_2290 = __this->___m_CharacterCount;
		if ((!(((uint32_t)L_2290) == ((uint32_t)1))))
		{
			goto IL_456f;
		}
	}
	{
		uint32_t L_2291 = V_5;
		G_B726_0 = ((((int32_t)L_2291) == ((int32_t)3))? 1 : 0);
		goto IL_4570;
	}

IL_456f:
	{
		G_B726_0 = 0;
	}

IL_4570:
	{
		G_B728_0 = G_B726_0;
		goto IL_4573;
	}

IL_4572:
	{
		G_B728_0 = 1;
	}

IL_4573:
	{
		V_338 = (bool)G_B728_0;
		bool L_2292 = V_338;
		if (!L_2292)
		{
			goto IL_458f;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2293 = ___1_textInfo;
		TextGenerator_ClearMesh_m68BA46B0365FC730BA5D2E6BDF2528BD370B2D83((bool)1, L_2293, NULL);
		goto IL_88b4;
	}

IL_458f:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2294 = ___1_textInfo;
		NullCheck(L_2294);
		MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6* L_2295 = L_2294->___meshInfo;
		int32_t L_2296 = __this->___m_CurrentMaterialIndex;
		NullCheck(L_2295);
		il2cpp_codegen_runtime_class_init_inline(MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F_il2cpp_TypeInfo_var);
		MeshInfo_Clear_m06992FEB7AC9B2AE1728BEDFC8D8A39DE1AAD475(((L_2295)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2296))), (bool)0, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2297;
		L_2297 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_33 = L_2297;
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_2298 = __this->___m_RectTransformCorners;
		V_34 = L_2298;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2299 = ___0_generationSettings;
		NullCheck(L_2299);
		int32_t L_2300 = L_2299->___textAlignment;
		V_340 = L_2300;
		int32_t L_2301 = V_340;
		V_339 = L_2301;
		int32_t L_2302 = V_339;
		if ((((int32_t)L_2302) > ((int32_t)((int32_t)1056))))
		{
			goto IL_4758;
		}
	}
	{
		int32_t L_2303 = V_339;
		if ((((int32_t)L_2303) > ((int32_t)((int32_t)516))))
		{
			goto IL_4693;
		}
	}
	{
		int32_t L_2304 = V_339;
		if ((((int32_t)L_2304) > ((int32_t)((int32_t)264))))
		{
			goto IL_4636;
		}
	}
	{
		int32_t L_2305 = V_339;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_2305, ((int32_t)257)))) > ((uint32_t)1))))
		{
			goto IL_48d2;
		}
	}
	{
		goto IL_460f;
	}

IL_460f:
	{
		int32_t L_2306 = V_339;
		if ((((int32_t)L_2306) == ((int32_t)((int32_t)260))))
		{
			goto IL_48d2;
		}
	}
	{
		goto IL_4621;
	}

IL_4621:
	{
		int32_t L_2307 = V_339;
		if ((((int32_t)L_2307) == ((int32_t)((int32_t)264))))
		{
			goto IL_48d2;
		}
	}
	{
		goto IL_4c35;
	}

IL_4636:
	{
		int32_t L_2308 = V_339;
		if ((((int32_t)L_2308) > ((int32_t)((int32_t)288))))
		{
			goto IL_466a;
		}
	}
	{
		int32_t L_2309 = V_339;
		if ((((int32_t)L_2309) == ((int32_t)((int32_t)272))))
		{
			goto IL_48d2;
		}
	}
	{
		goto IL_4655;
	}

IL_4655:
	{
		int32_t L_2310 = V_339;
		if ((((int32_t)L_2310) == ((int32_t)((int32_t)288))))
		{
			goto IL_48d2;
		}
	}
	{
		goto IL_4c35;
	}

IL_466a:
	{
		int32_t L_2311 = V_339;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_2311, ((int32_t)513)))) > ((uint32_t)1))))
		{
			goto IL_4973;
		}
	}
	{
		goto IL_467e;
	}

IL_467e:
	{
		int32_t L_2312 = V_339;
		if ((((int32_t)L_2312) == ((int32_t)((int32_t)516))))
		{
			goto IL_4973;
		}
	}
	{
		goto IL_4c35;
	}

IL_4693:
	{
		int32_t L_2313 = V_339;
		if ((((int32_t)L_2313) > ((int32_t)((int32_t)1026))))
		{
			goto IL_46fd;
		}
	}
	{
		int32_t L_2314 = V_339;
		if ((((int32_t)L_2314) > ((int32_t)((int32_t)528))))
		{
			goto IL_46d4;
		}
	}
	{
		int32_t L_2315 = V_339;
		if ((((int32_t)L_2315) == ((int32_t)((int32_t)520))))
		{
			goto IL_4973;
		}
	}
	{
		goto IL_46bf;
	}

IL_46bf:
	{
		int32_t L_2316 = V_339;
		if ((((int32_t)L_2316) == ((int32_t)((int32_t)528))))
		{
			goto IL_4973;
		}
	}
	{
		goto IL_4c35;
	}

IL_46d4:
	{
		int32_t L_2317 = V_339;
		if ((((int32_t)L_2317) == ((int32_t)((int32_t)544))))
		{
			goto IL_4973;
		}
	}
	{
		goto IL_46e6;
	}

IL_46e6:
	{
		int32_t L_2318 = V_339;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_2318, ((int32_t)1025)))) > ((uint32_t)1))))
		{
			goto IL_4a74;
		}
	}
	{
		goto IL_4c35;
	}

IL_46fd:
	{
		int32_t L_2319 = V_339;
		if ((((int32_t)L_2319) > ((int32_t)((int32_t)1032))))
		{
			goto IL_4731;
		}
	}
	{
		int32_t L_2320 = V_339;
		if ((((int32_t)L_2320) == ((int32_t)((int32_t)1028))))
		{
			goto IL_4a74;
		}
	}
	{
		goto IL_471c;
	}

IL_471c:
	{
		int32_t L_2321 = V_339;
		if ((((int32_t)L_2321) == ((int32_t)((int32_t)1032))))
		{
			goto IL_4a74;
		}
	}
	{
		goto IL_4c35;
	}

IL_4731:
	{
		int32_t L_2322 = V_339;
		if ((((int32_t)L_2322) == ((int32_t)((int32_t)1040))))
		{
			goto IL_4a74;
		}
	}
	{
		goto IL_4743;
	}

IL_4743:
	{
		int32_t L_2323 = V_339;
		if ((((int32_t)L_2323) == ((int32_t)((int32_t)1056))))
		{
			goto IL_4a74;
		}
	}
	{
		goto IL_4c35;
	}

IL_4758:
	{
		int32_t L_2324 = V_339;
		if ((((int32_t)L_2324) > ((int32_t)((int32_t)4100))))
		{
			goto IL_480d;
		}
	}
	{
		int32_t L_2325 = V_339;
		if ((((int32_t)L_2325) > ((int32_t)((int32_t)2056))))
		{
			goto IL_47b0;
		}
	}
	{
		int32_t L_2326 = V_339;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_2326, ((int32_t)2049)))) > ((uint32_t)1))))
		{
			goto IL_4b11;
		}
	}
	{
		goto IL_4789;
	}

IL_4789:
	{
		int32_t L_2327 = V_339;
		if ((((int32_t)L_2327) == ((int32_t)((int32_t)2052))))
		{
			goto IL_4b11;
		}
	}
	{
		goto IL_479b;
	}

IL_479b:
	{
		int32_t L_2328 = V_339;
		if ((((int32_t)L_2328) == ((int32_t)((int32_t)2056))))
		{
			goto IL_4b11;
		}
	}
	{
		goto IL_4c35;
	}

IL_47b0:
	{
		int32_t L_2329 = V_339;
		if ((((int32_t)L_2329) > ((int32_t)((int32_t)2080))))
		{
			goto IL_47e4;
		}
	}
	{
		int32_t L_2330 = V_339;
		if ((((int32_t)L_2330) == ((int32_t)((int32_t)2064))))
		{
			goto IL_4b11;
		}
	}
	{
		goto IL_47cf;
	}

IL_47cf:
	{
		int32_t L_2331 = V_339;
		if ((((int32_t)L_2331) == ((int32_t)((int32_t)2080))))
		{
			goto IL_4b11;
		}
	}
	{
		goto IL_4c35;
	}

IL_47e4:
	{
		int32_t L_2332 = V_339;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_2332, ((int32_t)4097)))) > ((uint32_t)1))))
		{
			goto IL_4b58;
		}
	}
	{
		goto IL_47f8;
	}

IL_47f8:
	{
		int32_t L_2333 = V_339;
		if ((((int32_t)L_2333) == ((int32_t)((int32_t)4100))))
		{
			goto IL_4b58;
		}
	}
	{
		goto IL_4c35;
	}

IL_480d:
	{
		int32_t L_2334 = V_339;
		if ((((int32_t)L_2334) > ((int32_t)((int32_t)8194))))
		{
			goto IL_4877;
		}
	}
	{
		int32_t L_2335 = V_339;
		if ((((int32_t)L_2335) > ((int32_t)((int32_t)4112))))
		{
			goto IL_484e;
		}
	}
	{
		int32_t L_2336 = V_339;
		if ((((int32_t)L_2336) == ((int32_t)((int32_t)4104))))
		{
			goto IL_4b58;
		}
	}
	{
		goto IL_4839;
	}

IL_4839:
	{
		int32_t L_2337 = V_339;
		if ((((int32_t)L_2337) == ((int32_t)((int32_t)4112))))
		{
			goto IL_4b58;
		}
	}
	{
		goto IL_4c35;
	}

IL_484e:
	{
		int32_t L_2338 = V_339;
		if ((((int32_t)L_2338) == ((int32_t)((int32_t)4128))))
		{
			goto IL_4b58;
		}
	}
	{
		goto IL_4860;
	}

IL_4860:
	{
		int32_t L_2339 = V_339;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_2339, ((int32_t)8193)))) > ((uint32_t)1))))
		{
			goto IL_4bd4;
		}
	}
	{
		goto IL_4c35;
	}

IL_4877:
	{
		int32_t L_2340 = V_339;
		if ((((int32_t)L_2340) > ((int32_t)((int32_t)8200))))
		{
			goto IL_48ab;
		}
	}
	{
		int32_t L_2341 = V_339;
		if ((((int32_t)L_2341) == ((int32_t)((int32_t)8196))))
		{
			goto IL_4bd4;
		}
	}
	{
		goto IL_4896;
	}

IL_4896:
	{
		int32_t L_2342 = V_339;
		if ((((int32_t)L_2342) == ((int32_t)((int32_t)8200))))
		{
			goto IL_4bd4;
		}
	}
	{
		goto IL_4c35;
	}

IL_48ab:
	{
		int32_t L_2343 = V_339;
		if ((((int32_t)L_2343) == ((int32_t)((int32_t)8208))))
		{
			goto IL_4bd4;
		}
	}
	{
		goto IL_48bd;
	}

IL_48bd:
	{
		int32_t L_2344 = V_339;
		if ((((int32_t)L_2344) == ((int32_t)((int32_t)8224))))
		{
			goto IL_4bd4;
		}
	}
	{
		goto IL_4c35;
	}

IL_48d2:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2345 = ___0_generationSettings;
		NullCheck(L_2345);
		int32_t L_2346 = L_2345->___overflowMode;
		V_341 = (bool)((((int32_t)((((int32_t)L_2346) == ((int32_t)5))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_2347 = V_341;
		if (!L_2347)
		{
			goto IL_4928;
		}
	}
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_2348 = V_34;
		NullCheck(L_2348);
		int32_t L_2349 = 1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2350 = (L_2348)->GetAt(static_cast<il2cpp_array_size_t>(L_2349));
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2351 = V_19;
		float L_2352 = L_2351.___x;
		float L_2353 = __this->___m_MaxAscender;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2354 = V_19;
		float L_2355 = L_2354.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2356;
		memset((&L_2356), 0, sizeof(L_2356));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2356), ((float)il2cpp_codegen_add((0.0f), L_2352)), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract((0.0f), L_2353)), L_2355)), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2357;
		L_2357 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2350, L_2356, NULL);
		V_33 = L_2357;
		goto IL_496e;
	}

IL_4928:
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_2358 = V_34;
		NullCheck(L_2358);
		int32_t L_2359 = 1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2360 = (L_2358)->GetAt(static_cast<il2cpp_array_size_t>(L_2359));
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2361 = V_19;
		float L_2362 = L_2361.___x;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2363 = ___1_textInfo;
		NullCheck(L_2363);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_2364 = L_2363->___pageInfo;
		int32_t L_2365 = V_18;
		NullCheck(L_2364);
		float L_2366 = ((L_2364)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2365)))->___ascender;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2367 = V_19;
		float L_2368 = L_2367.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2369;
		memset((&L_2369), 0, sizeof(L_2369));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2369), ((float)il2cpp_codegen_add((0.0f), L_2362)), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract((0.0f), L_2366)), L_2368)), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2370;
		L_2370 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2360, L_2369, NULL);
		V_33 = L_2370;
	}

IL_496e:
	{
		goto IL_4c35;
	}

IL_4973:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2371 = ___0_generationSettings;
		NullCheck(L_2371);
		int32_t L_2372 = L_2371->___overflowMode;
		V_342 = (bool)((((int32_t)((((int32_t)L_2372) == ((int32_t)5))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_2373 = V_342;
		if (!L_2373)
		{
			goto IL_49f1;
		}
	}
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_2374 = V_34;
		NullCheck(L_2374);
		int32_t L_2375 = 0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2376 = (L_2374)->GetAt(static_cast<il2cpp_array_size_t>(L_2375));
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_2377 = V_34;
		NullCheck(L_2377);
		int32_t L_2378 = 1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2379 = (L_2377)->GetAt(static_cast<il2cpp_array_size_t>(L_2378));
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2380;
		L_2380 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2376, L_2379, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2381;
		L_2381 = Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline(L_2380, (2.0f), NULL);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2382 = V_19;
		float L_2383 = L_2382.___x;
		float L_2384 = __this->___m_MaxAscender;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2385 = V_19;
		float L_2386 = L_2385.___y;
		float L_2387 = V_23;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2388 = V_19;
		float L_2389 = L_2388.___w;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2390;
		memset((&L_2390), 0, sizeof(L_2390));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2390), ((float)il2cpp_codegen_add((0.0f), L_2383)), ((float)il2cpp_codegen_subtract((0.0f), ((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_2384, L_2386)), L_2387)), L_2389))/(2.0f))))), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2391;
		L_2391 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2381, L_2390, NULL);
		V_33 = L_2391;
		goto IL_4a6f;
	}

IL_49f1:
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_2392 = V_34;
		NullCheck(L_2392);
		int32_t L_2393 = 0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2394 = (L_2392)->GetAt(static_cast<il2cpp_array_size_t>(L_2393));
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_2395 = V_34;
		NullCheck(L_2395);
		int32_t L_2396 = 1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2397 = (L_2395)->GetAt(static_cast<il2cpp_array_size_t>(L_2396));
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2398;
		L_2398 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2394, L_2397, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2399;
		L_2399 = Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline(L_2398, (2.0f), NULL);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2400 = V_19;
		float L_2401 = L_2400.___x;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2402 = ___1_textInfo;
		NullCheck(L_2402);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_2403 = L_2402->___pageInfo;
		int32_t L_2404 = V_18;
		NullCheck(L_2403);
		float L_2405 = ((L_2403)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2404)))->___ascender;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2406 = V_19;
		float L_2407 = L_2406.___y;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2408 = ___1_textInfo;
		NullCheck(L_2408);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_2409 = L_2408->___pageInfo;
		int32_t L_2410 = V_18;
		NullCheck(L_2409);
		float L_2411 = ((L_2409)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2410)))->___descender;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2412 = V_19;
		float L_2413 = L_2412.___w;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2414;
		memset((&L_2414), 0, sizeof(L_2414));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2414), ((float)il2cpp_codegen_add((0.0f), L_2401)), ((float)il2cpp_codegen_subtract((0.0f), ((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_2405, L_2407)), L_2411)), L_2413))/(2.0f))))), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2415;
		L_2415 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2399, L_2414, NULL);
		V_33 = L_2415;
	}

IL_4a6f:
	{
		goto IL_4c35;
	}

IL_4a74:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2416 = ___0_generationSettings;
		NullCheck(L_2416);
		int32_t L_2417 = L_2416->___overflowMode;
		V_343 = (bool)((((int32_t)((((int32_t)L_2417) == ((int32_t)5))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_2418 = V_343;
		if (!L_2418)
		{
			goto IL_4ac6;
		}
	}
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_2419 = V_34;
		NullCheck(L_2419);
		int32_t L_2420 = 0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2421 = (L_2419)->GetAt(static_cast<il2cpp_array_size_t>(L_2420));
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2422 = V_19;
		float L_2423 = L_2422.___x;
		float L_2424 = V_23;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2425 = V_19;
		float L_2426 = L_2425.___w;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2427;
		memset((&L_2427), 0, sizeof(L_2427));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2427), ((float)il2cpp_codegen_add((0.0f), L_2423)), ((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract((0.0f), L_2424)), L_2426)), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2428;
		L_2428 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2421, L_2427, NULL);
		V_33 = L_2428;
		goto IL_4b0c;
	}

IL_4ac6:
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_2429 = V_34;
		NullCheck(L_2429);
		int32_t L_2430 = 0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2431 = (L_2429)->GetAt(static_cast<il2cpp_array_size_t>(L_2430));
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2432 = V_19;
		float L_2433 = L_2432.___x;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2434 = ___1_textInfo;
		NullCheck(L_2434);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_2435 = L_2434->___pageInfo;
		int32_t L_2436 = V_18;
		NullCheck(L_2435);
		float L_2437 = ((L_2435)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2436)))->___descender;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2438 = V_19;
		float L_2439 = L_2438.___w;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2440;
		memset((&L_2440), 0, sizeof(L_2440));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2440), ((float)il2cpp_codegen_add((0.0f), L_2433)), ((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract((0.0f), L_2437)), L_2439)), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2441;
		L_2441 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2431, L_2440, NULL);
		V_33 = L_2441;
	}

IL_4b0c:
	{
		goto IL_4c35;
	}

IL_4b11:
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_2442 = V_34;
		NullCheck(L_2442);
		int32_t L_2443 = 0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2444 = (L_2442)->GetAt(static_cast<il2cpp_array_size_t>(L_2443));
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_2445 = V_34;
		NullCheck(L_2445);
		int32_t L_2446 = 1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2447 = (L_2445)->GetAt(static_cast<il2cpp_array_size_t>(L_2446));
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2448;
		L_2448 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2444, L_2447, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2449;
		L_2449 = Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline(L_2448, (2.0f), NULL);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2450 = V_19;
		float L_2451 = L_2450.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2452;
		memset((&L_2452), 0, sizeof(L_2452));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2452), ((float)il2cpp_codegen_add((0.0f), L_2451)), (0.0f), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2453;
		L_2453 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2449, L_2452, NULL);
		V_33 = L_2453;
		goto IL_4c35;
	}

IL_4b58:
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_2454 = V_34;
		NullCheck(L_2454);
		int32_t L_2455 = 0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2456 = (L_2454)->GetAt(static_cast<il2cpp_array_size_t>(L_2455));
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_2457 = V_34;
		NullCheck(L_2457);
		int32_t L_2458 = 1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2459 = (L_2457)->GetAt(static_cast<il2cpp_array_size_t>(L_2458));
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2460;
		L_2460 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2456, L_2459, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2461;
		L_2461 = Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline(L_2460, (2.0f), NULL);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2462 = V_19;
		float L_2463 = L_2462.___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2464 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2465 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2464->___max);
		float L_2466 = L_2465->___y;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2467 = V_19;
		float L_2468 = L_2467.___y;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2469 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2470 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2469->___min);
		float L_2471 = L_2470->___y;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2472 = V_19;
		float L_2473 = L_2472.___w;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2474;
		memset((&L_2474), 0, sizeof(L_2474));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2474), ((float)il2cpp_codegen_add((0.0f), L_2463)), ((float)il2cpp_codegen_subtract((0.0f), ((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_2466, L_2468)), L_2471)), L_2473))/(2.0f))))), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2475;
		L_2475 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2461, L_2474, NULL);
		V_33 = L_2475;
		goto IL_4c35;
	}

IL_4bd4:
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_2476 = V_34;
		NullCheck(L_2476);
		int32_t L_2477 = 0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2478 = (L_2476)->GetAt(static_cast<il2cpp_array_size_t>(L_2477));
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_2479 = V_34;
		NullCheck(L_2479);
		int32_t L_2480 = 1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2481 = (L_2479)->GetAt(static_cast<il2cpp_array_size_t>(L_2480));
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2482;
		L_2482 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2478, L_2481, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2483;
		L_2483 = Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline(L_2482, (2.0f), NULL);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2484 = V_19;
		float L_2485 = L_2484.___x;
		float L_2486 = __this->___m_MaxCapHeight;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2487 = V_19;
		float L_2488 = L_2487.___y;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2489 = V_19;
		float L_2490 = L_2489.___w;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2491;
		memset((&L_2491), 0, sizeof(L_2491));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2491), ((float)il2cpp_codegen_add((0.0f), L_2485)), ((float)il2cpp_codegen_subtract((0.0f), ((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(L_2486, L_2488)), L_2490))/(2.0f))))), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2492;
		L_2492 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2483, L_2491, NULL);
		V_33 = L_2492;
		goto IL_4c35;
	}

IL_4c35:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2493;
		L_2493 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_35 = L_2493;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2494;
		L_2494 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_36 = L_2494;
		V_37 = 0;
		V_38 = 0;
		V_39 = 0;
		V_40 = (bool)0;
		V_41 = (bool)0;
		V_42 = 0;
		V_43 = 0;
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_2495;
		L_2495 = Color_get_white_m068F5AF879B0FCA584E3693F762EA41BB65532C6_inline(NULL);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_2496;
		L_2496 = Color32_op_Implicit_m79AF5E0BDE9CE041CAC4D89CBFA66E71C6DD1B70_inline(L_2495, NULL);
		V_44 = L_2496;
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_2497;
		L_2497 = Color_get_white_m068F5AF879B0FCA584E3693F762EA41BB65532C6_inline(NULL);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_2498;
		L_2498 = Color32_op_Implicit_m79AF5E0BDE9CE041CAC4D89CBFA66E71C6DD1B70_inline(L_2497, NULL);
		V_45 = L_2498;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_2499;
		memset((&L_2499), 0, sizeof(L_2499));
		Color32__ctor_mC9C6B443F0C7CA3F8B174158B2AF6F05E18EAC4E_inline((&L_2499), (uint8_t)((int32_t)255), (uint8_t)((int32_t)255), (uint8_t)0, (uint8_t)((int32_t)64), NULL);
		il2cpp_codegen_runtime_class_init_inline(Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4_il2cpp_TypeInfo_var);
		Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4 L_2500;
		L_2500 = Offset_get_zero_mF5B6D7C3F437FA438844A0B3EF405D805F1D1958(NULL);
		HighlightState__ctor_mDBB71C58F46D7BDC518026AC796D24F2D9B36D3F((&V_46), L_2499, L_2500, NULL);
		V_47 = (0.0f);
		V_48 = (0.0f);
		V_49 = (0.0f);
		V_50 = (0.0f);
		V_51 = (0.0f);
		V_52 = (32767.0f);
		V_53 = 0;
		V_54 = (0.0f);
		V_55 = (0.0f);
		V_56 = (0.0f);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2501 = ___1_textInfo;
		NullCheck(L_2501);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2502 = L_2501->___textElementInfo;
		V_57 = L_2502;
		V_344 = 0;
		goto IL_87d0;
	}

IL_4ce4:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2503 = V_57;
		int32_t L_2504 = V_344;
		NullCheck(L_2503);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_2505 = ((L_2503)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2504)))->___fontAsset;
		V_345 = L_2505;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2506 = V_57;
		int32_t L_2507 = V_344;
		NullCheck(L_2506);
		Il2CppChar L_2508 = ((L_2506)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2507)))->___character;
		V_346 = L_2508;
		Il2CppChar L_2509 = V_346;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_2510;
		L_2510 = Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924(L_2509, NULL);
		V_347 = L_2510;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2511 = V_57;
		int32_t L_2512 = V_344;
		NullCheck(L_2511);
		int32_t L_2513 = ((L_2511)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2512)))->___lineNumber;
		V_348 = L_2513;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2514 = ___1_textInfo;
		NullCheck(L_2514);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_2515 = L_2514->___lineInfo;
		int32_t L_2516 = V_348;
		NullCheck(L_2515);
		int32_t L_2517 = L_2516;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2518 = (L_2515)->GetAt(static_cast<il2cpp_array_size_t>(L_2517));
		V_349 = L_2518;
		int32_t L_2519 = V_348;
		V_38 = ((int32_t)il2cpp_codegen_add(L_2519, 1));
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2520 = V_349;
		int32_t L_2521 = L_2520.___alignment;
		V_350 = L_2521;
		int32_t L_2522 = V_350;
		V_359 = L_2522;
		int32_t L_2523 = V_359;
		V_358 = L_2523;
		int32_t L_2524 = V_358;
		if ((((int32_t)L_2524) > ((int32_t)((int32_t)1056))))
		{
			goto IL_4ed9;
		}
	}
	{
		int32_t L_2525 = V_358;
		if ((((int32_t)L_2525) > ((int32_t)((int32_t)520))))
		{
			goto IL_4e49;
		}
	}
	{
		int32_t L_2526 = V_358;
		if ((((int32_t)L_2526) > ((int32_t)((int32_t)272))))
		{
			goto IL_4dff;
		}
	}
	{
		int32_t L_2527 = V_358;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_2527, ((int32_t)257))))
		{
			case 0:
			{
				goto IL_501a;
			}
			case 1:
			{
				goto IL_507c;
			}
			case 2:
			{
				goto IL_55b9;
			}
			case 3:
			{
				goto IL_5126;
			}
		}
	}
	{
		goto IL_4dd8;
	}

IL_4dd8:
	{
		int32_t L_2528 = V_358;
		if ((((int32_t)L_2528) == ((int32_t)((int32_t)264))))
		{
			goto IL_51a0;
		}
	}
	{
		goto IL_4dea;
	}

IL_4dea:
	{
		int32_t L_2529 = V_358;
		if ((((int32_t)L_2529) == ((int32_t)((int32_t)272))))
		{
			goto IL_51a0;
		}
	}
	{
		goto IL_55b9;
	}

IL_4dff:
	{
		int32_t L_2530 = V_358;
		if ((((int32_t)L_2530) == ((int32_t)((int32_t)288))))
		{
			goto IL_50c1;
		}
	}
	{
		goto IL_4e11;
	}

IL_4e11:
	{
		int32_t L_2531 = V_358;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_2531, ((int32_t)513))))
		{
			case 0:
			{
				goto IL_501a;
			}
			case 1:
			{
				goto IL_507c;
			}
			case 2:
			{
				goto IL_55b9;
			}
			case 3:
			{
				goto IL_5126;
			}
		}
	}
	{
		goto IL_4e34;
	}

IL_4e34:
	{
		int32_t L_2532 = V_358;
		if ((((int32_t)L_2532) == ((int32_t)((int32_t)520))))
		{
			goto IL_51a0;
		}
	}
	{
		goto IL_55b9;
	}

IL_4e49:
	{
		int32_t L_2533 = V_358;
		if ((((int32_t)L_2533) > ((int32_t)((int32_t)1028))))
		{
			goto IL_4ea0;
		}
	}
	{
		int32_t L_2534 = V_358;
		if ((((int32_t)L_2534) == ((int32_t)((int32_t)528))))
		{
			goto IL_51a0;
		}
	}
	{
		goto IL_4e68;
	}

IL_4e68:
	{
		int32_t L_2535 = V_358;
		if ((((int32_t)L_2535) == ((int32_t)((int32_t)544))))
		{
			goto IL_50c1;
		}
	}
	{
		goto IL_4e7a;
	}

IL_4e7a:
	{
		int32_t L_2536 = V_358;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_2536, ((int32_t)1025))))
		{
			case 0:
			{
				goto IL_501a;
			}
			case 1:
			{
				goto IL_507c;
			}
			case 2:
			{
				goto IL_55b9;
			}
			case 3:
			{
				goto IL_5126;
			}
		}
	}
	{
		goto IL_55b9;
	}

IL_4ea0:
	{
		int32_t L_2537 = V_358;
		if ((((int32_t)L_2537) == ((int32_t)((int32_t)1032))))
		{
			goto IL_51a0;
		}
	}
	{
		goto IL_4eb2;
	}

IL_4eb2:
	{
		int32_t L_2538 = V_358;
		if ((((int32_t)L_2538) == ((int32_t)((int32_t)1040))))
		{
			goto IL_51a0;
		}
	}
	{
		goto IL_4ec4;
	}

IL_4ec4:
	{
		int32_t L_2539 = V_358;
		if ((((int32_t)L_2539) == ((int32_t)((int32_t)1056))))
		{
			goto IL_50c1;
		}
	}
	{
		goto IL_55b9;
	}

IL_4ed9:
	{
		int32_t L_2540 = V_358;
		if ((((int32_t)L_2540) > ((int32_t)((int32_t)4104))))
		{
			goto IL_4f8a;
		}
	}
	{
		int32_t L_2541 = V_358;
		if ((((int32_t)L_2541) > ((int32_t)((int32_t)2064))))
		{
			goto IL_4f40;
		}
	}
	{
		int32_t L_2542 = V_358;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_2542, ((int32_t)2049))))
		{
			case 0:
			{
				goto IL_501a;
			}
			case 1:
			{
				goto IL_507c;
			}
			case 2:
			{
				goto IL_55b9;
			}
			case 3:
			{
				goto IL_5126;
			}
		}
	}
	{
		goto IL_4f19;
	}

IL_4f19:
	{
		int32_t L_2543 = V_358;
		if ((((int32_t)L_2543) == ((int32_t)((int32_t)2056))))
		{
			goto IL_51a0;
		}
	}
	{
		goto IL_4f2b;
	}

IL_4f2b:
	{
		int32_t L_2544 = V_358;
		if ((((int32_t)L_2544) == ((int32_t)((int32_t)2064))))
		{
			goto IL_51a0;
		}
	}
	{
		goto IL_55b9;
	}

IL_4f40:
	{
		int32_t L_2545 = V_358;
		if ((((int32_t)L_2545) == ((int32_t)((int32_t)2080))))
		{
			goto IL_50c1;
		}
	}
	{
		goto IL_4f52;
	}

IL_4f52:
	{
		int32_t L_2546 = V_358;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_2546, ((int32_t)4097))))
		{
			case 0:
			{
				goto IL_501a;
			}
			case 1:
			{
				goto IL_507c;
			}
			case 2:
			{
				goto IL_55b9;
			}
			case 3:
			{
				goto IL_5126;
			}
		}
	}
	{
		goto IL_4f75;
	}

IL_4f75:
	{
		int32_t L_2547 = V_358;
		if ((((int32_t)L_2547) == ((int32_t)((int32_t)4104))))
		{
			goto IL_51a0;
		}
	}
	{
		goto IL_55b9;
	}

IL_4f8a:
	{
		int32_t L_2548 = V_358;
		if ((((int32_t)L_2548) > ((int32_t)((int32_t)8196))))
		{
			goto IL_4fe1;
		}
	}
	{
		int32_t L_2549 = V_358;
		if ((((int32_t)L_2549) == ((int32_t)((int32_t)4112))))
		{
			goto IL_51a0;
		}
	}
	{
		goto IL_4fa9;
	}

IL_4fa9:
	{
		int32_t L_2550 = V_358;
		if ((((int32_t)L_2550) == ((int32_t)((int32_t)4128))))
		{
			goto IL_50c1;
		}
	}
	{
		goto IL_4fbb;
	}

IL_4fbb:
	{
		int32_t L_2551 = V_358;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_2551, ((int32_t)8193))))
		{
			case 0:
			{
				goto IL_501a;
			}
			case 1:
			{
				goto IL_507c;
			}
			case 2:
			{
				goto IL_55b9;
			}
			case 3:
			{
				goto IL_5126;
			}
		}
	}
	{
		goto IL_55b9;
	}

IL_4fe1:
	{
		int32_t L_2552 = V_358;
		if ((((int32_t)L_2552) == ((int32_t)((int32_t)8200))))
		{
			goto IL_51a0;
		}
	}
	{
		goto IL_4ff3;
	}

IL_4ff3:
	{
		int32_t L_2553 = V_358;
		if ((((int32_t)L_2553) == ((int32_t)((int32_t)8208))))
		{
			goto IL_51a0;
		}
	}
	{
		goto IL_5005;
	}

IL_5005:
	{
		int32_t L_2554 = V_358;
		if ((((int32_t)L_2554) == ((int32_t)((int32_t)8224))))
		{
			goto IL_50c1;
		}
	}
	{
		goto IL_55b9;
	}

IL_501a:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2555 = ___0_generationSettings;
		NullCheck(L_2555);
		bool L_2556 = L_2555->___isRightToLeft;
		V_360 = (bool)((((int32_t)L_2556) == ((int32_t)0))? 1 : 0);
		bool L_2557 = V_360;
		if (!L_2557)
		{
			goto IL_5055;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2558 = V_349;
		float L_2559 = L_2558.___marginLeft;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_35), ((float)il2cpp_codegen_add((0.0f), L_2559)), (0.0f), (0.0f), NULL);
		goto IL_5077;
	}

IL_5055:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2560 = V_349;
		float L_2561 = L_2560.___maxAdvance;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_35), ((float)il2cpp_codegen_subtract((0.0f), L_2561)), (0.0f), (0.0f), NULL);
	}

IL_5077:
	{
		goto IL_55b9;
	}

IL_507c:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2562 = V_349;
		float L_2563 = L_2562.___marginLeft;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2564 = V_349;
		float L_2565 = L_2564.___width;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2566 = V_349;
		float L_2567 = L_2566.___maxAdvance;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_35), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2563, ((float)(L_2565/(2.0f))))), ((float)(L_2567/(2.0f))))), (0.0f), (0.0f), NULL);
		goto IL_55b9;
	}

IL_50c1:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2568 = V_349;
		float L_2569 = L_2568.___marginLeft;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2570 = V_349;
		float L_2571 = L_2570.___width;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2572 = V_349;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2573 = L_2572.___lineExtents;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2574 = L_2573.___min;
		float L_2575 = L_2574.___x;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2576 = V_349;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2577 = L_2576.___lineExtents;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2578 = L_2577.___max;
		float L_2579 = L_2578.___x;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_35), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2569, ((float)(L_2571/(2.0f))))), ((float)(((float)il2cpp_codegen_add(L_2575, L_2579))/(2.0f))))), (0.0f), (0.0f), NULL);
		goto IL_55b9;
	}

IL_5126:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2580 = ___0_generationSettings;
		NullCheck(L_2580);
		bool L_2581 = L_2580->___isRightToLeft;
		V_361 = (bool)((((int32_t)L_2581) == ((int32_t)0))? 1 : 0);
		bool L_2582 = V_361;
		if (!L_2582)
		{
			goto IL_5173;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2583 = V_349;
		float L_2584 = L_2583.___marginLeft;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2585 = V_349;
		float L_2586 = L_2585.___width;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2587 = V_349;
		float L_2588 = L_2587.___maxAdvance;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_35), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2584, L_2586)), L_2588)), (0.0f), (0.0f), NULL);
		goto IL_519b;
	}

IL_5173:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2589 = V_349;
		float L_2590 = L_2589.___marginLeft;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2591 = V_349;
		float L_2592 = L_2591.___width;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_35), ((float)il2cpp_codegen_add(L_2590, L_2592)), (0.0f), (0.0f), NULL);
	}

IL_519b:
	{
		goto IL_55b9;
	}

IL_51a0:
	{
		int32_t L_2593 = V_344;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2594 = V_349;
		int32_t L_2595 = L_2594.___lastVisibleCharacterIndex;
		if ((((int32_t)L_2593) > ((int32_t)L_2595)))
		{
			goto IL_51ef;
		}
	}
	{
		Il2CppChar L_2596 = V_346;
		if ((((int32_t)L_2596) == ((int32_t)((int32_t)10))))
		{
			goto IL_51ef;
		}
	}
	{
		Il2CppChar L_2597 = V_346;
		if ((((int32_t)L_2597) == ((int32_t)((int32_t)173))))
		{
			goto IL_51ef;
		}
	}
	{
		Il2CppChar L_2598 = V_346;
		if ((((int32_t)L_2598) == ((int32_t)((int32_t)8203))))
		{
			goto IL_51ef;
		}
	}
	{
		Il2CppChar L_2599 = V_346;
		if ((((int32_t)L_2599) == ((int32_t)((int32_t)8288))))
		{
			goto IL_51ef;
		}
	}
	{
		Il2CppChar L_2600 = V_346;
		G_B891_0 = ((((int32_t)L_2600) == ((int32_t)3))? 1 : 0);
		goto IL_51f0;
	}

IL_51ef:
	{
		G_B891_0 = 1;
	}

IL_51f0:
	{
		V_362 = (bool)G_B891_0;
		bool L_2601 = V_362;
		if (!L_2601)
		{
			goto IL_5203;
		}
	}
	{
		goto IL_55b9;
	}

IL_5203:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2602 = V_57;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2603 = V_349;
		int32_t L_2604 = L_2603.___lastCharacterIndex;
		NullCheck(L_2602);
		Il2CppChar L_2605 = ((L_2602)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2604)))->___character;
		V_356 = L_2605;
		int32_t L_2606 = V_350;
		V_357 = (bool)((((int32_t)((int32_t)((int32_t)L_2606&((int32_t)16)))) == ((int32_t)((int32_t)16)))? 1 : 0);
		Il2CppChar L_2607 = V_356;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_2608;
		L_2608 = Char_IsControl_m133C10360BE82B7580E4D3ECE3C881A6C82B3F7F(L_2607, NULL);
		if (L_2608)
		{
			goto IL_5250;
		}
	}
	{
		int32_t L_2609 = V_348;
		int32_t L_2610 = __this->___m_LineNumber;
		G_B896_0 = ((((int32_t)L_2609) < ((int32_t)L_2610))? 1 : 0);
		goto IL_5251;
	}

IL_5250:
	{
		G_B896_0 = 0;
	}

IL_5251:
	{
		bool L_2611 = V_357;
		if (((int32_t)(G_B896_0|(int32_t)L_2611)))
		{
			goto IL_5274;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2612 = V_349;
		float L_2613 = L_2612.___maxAdvance;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2614 = V_349;
		float L_2615 = L_2614.___width;
		G_B899_0 = ((((float)L_2613) > ((float)L_2615))? 1 : 0);
		goto IL_5275;
	}

IL_5274:
	{
		G_B899_0 = 1;
	}

IL_5275:
	{
		V_363 = (bool)G_B899_0;
		bool L_2616 = V_363;
		if (!L_2616)
		{
			goto IL_5558;
		}
	}
	{
		int32_t L_2617 = V_348;
		int32_t L_2618 = V_39;
		if ((!(((uint32_t)L_2617) == ((uint32_t)L_2618))))
		{
			goto IL_52a9;
		}
	}
	{
		int32_t L_2619 = V_344;
		if (!L_2619)
		{
			goto IL_52a9;
		}
	}
	{
		int32_t L_2620 = V_344;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2621 = ___0_generationSettings;
		NullCheck(L_2621);
		int32_t L_2622 = L_2621->___firstVisibleCharacter;
		G_B904_0 = ((((int32_t)L_2620) == ((int32_t)L_2622))? 1 : 0);
		goto IL_52aa;
	}

IL_52a9:
	{
		G_B904_0 = 1;
	}

IL_52aa:
	{
		V_364 = (bool)G_B904_0;
		bool L_2623 = V_364;
		if (!L_2623)
		{
			goto IL_5340;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2624 = ___0_generationSettings;
		NullCheck(L_2624);
		bool L_2625 = L_2624->___isRightToLeft;
		V_365 = (bool)((((int32_t)L_2625) == ((int32_t)0))? 1 : 0);
		bool L_2626 = V_365;
		if (!L_2626)
		{
			goto IL_52f1;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2627 = V_349;
		float L_2628 = L_2627.___marginLeft;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_35), L_2628, (0.0f), (0.0f), NULL);
		goto IL_5319;
	}

IL_52f1:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2629 = V_349;
		float L_2630 = L_2629.___marginLeft;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2631 = V_349;
		float L_2632 = L_2631.___width;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_35), ((float)il2cpp_codegen_add(L_2630, L_2632)), (0.0f), (0.0f), NULL);
	}

IL_5319:
	{
		Il2CppChar L_2633 = V_346;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_2634;
		L_2634 = Char_IsSeparator_m8DBA05CCFA10131140E40057E6553F7AC7397BF9(L_2633, NULL);
		V_366 = L_2634;
		bool L_2635 = V_366;
		if (!L_2635)
		{
			goto IL_5337;
		}
	}
	{
		V_40 = (bool)1;
		goto IL_533a;
	}

IL_5337:
	{
		V_40 = (bool)0;
	}

IL_533a:
	{
		goto IL_5555;
	}

IL_5340:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2636 = ___0_generationSettings;
		NullCheck(L_2636);
		bool L_2637 = L_2636->___isRightToLeft;
		if (!L_2637)
		{
			goto IL_5362;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2638 = V_349;
		float L_2639 = L_2638.___width;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2640 = V_349;
		float L_2641 = L_2640.___maxAdvance;
		G_B915_0 = ((float)il2cpp_codegen_add(L_2639, L_2641));
		goto IL_5379;
	}

IL_5362:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2642 = V_349;
		float L_2643 = L_2642.___width;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2644 = V_349;
		float L_2645 = L_2644.___maxAdvance;
		G_B915_0 = ((float)il2cpp_codegen_subtract(L_2643, L_2645));
	}

IL_5379:
	{
		V_367 = G_B915_0;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2646 = V_349;
		int32_t L_2647 = L_2646.___visibleCharacterCount;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2648 = V_349;
		int32_t L_2649 = L_2648.___controlCharacterCount;
		V_368 = ((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_subtract(L_2647, 1)), L_2649));
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2650 = V_349;
		int32_t L_2651 = L_2650.___spaceCount;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2652 = V_349;
		int32_t L_2653 = L_2652.___controlCharacterCount;
		V_369 = ((int32_t)il2cpp_codegen_subtract(L_2651, L_2653));
		bool L_2654 = V_40;
		V_371 = L_2654;
		bool L_2655 = V_371;
		if (!L_2655)
		{
			goto IL_53e9;
		}
	}
	{
		int32_t L_2656 = V_369;
		V_369 = ((int32_t)il2cpp_codegen_subtract(L_2656, 1));
		int32_t L_2657 = V_368;
		V_368 = ((int32_t)il2cpp_codegen_add(L_2657, 1));
	}

IL_53e9:
	{
		int32_t L_2658 = V_369;
		if ((((int32_t)L_2658) > ((int32_t)0)))
		{
			goto IL_53f9;
		}
	}
	{
		G_B920_0 = (1.0f);
		goto IL_53ff;
	}

IL_53f9:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2659 = ___0_generationSettings;
		NullCheck(L_2659);
		float L_2660 = L_2659->___wordWrappingRatio;
		G_B920_0 = L_2660;
	}

IL_53ff:
	{
		V_370 = G_B920_0;
		int32_t L_2661 = V_369;
		V_372 = (bool)((((int32_t)L_2661) < ((int32_t)1))? 1 : 0);
		bool L_2662 = V_372;
		if (!L_2662)
		{
			goto IL_5423;
		}
	}
	{
		V_369 = 1;
	}

IL_5423:
	{
		Il2CppChar L_2663 = V_346;
		if ((((int32_t)L_2663) == ((int32_t)((int32_t)160))))
		{
			goto IL_544a;
		}
	}
	{
		Il2CppChar L_2664 = V_346;
		if ((((int32_t)L_2664) == ((int32_t)((int32_t)9))))
		{
			goto IL_5447;
		}
	}
	{
		Il2CppChar L_2665 = V_346;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_2666;
		L_2666 = Char_IsSeparator_m8DBA05CCFA10131140E40057E6553F7AC7397BF9(L_2665, NULL);
		G_B926_0 = ((int32_t)(L_2666));
		goto IL_5448;
	}

IL_5447:
	{
		G_B926_0 = 1;
	}

IL_5448:
	{
		G_B928_0 = G_B926_0;
		goto IL_544b;
	}

IL_544a:
	{
		G_B928_0 = 0;
	}

IL_544b:
	{
		V_373 = (bool)G_B928_0;
		bool L_2667 = V_373;
		if (!L_2667)
		{
			goto IL_54df;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2668 = ___0_generationSettings;
		NullCheck(L_2668);
		bool L_2669 = L_2668->___isRightToLeft;
		V_374 = (bool)((((int32_t)L_2669) == ((int32_t)0))? 1 : 0);
		bool L_2670 = V_374;
		if (!L_2670)
		{
			goto IL_54a9;
		}
	}
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2671 = V_35;
		float L_2672 = V_367;
		float L_2673 = V_370;
		int32_t L_2674 = V_369;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2675;
		memset((&L_2675), 0, sizeof(L_2675));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2675), ((float)(((float)il2cpp_codegen_multiply(L_2672, ((float)il2cpp_codegen_subtract((1.0f), L_2673))))/((float)L_2674))), (0.0f), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2676;
		L_2676 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2671, L_2675, NULL);
		V_35 = L_2676;
		goto IL_54dc;
	}

IL_54a9:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2677 = V_35;
		float L_2678 = V_367;
		float L_2679 = V_370;
		int32_t L_2680 = V_369;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2681;
		memset((&L_2681), 0, sizeof(L_2681));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2681), ((float)(((float)il2cpp_codegen_multiply(L_2678, ((float)il2cpp_codegen_subtract((1.0f), L_2679))))/((float)L_2680))), (0.0f), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2682;
		L_2682 = Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline(L_2677, L_2681, NULL);
		V_35 = L_2682;
	}

IL_54dc:
	{
		goto IL_5554;
	}

IL_54df:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2683 = ___0_generationSettings;
		NullCheck(L_2683);
		bool L_2684 = L_2683->___isRightToLeft;
		V_375 = (bool)((((int32_t)L_2684) == ((int32_t)0))? 1 : 0);
		bool L_2685 = V_375;
		if (!L_2685)
		{
			goto IL_5526;
		}
	}
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2686 = V_35;
		float L_2687 = V_367;
		float L_2688 = V_370;
		int32_t L_2689 = V_368;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2690;
		memset((&L_2690), 0, sizeof(L_2690));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2690), ((float)(((float)il2cpp_codegen_multiply(L_2687, L_2688))/((float)L_2689))), (0.0f), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2691;
		L_2691 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2686, L_2690, NULL);
		V_35 = L_2691;
		goto IL_5553;
	}

IL_5526:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2692 = V_35;
		float L_2693 = V_367;
		float L_2694 = V_370;
		int32_t L_2695 = V_368;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2696;
		memset((&L_2696), 0, sizeof(L_2696));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2696), ((float)(((float)il2cpp_codegen_multiply(L_2693, L_2694))/((float)L_2695))), (0.0f), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2697;
		L_2697 = Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline(L_2692, L_2696, NULL);
		V_35 = L_2697;
	}

IL_5553:
	{
	}

IL_5554:
	{
	}

IL_5555:
	{
		goto IL_55b7;
	}

IL_5558:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2698 = ___0_generationSettings;
		NullCheck(L_2698);
		bool L_2699 = L_2698->___isRightToLeft;
		V_376 = (bool)((((int32_t)L_2699) == ((int32_t)0))? 1 : 0);
		bool L_2700 = V_376;
		if (!L_2700)
		{
			goto IL_558e;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2701 = V_349;
		float L_2702 = L_2701.___marginLeft;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_35), L_2702, (0.0f), (0.0f), NULL);
		goto IL_55b6;
	}

IL_558e:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2703 = V_349;
		float L_2704 = L_2703.___marginLeft;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2705 = V_349;
		float L_2706 = L_2705.___width;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_35), ((float)il2cpp_codegen_add(L_2704, L_2706)), (0.0f), (0.0f), NULL);
	}

IL_55b6:
	{
	}

IL_55b7:
	{
		goto IL_55b9;
	}

IL_55b9:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2707 = V_33;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2708 = V_35;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2709;
		L_2709 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2707, L_2708, NULL);
		V_36 = L_2709;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2710 = V_57;
		int32_t L_2711 = V_344;
		NullCheck(L_2710);
		bool L_2712 = ((L_2710)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2711)))->___isVisible;
		V_351 = L_2712;
		bool L_2713 = V_351;
		V_377 = L_2713;
		bool L_2714 = V_377;
		if (!L_2714)
		{
			goto IL_6bfd;
		}
	}
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2715 = V_57;
		int32_t L_2716 = V_344;
		NullCheck(L_2715);
		uint8_t L_2717 = ((L_2715)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2716)))->___elementType;
		V_378 = L_2717;
		uint8_t L_2718 = V_378;
		V_383 = L_2718;
		uint8_t L_2719 = V_383;
		V_382 = L_2719;
		uint8_t L_2720 = V_382;
		if ((((int32_t)L_2720) == ((int32_t)1)))
		{
			goto IL_5640;
		}
	}
	{
		goto IL_562f;
	}

IL_562f:
	{
		uint8_t L_2721 = V_382;
		if ((((int32_t)L_2721) == ((int32_t)2)))
		{
			goto IL_6885;
		}
	}
	{
		goto IL_6887;
	}

IL_5640:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2722 = V_349;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2723 = L_2722.___lineExtents;
		V_380 = L_2723;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2724 = ___0_generationSettings;
		NullCheck(L_2724);
		float L_2725 = L_2724->___uvLineOffset;
		int32_t L_2726 = V_348;
		V_381 = (fmodf(((float)il2cpp_codegen_multiply(L_2725, ((float)L_2726))), (1.0f)));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2727 = ___0_generationSettings;
		NullCheck(L_2727);
		int32_t L_2728 = L_2727->___horizontalMapping;
		V_386 = L_2728;
		int32_t L_2729 = V_386;
		V_385 = L_2729;
		int32_t L_2730 = V_385;
		switch (L_2730)
		{
			case 0:
			{
				goto IL_56a3;
			}
			case 1:
			{
				goto IL_572c;
			}
			case 2:
			{
				goto IL_5b09;
			}
			case 3:
			{
				goto IL_5cf6;
			}
		}
	}
	{
		goto IL_61f5;
	}

IL_56a3:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2731 = V_57;
		int32_t L_2732 = V_344;
		NullCheck(L_2731);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2733 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2731)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2732)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2734 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2733->___uv2);
		L_2734->___x = (0.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2735 = V_57;
		int32_t L_2736 = V_344;
		NullCheck(L_2735);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2737 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2735)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2736)))->___vertexTopLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2738 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2737->___uv2);
		L_2738->___x = (0.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2739 = V_57;
		int32_t L_2740 = V_344;
		NullCheck(L_2739);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2741 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2739)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2740)))->___vertexTopRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2742 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2741->___uv2);
		L_2742->___x = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2743 = V_57;
		int32_t L_2744 = V_344;
		NullCheck(L_2743);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2745 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2743)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2744)))->___vertexBottomRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2746 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2745->___uv2);
		L_2746->___x = (1.0f);
		goto IL_61f5;
	}

IL_572c:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2747 = ___0_generationSettings;
		NullCheck(L_2747);
		int32_t L_2748 = L_2747->___textAlignment;
		V_387 = (bool)((((int32_t)((((int32_t)L_2748) == ((int32_t)((int32_t)520)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_2749 = V_387;
		if (!L_2749)
		{
			goto IL_591b;
		}
	}
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2750 = V_57;
		int32_t L_2751 = V_344;
		NullCheck(L_2750);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2752 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2750)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2751)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2753 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2752->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2754 = V_57;
		int32_t L_2755 = V_344;
		NullCheck(L_2754);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2756 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2754)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2755)))->___vertexBottomLeft);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2757 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2756->___position);
		float L_2758 = L_2757->___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2759 = V_380;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2760 = L_2759.___min;
		float L_2761 = L_2760.___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2762 = V_380;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2763 = L_2762.___max;
		float L_2764 = L_2763.___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2765 = V_380;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2766 = L_2765.___min;
		float L_2767 = L_2766.___x;
		float L_2768 = V_381;
		L_2753->___x = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_2758, L_2761))/((float)il2cpp_codegen_subtract(L_2764, L_2767)))), L_2768));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2769 = V_57;
		int32_t L_2770 = V_344;
		NullCheck(L_2769);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2771 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2769)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2770)))->___vertexTopLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2772 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2771->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2773 = V_57;
		int32_t L_2774 = V_344;
		NullCheck(L_2773);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2775 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2773)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2774)))->___vertexTopLeft);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2776 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2775->___position);
		float L_2777 = L_2776->___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2778 = V_380;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2779 = L_2778.___min;
		float L_2780 = L_2779.___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2781 = V_380;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2782 = L_2781.___max;
		float L_2783 = L_2782.___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2784 = V_380;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2785 = L_2784.___min;
		float L_2786 = L_2785.___x;
		float L_2787 = V_381;
		L_2772->___x = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_2777, L_2780))/((float)il2cpp_codegen_subtract(L_2783, L_2786)))), L_2787));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2788 = V_57;
		int32_t L_2789 = V_344;
		NullCheck(L_2788);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2790 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2788)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2789)))->___vertexTopRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2791 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2790->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2792 = V_57;
		int32_t L_2793 = V_344;
		NullCheck(L_2792);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2794 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2792)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2793)))->___vertexTopRight);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2795 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2794->___position);
		float L_2796 = L_2795->___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2797 = V_380;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2798 = L_2797.___min;
		float L_2799 = L_2798.___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2800 = V_380;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2801 = L_2800.___max;
		float L_2802 = L_2801.___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2803 = V_380;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2804 = L_2803.___min;
		float L_2805 = L_2804.___x;
		float L_2806 = V_381;
		L_2791->___x = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_2796, L_2799))/((float)il2cpp_codegen_subtract(L_2802, L_2805)))), L_2806));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2807 = V_57;
		int32_t L_2808 = V_344;
		NullCheck(L_2807);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2809 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2807)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2808)))->___vertexBottomRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2810 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2809->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2811 = V_57;
		int32_t L_2812 = V_344;
		NullCheck(L_2811);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2813 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2811)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2812)))->___vertexBottomRight);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2814 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2813->___position);
		float L_2815 = L_2814->___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2816 = V_380;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2817 = L_2816.___min;
		float L_2818 = L_2817.___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2819 = V_380;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2820 = L_2819.___max;
		float L_2821 = L_2820.___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2822 = V_380;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2823 = L_2822.___min;
		float L_2824 = L_2823.___x;
		float L_2825 = V_381;
		L_2810->___x = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_2815, L_2818))/((float)il2cpp_codegen_subtract(L_2821, L_2824)))), L_2825));
		goto IL_61f5;
	}

IL_591b:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2826 = V_57;
		int32_t L_2827 = V_344;
		NullCheck(L_2826);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2828 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2826)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2827)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2829 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2828->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2830 = V_57;
		int32_t L_2831 = V_344;
		NullCheck(L_2830);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2832 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2830)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2831)))->___vertexBottomLeft);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2833 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2832->___position);
		float L_2834 = L_2833->___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2835 = V_35;
		float L_2836 = L_2835.___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2837 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2838 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2837->___min);
		float L_2839 = L_2838->___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2840 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2841 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2840->___max);
		float L_2842 = L_2841->___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2843 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2844 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2843->___min);
		float L_2845 = L_2844->___x;
		float L_2846 = V_381;
		L_2829->___x = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2834, L_2836)), L_2839))/((float)il2cpp_codegen_subtract(L_2842, L_2845)))), L_2846));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2847 = V_57;
		int32_t L_2848 = V_344;
		NullCheck(L_2847);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2849 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2847)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2848)))->___vertexTopLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2850 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2849->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2851 = V_57;
		int32_t L_2852 = V_344;
		NullCheck(L_2851);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2853 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2851)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2852)))->___vertexTopLeft);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2854 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2853->___position);
		float L_2855 = L_2854->___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2856 = V_35;
		float L_2857 = L_2856.___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2858 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2859 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2858->___min);
		float L_2860 = L_2859->___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2861 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2862 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2861->___max);
		float L_2863 = L_2862->___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2864 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2865 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2864->___min);
		float L_2866 = L_2865->___x;
		float L_2867 = V_381;
		L_2850->___x = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2855, L_2857)), L_2860))/((float)il2cpp_codegen_subtract(L_2863, L_2866)))), L_2867));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2868 = V_57;
		int32_t L_2869 = V_344;
		NullCheck(L_2868);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2870 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2868)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2869)))->___vertexTopRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2871 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2870->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2872 = V_57;
		int32_t L_2873 = V_344;
		NullCheck(L_2872);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2874 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2872)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2873)))->___vertexTopRight);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2875 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2874->___position);
		float L_2876 = L_2875->___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2877 = V_35;
		float L_2878 = L_2877.___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2879 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2880 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2879->___min);
		float L_2881 = L_2880->___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2882 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2883 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2882->___max);
		float L_2884 = L_2883->___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2885 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2886 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2885->___min);
		float L_2887 = L_2886->___x;
		float L_2888 = V_381;
		L_2871->___x = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2876, L_2878)), L_2881))/((float)il2cpp_codegen_subtract(L_2884, L_2887)))), L_2888));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2889 = V_57;
		int32_t L_2890 = V_344;
		NullCheck(L_2889);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2891 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2889)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2890)))->___vertexBottomRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2892 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2891->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2893 = V_57;
		int32_t L_2894 = V_344;
		NullCheck(L_2893);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2895 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2893)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2894)))->___vertexBottomRight);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2896 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2895->___position);
		float L_2897 = L_2896->___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2898 = V_35;
		float L_2899 = L_2898.___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2900 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2901 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2900->___min);
		float L_2902 = L_2901->___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2903 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2904 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2903->___max);
		float L_2905 = L_2904->___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2906 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2907 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2906->___min);
		float L_2908 = L_2907->___x;
		float L_2909 = V_381;
		L_2892->___x = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2897, L_2899)), L_2902))/((float)il2cpp_codegen_subtract(L_2905, L_2908)))), L_2909));
		goto IL_61f5;
	}

IL_5b09:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2910 = V_57;
		int32_t L_2911 = V_344;
		NullCheck(L_2910);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2912 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2910)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2911)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2913 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2912->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2914 = V_57;
		int32_t L_2915 = V_344;
		NullCheck(L_2914);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2916 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2914)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2915)))->___vertexBottomLeft);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2917 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2916->___position);
		float L_2918 = L_2917->___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2919 = V_35;
		float L_2920 = L_2919.___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2921 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2922 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2921->___min);
		float L_2923 = L_2922->___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2924 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2925 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2924->___max);
		float L_2926 = L_2925->___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2927 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2928 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2927->___min);
		float L_2929 = L_2928->___x;
		float L_2930 = V_381;
		L_2913->___x = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2918, L_2920)), L_2923))/((float)il2cpp_codegen_subtract(L_2926, L_2929)))), L_2930));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2931 = V_57;
		int32_t L_2932 = V_344;
		NullCheck(L_2931);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2933 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2931)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2932)))->___vertexTopLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2934 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2933->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2935 = V_57;
		int32_t L_2936 = V_344;
		NullCheck(L_2935);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2937 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2935)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2936)))->___vertexTopLeft);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2938 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2937->___position);
		float L_2939 = L_2938->___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2940 = V_35;
		float L_2941 = L_2940.___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2942 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2943 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2942->___min);
		float L_2944 = L_2943->___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2945 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2946 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2945->___max);
		float L_2947 = L_2946->___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2948 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2949 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2948->___min);
		float L_2950 = L_2949->___x;
		float L_2951 = V_381;
		L_2934->___x = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2939, L_2941)), L_2944))/((float)il2cpp_codegen_subtract(L_2947, L_2950)))), L_2951));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2952 = V_57;
		int32_t L_2953 = V_344;
		NullCheck(L_2952);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2954 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2952)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2953)))->___vertexTopRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2955 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2954->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2956 = V_57;
		int32_t L_2957 = V_344;
		NullCheck(L_2956);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2958 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2956)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2957)))->___vertexTopRight);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2959 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2958->___position);
		float L_2960 = L_2959->___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2961 = V_35;
		float L_2962 = L_2961.___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2963 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2964 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2963->___min);
		float L_2965 = L_2964->___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2966 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2967 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2966->___max);
		float L_2968 = L_2967->___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2969 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2970 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2969->___min);
		float L_2971 = L_2970->___x;
		float L_2972 = V_381;
		L_2955->___x = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2960, L_2962)), L_2965))/((float)il2cpp_codegen_subtract(L_2968, L_2971)))), L_2972));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2973 = V_57;
		int32_t L_2974 = V_344;
		NullCheck(L_2973);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2975 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2973)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2974)))->___vertexBottomRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2976 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2975->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2977 = V_57;
		int32_t L_2978 = V_344;
		NullCheck(L_2977);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2979 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2977)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2978)))->___vertexBottomRight);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2980 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2979->___position);
		float L_2981 = L_2980->___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2982 = V_35;
		float L_2983 = L_2982.___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2984 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2985 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2984->___min);
		float L_2986 = L_2985->___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2987 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2988 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2987->___max);
		float L_2989 = L_2988->___x;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2990 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2991 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2990->___min);
		float L_2992 = L_2991->___x;
		float L_2993 = V_381;
		L_2976->___x = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2981, L_2983)), L_2986))/((float)il2cpp_codegen_subtract(L_2989, L_2992)))), L_2993));
		goto IL_61f5;
	}

IL_5cf6:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2994 = ___0_generationSettings;
		NullCheck(L_2994);
		int32_t L_2995 = L_2994->___verticalMapping;
		V_389 = L_2995;
		int32_t L_2996 = V_389;
		V_388 = L_2996;
		int32_t L_2997 = V_388;
		switch (L_2997)
		{
			case 0:
			{
				goto IL_5d2e;
			}
			case 1:
			{
				goto IL_5db7;
			}
			case 2:
			{
				goto IL_5f10;
			}
			case 3:
			{
				goto IL_6066;
			}
		}
	}
	{
		goto IL_6073;
	}

IL_5d2e:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2998 = V_57;
		int32_t L_2999 = V_344;
		NullCheck(L_2998);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3000 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2998)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2999)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3001 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3000->___uv2);
		L_3001->___y = (0.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3002 = V_57;
		int32_t L_3003 = V_344;
		NullCheck(L_3002);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3004 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3002)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3003)))->___vertexTopLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3005 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3004->___uv2);
		L_3005->___y = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3006 = V_57;
		int32_t L_3007 = V_344;
		NullCheck(L_3006);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3008 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3006)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3007)))->___vertexTopRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3009 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3008->___uv2);
		L_3009->___y = (0.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3010 = V_57;
		int32_t L_3011 = V_344;
		NullCheck(L_3010);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3012 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3010)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3011)))->___vertexBottomRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3013 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3012->___uv2);
		L_3013->___y = (1.0f);
		goto IL_6073;
	}

IL_5db7:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3014 = V_57;
		int32_t L_3015 = V_344;
		NullCheck(L_3014);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3016 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3014)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3015)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3017 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3016->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3018 = V_57;
		int32_t L_3019 = V_344;
		NullCheck(L_3018);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3020 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3018)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3019)))->___vertexBottomLeft);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3021 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_3020->___position);
		float L_3022 = L_3021->___y;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_3023 = V_380;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3024 = L_3023.___min;
		float L_3025 = L_3024.___y;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_3026 = V_380;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3027 = L_3026.___max;
		float L_3028 = L_3027.___y;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_3029 = V_380;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3030 = L_3029.___min;
		float L_3031 = L_3030.___y;
		float L_3032 = V_381;
		L_3017->___y = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_3022, L_3025))/((float)il2cpp_codegen_subtract(L_3028, L_3031)))), L_3032));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3033 = V_57;
		int32_t L_3034 = V_344;
		NullCheck(L_3033);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3035 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3033)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3034)))->___vertexTopLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3036 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3035->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3037 = V_57;
		int32_t L_3038 = V_344;
		NullCheck(L_3037);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3039 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3037)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3038)))->___vertexTopLeft);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3040 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_3039->___position);
		float L_3041 = L_3040->___y;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_3042 = V_380;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3043 = L_3042.___min;
		float L_3044 = L_3043.___y;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_3045 = V_380;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3046 = L_3045.___max;
		float L_3047 = L_3046.___y;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_3048 = V_380;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3049 = L_3048.___min;
		float L_3050 = L_3049.___y;
		float L_3051 = V_381;
		L_3036->___y = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_3041, L_3044))/((float)il2cpp_codegen_subtract(L_3047, L_3050)))), L_3051));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3052 = V_57;
		int32_t L_3053 = V_344;
		NullCheck(L_3052);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3054 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3052)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3053)))->___vertexTopRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3055 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3054->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3056 = V_57;
		int32_t L_3057 = V_344;
		NullCheck(L_3056);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3058 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3056)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3057)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3059 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3058->___uv2);
		float L_3060 = L_3059->___y;
		L_3055->___y = L_3060;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3061 = V_57;
		int32_t L_3062 = V_344;
		NullCheck(L_3061);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3063 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3061)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3062)))->___vertexBottomRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3064 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3063->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3065 = V_57;
		int32_t L_3066 = V_344;
		NullCheck(L_3065);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3067 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3065)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3066)))->___vertexTopLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3068 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3067->___uv2);
		float L_3069 = L_3068->___y;
		L_3064->___y = L_3069;
		goto IL_6073;
	}

IL_5f10:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3070 = V_57;
		int32_t L_3071 = V_344;
		NullCheck(L_3070);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3072 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3070)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3071)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3073 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3072->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3074 = V_57;
		int32_t L_3075 = V_344;
		NullCheck(L_3074);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3076 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3074)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3075)))->___vertexBottomLeft);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3077 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_3076->___position);
		float L_3078 = L_3077->___y;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3079 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3080 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3079->___min);
		float L_3081 = L_3080->___y;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3082 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3083 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3082->___max);
		float L_3084 = L_3083->___y;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3085 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3086 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3085->___min);
		float L_3087 = L_3086->___y;
		float L_3088 = V_381;
		L_3073->___y = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_3078, L_3081))/((float)il2cpp_codegen_subtract(L_3084, L_3087)))), L_3088));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3089 = V_57;
		int32_t L_3090 = V_344;
		NullCheck(L_3089);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3091 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3089)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3090)))->___vertexTopLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3092 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3091->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3093 = V_57;
		int32_t L_3094 = V_344;
		NullCheck(L_3093);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3095 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3093)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3094)))->___vertexTopLeft);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3096 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_3095->___position);
		float L_3097 = L_3096->___y;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3098 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3099 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3098->___min);
		float L_3100 = L_3099->___y;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3101 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3102 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3101->___max);
		float L_3103 = L_3102->___y;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3104 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3105 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3104->___min);
		float L_3106 = L_3105->___y;
		float L_3107 = V_381;
		L_3092->___y = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_3097, L_3100))/((float)il2cpp_codegen_subtract(L_3103, L_3106)))), L_3107));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3108 = V_57;
		int32_t L_3109 = V_344;
		NullCheck(L_3108);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3110 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3108)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3109)))->___vertexTopRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3111 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3110->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3112 = V_57;
		int32_t L_3113 = V_344;
		NullCheck(L_3112);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3114 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3112)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3113)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3115 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3114->___uv2);
		float L_3116 = L_3115->___y;
		L_3111->___y = L_3116;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3117 = V_57;
		int32_t L_3118 = V_344;
		NullCheck(L_3117);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3119 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3117)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3118)))->___vertexBottomRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3120 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3119->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3121 = V_57;
		int32_t L_3122 = V_344;
		NullCheck(L_3121);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3123 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3121)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3122)))->___vertexTopLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3124 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3123->___uv2);
		float L_3125 = L_3124->___y;
		L_3120->___y = L_3125;
		goto IL_6073;
	}

IL_6066:
	{
		il2cpp_codegen_runtime_class_init_inline(Debug_t8394C7EEAECA3689C2C9B9DE9C7166D73596276F_il2cpp_TypeInfo_var);
		Debug_Log_m87A9A3C761FF5C43ED8A53B16190A53D08F818BB(_stringLiteralAFB91D1DF3A99213A5F62F37EB0B31E6121411C4, NULL);
		goto IL_6073;
	}

IL_6073:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3126 = V_57;
		int32_t L_3127 = V_344;
		NullCheck(L_3126);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3128 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3126)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3127)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3129 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3128->___uv2);
		float L_3130 = L_3129->___y;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3131 = V_57;
		int32_t L_3132 = V_344;
		NullCheck(L_3131);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3133 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3131)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3132)))->___vertexTopLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3134 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3133->___uv2);
		float L_3135 = L_3134->___y;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3136 = V_57;
		int32_t L_3137 = V_344;
		NullCheck(L_3136);
		float L_3138 = ((L_3136)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3137)))->___aspectRatio;
		V_384 = ((float)(((float)il2cpp_codegen_subtract((1.0f), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_3130, L_3135)), L_3138))))/(2.0f)));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3139 = V_57;
		int32_t L_3140 = V_344;
		NullCheck(L_3139);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3141 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3139)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3140)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3142 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3141->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3143 = V_57;
		int32_t L_3144 = V_344;
		NullCheck(L_3143);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3145 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3143)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3144)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3146 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3145->___uv2);
		float L_3147 = L_3146->___y;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3148 = V_57;
		int32_t L_3149 = V_344;
		NullCheck(L_3148);
		float L_3150 = ((L_3148)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3149)))->___aspectRatio;
		float L_3151 = V_384;
		float L_3152 = V_381;
		L_3142->___x = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_3147, L_3150)), L_3151)), L_3152));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3153 = V_57;
		int32_t L_3154 = V_344;
		NullCheck(L_3153);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3155 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3153)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3154)))->___vertexTopLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3156 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3155->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3157 = V_57;
		int32_t L_3158 = V_344;
		NullCheck(L_3157);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3159 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3157)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3158)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3160 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3159->___uv2);
		float L_3161 = L_3160->___x;
		L_3156->___x = L_3161;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3162 = V_57;
		int32_t L_3163 = V_344;
		NullCheck(L_3162);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3164 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3162)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3163)))->___vertexTopRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3165 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3164->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3166 = V_57;
		int32_t L_3167 = V_344;
		NullCheck(L_3166);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3168 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3166)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3167)))->___vertexTopLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3169 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3168->___uv2);
		float L_3170 = L_3169->___y;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3171 = V_57;
		int32_t L_3172 = V_344;
		NullCheck(L_3171);
		float L_3173 = ((L_3171)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3172)))->___aspectRatio;
		float L_3174 = V_384;
		float L_3175 = V_381;
		L_3165->___x = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_3170, L_3173)), L_3174)), L_3175));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3176 = V_57;
		int32_t L_3177 = V_344;
		NullCheck(L_3176);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3178 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3176)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3177)))->___vertexBottomRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3179 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3178->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3180 = V_57;
		int32_t L_3181 = V_344;
		NullCheck(L_3180);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3182 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3180)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3181)))->___vertexTopRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3183 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3182->___uv2);
		float L_3184 = L_3183->___x;
		L_3179->___x = L_3184;
		goto IL_61f5;
	}

IL_61f5:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3185 = ___0_generationSettings;
		NullCheck(L_3185);
		int32_t L_3186 = L_3185->___verticalMapping;
		V_392 = L_3186;
		int32_t L_3187 = V_392;
		V_391 = L_3187;
		int32_t L_3188 = V_391;
		switch (L_3188)
		{
			case 0:
			{
				goto IL_622d;
			}
			case 1:
			{
				goto IL_62b6;
			}
			case 2:
			{
				goto IL_63e3;
			}
			case 3:
			{
				goto IL_652e;
			}
		}
	}
	{
		goto IL_66a2;
	}

IL_622d:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3189 = V_57;
		int32_t L_3190 = V_344;
		NullCheck(L_3189);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3191 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3189)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3190)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3192 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3191->___uv2);
		L_3192->___y = (0.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3193 = V_57;
		int32_t L_3194 = V_344;
		NullCheck(L_3193);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3195 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3193)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3194)))->___vertexTopLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3196 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3195->___uv2);
		L_3196->___y = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3197 = V_57;
		int32_t L_3198 = V_344;
		NullCheck(L_3197);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3199 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3197)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3198)))->___vertexTopRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3200 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3199->___uv2);
		L_3200->___y = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3201 = V_57;
		int32_t L_3202 = V_344;
		NullCheck(L_3201);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3203 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3201)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3202)))->___vertexBottomRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3204 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3203->___uv2);
		L_3204->___y = (0.0f);
		goto IL_66a2;
	}

IL_62b6:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3205 = V_57;
		int32_t L_3206 = V_344;
		NullCheck(L_3205);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3207 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3205)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3206)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3208 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3207->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3209 = V_57;
		int32_t L_3210 = V_344;
		NullCheck(L_3209);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3211 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3209)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3210)))->___vertexBottomLeft);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3212 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_3211->___position);
		float L_3213 = L_3212->___y;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3214 = V_349;
		float L_3215 = L_3214.___descender;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3216 = V_349;
		float L_3217 = L_3216.___ascender;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3218 = V_349;
		float L_3219 = L_3218.___descender;
		L_3208->___y = ((float)(((float)il2cpp_codegen_subtract(L_3213, L_3215))/((float)il2cpp_codegen_subtract(L_3217, L_3219))));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3220 = V_57;
		int32_t L_3221 = V_344;
		NullCheck(L_3220);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3222 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3220)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3221)))->___vertexTopLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3223 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3222->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3224 = V_57;
		int32_t L_3225 = V_344;
		NullCheck(L_3224);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3226 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3224)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3225)))->___vertexTopLeft);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3227 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_3226->___position);
		float L_3228 = L_3227->___y;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3229 = V_349;
		float L_3230 = L_3229.___descender;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3231 = V_349;
		float L_3232 = L_3231.___ascender;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3233 = V_349;
		float L_3234 = L_3233.___descender;
		L_3223->___y = ((float)(((float)il2cpp_codegen_subtract(L_3228, L_3230))/((float)il2cpp_codegen_subtract(L_3232, L_3234))));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3235 = V_57;
		int32_t L_3236 = V_344;
		NullCheck(L_3235);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3237 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3235)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3236)))->___vertexTopRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3238 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3237->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3239 = V_57;
		int32_t L_3240 = V_344;
		NullCheck(L_3239);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3241 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3239)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3240)))->___vertexTopLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3242 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3241->___uv2);
		float L_3243 = L_3242->___y;
		L_3238->___y = L_3243;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3244 = V_57;
		int32_t L_3245 = V_344;
		NullCheck(L_3244);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3246 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3244)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3245)))->___vertexBottomRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3247 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3246->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3248 = V_57;
		int32_t L_3249 = V_344;
		NullCheck(L_3248);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3250 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3248)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3249)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3251 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3250->___uv2);
		float L_3252 = L_3251->___y;
		L_3247->___y = L_3252;
		goto IL_66a2;
	}

IL_63e3:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3253 = V_57;
		int32_t L_3254 = V_344;
		NullCheck(L_3253);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3255 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3253)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3254)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3256 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3255->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3257 = V_57;
		int32_t L_3258 = V_344;
		NullCheck(L_3257);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3259 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3257)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3258)))->___vertexBottomLeft);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3260 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_3259->___position);
		float L_3261 = L_3260->___y;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3262 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3263 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3262->___min);
		float L_3264 = L_3263->___y;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3265 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3266 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3265->___max);
		float L_3267 = L_3266->___y;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3268 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3269 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3268->___min);
		float L_3270 = L_3269->___y;
		L_3256->___y = ((float)(((float)il2cpp_codegen_subtract(L_3261, L_3264))/((float)il2cpp_codegen_subtract(L_3267, L_3270))));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3271 = V_57;
		int32_t L_3272 = V_344;
		NullCheck(L_3271);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3273 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3271)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3272)))->___vertexTopLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3274 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3273->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3275 = V_57;
		int32_t L_3276 = V_344;
		NullCheck(L_3275);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3277 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3275)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3276)))->___vertexTopLeft);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3278 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_3277->___position);
		float L_3279 = L_3278->___y;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3280 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3281 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3280->___min);
		float L_3282 = L_3281->___y;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3283 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3284 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3283->___max);
		float L_3285 = L_3284->___y;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3286 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3287 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3286->___min);
		float L_3288 = L_3287->___y;
		L_3274->___y = ((float)(((float)il2cpp_codegen_subtract(L_3279, L_3282))/((float)il2cpp_codegen_subtract(L_3285, L_3288))));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3289 = V_57;
		int32_t L_3290 = V_344;
		NullCheck(L_3289);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3291 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3289)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3290)))->___vertexTopRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3292 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3291->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3293 = V_57;
		int32_t L_3294 = V_344;
		NullCheck(L_3293);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3295 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3293)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3294)))->___vertexTopLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3296 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3295->___uv2);
		float L_3297 = L_3296->___y;
		L_3292->___y = L_3297;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3298 = V_57;
		int32_t L_3299 = V_344;
		NullCheck(L_3298);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3300 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3298)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3299)))->___vertexBottomRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3301 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3300->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3302 = V_57;
		int32_t L_3303 = V_344;
		NullCheck(L_3302);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3304 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3302)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3303)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3305 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3304->___uv2);
		float L_3306 = L_3305->___y;
		L_3301->___y = L_3306;
		goto IL_66a2;
	}

IL_652e:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3307 = V_57;
		int32_t L_3308 = V_344;
		NullCheck(L_3307);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3309 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3307)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3308)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3310 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3309->___uv2);
		float L_3311 = L_3310->___x;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3312 = V_57;
		int32_t L_3313 = V_344;
		NullCheck(L_3312);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3314 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3312)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3313)))->___vertexTopRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3315 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3314->___uv2);
		float L_3316 = L_3315->___x;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3317 = V_57;
		int32_t L_3318 = V_344;
		NullCheck(L_3317);
		float L_3319 = ((L_3317)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3318)))->___aspectRatio;
		V_390 = ((float)(((float)il2cpp_codegen_subtract((1.0f), ((float)(((float)il2cpp_codegen_add(L_3311, L_3316))/L_3319))))/(2.0f)));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3320 = V_57;
		int32_t L_3321 = V_344;
		NullCheck(L_3320);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3322 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3320)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3321)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3323 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3322->___uv2);
		float L_3324 = V_390;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3325 = V_57;
		int32_t L_3326 = V_344;
		NullCheck(L_3325);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3327 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3325)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3326)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3328 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3327->___uv2);
		float L_3329 = L_3328->___x;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3330 = V_57;
		int32_t L_3331 = V_344;
		NullCheck(L_3330);
		float L_3332 = ((L_3330)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3331)))->___aspectRatio;
		L_3323->___y = ((float)il2cpp_codegen_add(L_3324, ((float)(L_3329/L_3332))));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3333 = V_57;
		int32_t L_3334 = V_344;
		NullCheck(L_3333);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3335 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3333)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3334)))->___vertexTopLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3336 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3335->___uv2);
		float L_3337 = V_390;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3338 = V_57;
		int32_t L_3339 = V_344;
		NullCheck(L_3338);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3340 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3338)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3339)))->___vertexTopRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3341 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3340->___uv2);
		float L_3342 = L_3341->___x;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3343 = V_57;
		int32_t L_3344 = V_344;
		NullCheck(L_3343);
		float L_3345 = ((L_3343)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3344)))->___aspectRatio;
		L_3336->___y = ((float)il2cpp_codegen_add(L_3337, ((float)(L_3342/L_3345))));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3346 = V_57;
		int32_t L_3347 = V_344;
		NullCheck(L_3346);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3348 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3346)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3347)))->___vertexBottomRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3349 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3348->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3350 = V_57;
		int32_t L_3351 = V_344;
		NullCheck(L_3350);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3352 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3350)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3351)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3353 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3352->___uv2);
		float L_3354 = L_3353->___y;
		L_3349->___y = L_3354;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3355 = V_57;
		int32_t L_3356 = V_344;
		NullCheck(L_3355);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3357 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3355)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3356)))->___vertexTopRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3358 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3357->___uv2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3359 = V_57;
		int32_t L_3360 = V_344;
		NullCheck(L_3359);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3361 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3359)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3360)))->___vertexTopLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3362 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3361->___uv2);
		float L_3363 = L_3362->___y;
		L_3358->___y = L_3363;
		goto IL_66a2;
	}

IL_66a2:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3364 = V_57;
		int32_t L_3365 = V_344;
		NullCheck(L_3364);
		float L_3366 = ((L_3364)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3365)))->___scale;
		float L_3367 = __this->___m_CharWidthAdjDelta;
		V_47 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(L_3366, ((float)il2cpp_codegen_subtract((1.0f), L_3367)))), (1.0f)));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3368 = V_57;
		int32_t L_3369 = V_344;
		NullCheck(L_3368);
		bool L_3370 = ((L_3368)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3369)))->___isUsingAlternateTypeface;
		if (L_3370)
		{
			goto IL_66f6;
		}
	}
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3371 = V_57;
		int32_t L_3372 = V_344;
		NullCheck(L_3371);
		int32_t L_3373 = ((L_3371)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3372)))->___style;
		G_B972_0 = ((((int32_t)((int32_t)((int32_t)L_3373&1))) == ((int32_t)1))? 1 : 0);
		goto IL_66f7;
	}

IL_66f6:
	{
		G_B972_0 = 0;
	}

IL_66f7:
	{
		V_393 = (bool)G_B972_0;
		bool L_3374 = V_393;
		if (!L_3374)
		{
			goto IL_670f;
		}
	}
	{
		float L_3375 = V_47;
		V_47 = ((float)il2cpp_codegen_multiply(L_3375, (-1.0f)));
	}

IL_670f:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3376 = V_57;
		int32_t L_3377 = V_344;
		NullCheck(L_3376);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3378 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3376)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3377)))->___vertexBottomLeft);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3* L_3379 = (Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3*)(&L_3378->___uv);
		float L_3380 = V_47;
		L_3379->___w = L_3380;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3381 = V_57;
		int32_t L_3382 = V_344;
		NullCheck(L_3381);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3383 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3381)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3382)))->___vertexTopLeft);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3* L_3384 = (Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3*)(&L_3383->___uv);
		float L_3385 = V_47;
		L_3384->___w = L_3385;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3386 = V_57;
		int32_t L_3387 = V_344;
		NullCheck(L_3386);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3388 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3386)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3387)))->___vertexTopRight);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3* L_3389 = (Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3*)(&L_3388->___uv);
		float L_3390 = V_47;
		L_3389->___w = L_3390;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3391 = V_57;
		int32_t L_3392 = V_344;
		NullCheck(L_3391);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3393 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3391)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3392)))->___vertexBottomRight);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3* L_3394 = (Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3*)(&L_3393->___uv);
		float L_3395 = V_47;
		L_3394->___w = L_3395;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3396 = V_57;
		int32_t L_3397 = V_344;
		NullCheck(L_3396);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3398 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3396)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3397)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3399 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3398->___uv2);
		L_3399->___x = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3400 = V_57;
		int32_t L_3401 = V_344;
		NullCheck(L_3400);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3402 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3400)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3401)))->___vertexBottomLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3403 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3402->___uv2);
		float L_3404 = V_47;
		L_3403->___y = L_3404;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3405 = V_57;
		int32_t L_3406 = V_344;
		NullCheck(L_3405);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3407 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3405)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3406)))->___vertexTopLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3408 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3407->___uv2);
		L_3408->___x = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3409 = V_57;
		int32_t L_3410 = V_344;
		NullCheck(L_3409);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3411 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3409)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3410)))->___vertexTopLeft);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3412 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3411->___uv2);
		float L_3413 = V_47;
		L_3412->___y = L_3413;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3414 = V_57;
		int32_t L_3415 = V_344;
		NullCheck(L_3414);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3416 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3414)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3415)))->___vertexTopRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3417 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3416->___uv2);
		L_3417->___x = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3418 = V_57;
		int32_t L_3419 = V_344;
		NullCheck(L_3418);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3420 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3418)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3419)))->___vertexTopRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3421 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3420->___uv2);
		float L_3422 = V_47;
		L_3421->___y = L_3422;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3423 = V_57;
		int32_t L_3424 = V_344;
		NullCheck(L_3423);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3425 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3423)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3424)))->___vertexBottomRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3426 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3425->___uv2);
		L_3426->___x = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3427 = V_57;
		int32_t L_3428 = V_344;
		NullCheck(L_3427);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3429 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3427)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3428)))->___vertexBottomRight);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_3430 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_3429->___uv2);
		float L_3431 = V_47;
		L_3430->___y = L_3431;
		goto IL_6887;
	}

IL_6885:
	{
		goto IL_6887;
	}

IL_6887:
	{
		int32_t L_3432 = V_344;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3433 = ___0_generationSettings;
		NullCheck(L_3433);
		int32_t L_3434 = L_3433->___maxVisibleCharacters;
		if ((((int32_t)L_3432) >= ((int32_t)L_3434)))
		{
			goto IL_68bb;
		}
	}
	{
		int32_t L_3435 = V_37;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3436 = ___0_generationSettings;
		NullCheck(L_3436);
		int32_t L_3437 = L_3436->___maxVisibleWords;
		if ((((int32_t)L_3435) >= ((int32_t)L_3437)))
		{
			goto IL_68bb;
		}
	}
	{
		int32_t L_3438 = V_348;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3439 = ___0_generationSettings;
		NullCheck(L_3439);
		int32_t L_3440 = L_3439->___maxVisibleLines;
		if ((((int32_t)L_3438) >= ((int32_t)L_3440)))
		{
			goto IL_68bb;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3441 = ___0_generationSettings;
		NullCheck(L_3441);
		int32_t L_3442 = L_3441->___overflowMode;
		G_B981_0 = ((((int32_t)((((int32_t)L_3442) == ((int32_t)5))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_68bc;
	}

IL_68bb:
	{
		G_B981_0 = 0;
	}

IL_68bc:
	{
		V_394 = (bool)G_B981_0;
		bool L_3443 = V_394;
		if (!L_3443)
		{
			goto IL_69bc;
		}
	}
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3444 = V_57;
		int32_t L_3445 = V_344;
		NullCheck(L_3444);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3446 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3444)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3445)))->___vertexBottomLeft);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3447 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_3446->___position);
		V_395 = L_3447;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3448 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3449 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3450 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3449);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3451 = V_36;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3452;
		L_3452 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3450, L_3451, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3448 = L_3452;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3453 = V_57;
		int32_t L_3454 = V_344;
		NullCheck(L_3453);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3455 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3453)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3454)))->___vertexTopLeft);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3456 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_3455->___position);
		V_395 = L_3456;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3457 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3458 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3459 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3458);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3460 = V_36;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3461;
		L_3461 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3459, L_3460, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3457 = L_3461;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3462 = V_57;
		int32_t L_3463 = V_344;
		NullCheck(L_3462);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3464 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3462)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3463)))->___vertexTopRight);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3465 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_3464->___position);
		V_395 = L_3465;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3466 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3467 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3468 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3467);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3469 = V_36;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3470;
		L_3470 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3468, L_3469, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3466 = L_3470;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3471 = V_57;
		int32_t L_3472 = V_344;
		NullCheck(L_3471);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3473 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3471)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3472)))->___vertexBottomRight);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3474 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_3473->___position);
		V_395 = L_3474;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3475 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3476 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3477 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3476);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3478 = V_36;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3479;
		L_3479 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3477, L_3478, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3475 = L_3479;
		goto IL_6b89;
	}

IL_69bc:
	{
		int32_t L_3480 = V_344;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3481 = ___0_generationSettings;
		NullCheck(L_3481);
		int32_t L_3482 = L_3481->___maxVisibleCharacters;
		if ((((int32_t)L_3480) >= ((int32_t)L_3482)))
		{
			goto IL_6a03;
		}
	}
	{
		int32_t L_3483 = V_37;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3484 = ___0_generationSettings;
		NullCheck(L_3484);
		int32_t L_3485 = L_3484->___maxVisibleWords;
		if ((((int32_t)L_3483) >= ((int32_t)L_3485)))
		{
			goto IL_6a03;
		}
	}
	{
		int32_t L_3486 = V_348;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3487 = ___0_generationSettings;
		NullCheck(L_3487);
		int32_t L_3488 = L_3487->___maxVisibleLines;
		if ((((int32_t)L_3486) >= ((int32_t)L_3488)))
		{
			goto IL_6a03;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3489 = ___0_generationSettings;
		NullCheck(L_3489);
		int32_t L_3490 = L_3489->___overflowMode;
		if ((!(((uint32_t)L_3490) == ((uint32_t)5))))
		{
			goto IL_6a03;
		}
	}
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3491 = V_57;
		int32_t L_3492 = V_344;
		NullCheck(L_3491);
		int32_t L_3493 = ((L_3491)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3492)))->___pageNumber;
		int32_t L_3494 = V_18;
		G_B989_0 = ((((int32_t)L_3493) == ((int32_t)L_3494))? 1 : 0);
		goto IL_6a04;
	}

IL_6a03:
	{
		G_B989_0 = 0;
	}

IL_6a04:
	{
		V_396 = (bool)G_B989_0;
		bool L_3495 = V_396;
		if (!L_3495)
		{
			goto IL_6b04;
		}
	}
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3496 = V_57;
		int32_t L_3497 = V_344;
		NullCheck(L_3496);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3498 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3496)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3497)))->___vertexBottomLeft);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3499 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_3498->___position);
		V_395 = L_3499;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3500 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3501 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3502 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3501);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3503 = V_36;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3504;
		L_3504 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3502, L_3503, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3500 = L_3504;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3505 = V_57;
		int32_t L_3506 = V_344;
		NullCheck(L_3505);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3507 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3505)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3506)))->___vertexTopLeft);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3508 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_3507->___position);
		V_395 = L_3508;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3509 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3510 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3511 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3510);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3512 = V_36;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3513;
		L_3513 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3511, L_3512, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3509 = L_3513;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3514 = V_57;
		int32_t L_3515 = V_344;
		NullCheck(L_3514);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3516 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3514)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3515)))->___vertexTopRight);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3517 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_3516->___position);
		V_395 = L_3517;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3518 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3519 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3520 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3519);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3521 = V_36;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3522;
		L_3522 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3520, L_3521, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3518 = L_3522;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3523 = V_57;
		int32_t L_3524 = V_344;
		NullCheck(L_3523);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3525 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3523)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3524)))->___vertexBottomRight);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3526 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_3525->___position);
		V_395 = L_3526;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3527 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3528 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3529 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3528);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3530 = V_36;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3531;
		L_3531 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3529, L_3530, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3527 = L_3531;
		goto IL_6b89;
	}

IL_6b04:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3532 = V_57;
		int32_t L_3533 = V_344;
		NullCheck(L_3532);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3534 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3532)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3533)))->___vertexBottomLeft);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3535;
		L_3535 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		L_3534->___position = L_3535;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3536 = V_57;
		int32_t L_3537 = V_344;
		NullCheck(L_3536);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3538 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3536)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3537)))->___vertexTopLeft);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3539;
		L_3539 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		L_3538->___position = L_3539;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3540 = V_57;
		int32_t L_3541 = V_344;
		NullCheck(L_3540);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3542 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3540)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3541)))->___vertexTopRight);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3543;
		L_3543 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		L_3542->___position = L_3543;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3544 = V_57;
		int32_t L_3545 = V_344;
		NullCheck(L_3544);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3546 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3544)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3545)))->___vertexBottomRight);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3547;
		L_3547 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		L_3546->___position = L_3547;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3548 = V_57;
		int32_t L_3549 = V_344;
		NullCheck(L_3548);
		((L_3548)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3549)))->___isVisible = (bool)0;
	}

IL_6b89:
	{
		int32_t L_3550;
		L_3550 = QualitySettings_get_activeColorSpace_m4F47784E7B0FE0A5497C8BAB9CA86BD576FB92F9(NULL);
		if ((!(((uint32_t)L_3550) == ((uint32_t)1))))
		{
			goto IL_6b99;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3551 = ___0_generationSettings;
		NullCheck(L_3551);
		bool L_3552 = L_3551->___shouldConvertToLinearSpace;
		G_B995_0 = ((int32_t)(L_3552));
		goto IL_6b9a;
	}

IL_6b99:
	{
		G_B995_0 = 0;
	}

IL_6b9a:
	{
		V_379 = (bool)G_B995_0;
		uint8_t L_3553 = V_378;
		V_397 = (bool)((((int32_t)L_3553) == ((int32_t)1))? 1 : 0);
		bool L_3554 = V_397;
		if (!L_3554)
		{
			goto IL_6bcf;
		}
	}
	{
		int32_t L_3555 = V_344;
		bool L_3556 = V_379;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3557 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3558 = ___1_textInfo;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		TextGeneratorUtilities_FillCharacterVertexBuffers_mE0CCB8DA0D27F37DCFC4E47E89697D8823A8FCE8(L_3555, L_3556, L_3557, L_3558, NULL);
		goto IL_6bfc;
	}

IL_6bcf:
	{
		uint8_t L_3559 = V_378;
		V_398 = (bool)((((int32_t)L_3559) == ((int32_t)2))? 1 : 0);
		bool L_3560 = V_398;
		if (!L_3560)
		{
			goto IL_6bfc;
		}
	}
	{
		int32_t L_3561 = V_344;
		bool L_3562 = V_379;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3563 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3564 = ___1_textInfo;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		TextGeneratorUtilities_FillSpriteVertexBuffers_mD1AECFE4D4356A6925BF056E15CF84118313412B(L_3561, L_3562, L_3563, L_3564, NULL);
	}

IL_6bfc:
	{
	}

IL_6bfd:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3565 = ___1_textInfo;
		NullCheck(L_3565);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3566 = L_3565->___textElementInfo;
		int32_t L_3567 = V_344;
		NullCheck(L_3566);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3568 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3566)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3567)))->___bottomLeft);
		V_395 = L_3568;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3569 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3570 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3571 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3570);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3572 = V_36;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3573;
		L_3573 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3571, L_3572, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3569 = L_3573;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3574 = ___1_textInfo;
		NullCheck(L_3574);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3575 = L_3574->___textElementInfo;
		int32_t L_3576 = V_344;
		NullCheck(L_3575);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3577 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3575)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3576)))->___topLeft);
		V_395 = L_3577;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3578 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3579 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3580 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3579);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3581 = V_36;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3582;
		L_3582 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3580, L_3581, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3578 = L_3582;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3583 = ___1_textInfo;
		NullCheck(L_3583);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3584 = L_3583->___textElementInfo;
		int32_t L_3585 = V_344;
		NullCheck(L_3584);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3586 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3584)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3585)))->___topRight);
		V_395 = L_3586;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3587 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3588 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3589 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3588);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3590 = V_36;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3591;
		L_3591 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3589, L_3590, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3587 = L_3591;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3592 = ___1_textInfo;
		NullCheck(L_3592);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3593 = L_3592->___textElementInfo;
		int32_t L_3594 = V_344;
		NullCheck(L_3593);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3595 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3593)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3594)))->___bottomRight);
		V_395 = L_3595;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3596 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3597 = V_395;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3598 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3597);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3599 = V_36;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3600;
		L_3600 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3598, L_3599, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3596 = L_3600;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3601 = ___1_textInfo;
		NullCheck(L_3601);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3602 = L_3601->___textElementInfo;
		int32_t L_3603 = V_344;
		NullCheck(L_3602);
		float* L_3604 = (float*)(&((L_3602)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3603)))->___origin);
		V_308 = L_3604;
		float* L_3605 = V_308;
		float* L_3606 = V_308;
		float L_3607 = *((float*)L_3606);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3608 = V_36;
		float L_3609 = L_3608.___x;
		*((float*)L_3605) = (float)((float)il2cpp_codegen_add(L_3607, L_3609));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3610 = ___1_textInfo;
		NullCheck(L_3610);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3611 = L_3610->___textElementInfo;
		int32_t L_3612 = V_344;
		NullCheck(L_3611);
		float* L_3613 = (float*)(&((L_3611)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3612)))->___xAdvance);
		V_308 = L_3613;
		float* L_3614 = V_308;
		float* L_3615 = V_308;
		float L_3616 = *((float*)L_3615);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3617 = V_36;
		float L_3618 = L_3617.___x;
		*((float*)L_3614) = (float)((float)il2cpp_codegen_add(L_3616, L_3618));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3619 = ___1_textInfo;
		NullCheck(L_3619);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3620 = L_3619->___textElementInfo;
		int32_t L_3621 = V_344;
		NullCheck(L_3620);
		float* L_3622 = (float*)(&((L_3620)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3621)))->___ascender);
		V_308 = L_3622;
		float* L_3623 = V_308;
		float* L_3624 = V_308;
		float L_3625 = *((float*)L_3624);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3626 = V_36;
		float L_3627 = L_3626.___y;
		*((float*)L_3623) = (float)((float)il2cpp_codegen_add(L_3625, L_3627));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3628 = ___1_textInfo;
		NullCheck(L_3628);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3629 = L_3628->___textElementInfo;
		int32_t L_3630 = V_344;
		NullCheck(L_3629);
		float* L_3631 = (float*)(&((L_3629)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3630)))->___descender);
		V_308 = L_3631;
		float* L_3632 = V_308;
		float* L_3633 = V_308;
		float L_3634 = *((float*)L_3633);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3635 = V_36;
		float L_3636 = L_3635.___y;
		*((float*)L_3632) = (float)((float)il2cpp_codegen_add(L_3634, L_3636));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3637 = ___1_textInfo;
		NullCheck(L_3637);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3638 = L_3637->___textElementInfo;
		int32_t L_3639 = V_344;
		NullCheck(L_3638);
		float* L_3640 = (float*)(&((L_3638)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3639)))->___baseLine);
		V_308 = L_3640;
		float* L_3641 = V_308;
		float* L_3642 = V_308;
		float L_3643 = *((float*)L_3642);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3644 = V_36;
		float L_3645 = L_3644.___y;
		*((float*)L_3641) = (float)((float)il2cpp_codegen_add(L_3643, L_3645));
		bool L_3646 = V_351;
		V_399 = L_3646;
		bool L_3647 = V_399;
		if (!L_3647)
		{
			goto IL_6df1;
		}
	}
	{
	}

IL_6df1:
	{
		int32_t L_3648 = V_348;
		int32_t L_3649 = V_39;
		if ((!(((uint32_t)L_3648) == ((uint32_t)L_3649))))
		{
			goto IL_6e0d;
		}
	}
	{
		int32_t L_3650 = V_344;
		int32_t L_3651 = __this->___m_CharacterCount;
		G_B1005_0 = ((((int32_t)L_3650) == ((int32_t)((int32_t)il2cpp_codegen_subtract(L_3651, 1))))? 1 : 0);
		goto IL_6e0e;
	}

IL_6e0d:
	{
		G_B1005_0 = 1;
	}

IL_6e0e:
	{
		V_400 = (bool)G_B1005_0;
		bool L_3652 = V_400;
		if (!L_3652)
		{
			goto IL_7150;
		}
	}
	{
		int32_t L_3653 = V_348;
		int32_t L_3654 = V_39;
		V_401 = (bool)((((int32_t)((((int32_t)L_3653) == ((int32_t)L_3654))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_3655 = V_401;
		if (!L_3655)
		{
			goto IL_6fa2;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3656 = ___1_textInfo;
		NullCheck(L_3656);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3657 = L_3656->___lineInfo;
		int32_t L_3658 = V_39;
		NullCheck(L_3657);
		float* L_3659 = (float*)(&((L_3657)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3658)))->___baseline);
		V_308 = L_3659;
		float* L_3660 = V_308;
		float* L_3661 = V_308;
		float L_3662 = *((float*)L_3661);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3663 = V_36;
		float L_3664 = L_3663.___y;
		*((float*)L_3660) = (float)((float)il2cpp_codegen_add(L_3662, L_3664));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3665 = ___1_textInfo;
		NullCheck(L_3665);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3666 = L_3665->___lineInfo;
		int32_t L_3667 = V_39;
		NullCheck(L_3666);
		float* L_3668 = (float*)(&((L_3666)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3667)))->___ascender);
		V_308 = L_3668;
		float* L_3669 = V_308;
		float* L_3670 = V_308;
		float L_3671 = *((float*)L_3670);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3672 = V_36;
		float L_3673 = L_3672.___y;
		*((float*)L_3669) = (float)((float)il2cpp_codegen_add(L_3671, L_3673));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3674 = ___1_textInfo;
		NullCheck(L_3674);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3675 = L_3674->___lineInfo;
		int32_t L_3676 = V_39;
		NullCheck(L_3675);
		float* L_3677 = (float*)(&((L_3675)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3676)))->___descender);
		V_308 = L_3677;
		float* L_3678 = V_308;
		float* L_3679 = V_308;
		float L_3680 = *((float*)L_3679);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3681 = V_36;
		float L_3682 = L_3681.___y;
		*((float*)L_3678) = (float)((float)il2cpp_codegen_add(L_3680, L_3682));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3683 = ___1_textInfo;
		NullCheck(L_3683);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3684 = L_3683->___lineInfo;
		int32_t L_3685 = V_39;
		NullCheck(L_3684);
		float* L_3686 = (float*)(&((L_3684)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3685)))->___maxAdvance);
		V_308 = L_3686;
		float* L_3687 = V_308;
		float* L_3688 = V_308;
		float L_3689 = *((float*)L_3688);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3690 = V_36;
		float L_3691 = L_3690.___x;
		*((float*)L_3687) = (float)((float)il2cpp_codegen_add(L_3689, L_3691));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3692 = ___1_textInfo;
		NullCheck(L_3692);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3693 = L_3692->___lineInfo;
		int32_t L_3694 = V_39;
		NullCheck(L_3693);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3695 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&((L_3693)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3694)))->___lineExtents);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3696 = ___1_textInfo;
		NullCheck(L_3696);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3697 = L_3696->___textElementInfo;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3698 = ___1_textInfo;
		NullCheck(L_3698);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3699 = L_3698->___lineInfo;
		int32_t L_3700 = V_39;
		NullCheck(L_3699);
		int32_t L_3701 = ((L_3699)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3700)))->___firstCharacterIndex;
		NullCheck(L_3697);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3702 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3697)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3701)))->___bottomLeft);
		float L_3703 = L_3702->___x;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3704 = ___1_textInfo;
		NullCheck(L_3704);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3705 = L_3704->___lineInfo;
		int32_t L_3706 = V_39;
		NullCheck(L_3705);
		float L_3707 = ((L_3705)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3706)))->___descender;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3708;
		memset((&L_3708), 0, sizeof(L_3708));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_3708), L_3703, L_3707, NULL);
		L_3695->___min = L_3708;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3709 = ___1_textInfo;
		NullCheck(L_3709);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3710 = L_3709->___lineInfo;
		int32_t L_3711 = V_39;
		NullCheck(L_3710);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3712 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&((L_3710)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3711)))->___lineExtents);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3713 = ___1_textInfo;
		NullCheck(L_3713);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3714 = L_3713->___textElementInfo;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3715 = ___1_textInfo;
		NullCheck(L_3715);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3716 = L_3715->___lineInfo;
		int32_t L_3717 = V_39;
		NullCheck(L_3716);
		int32_t L_3718 = ((L_3716)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3717)))->___lastVisibleCharacterIndex;
		NullCheck(L_3714);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3719 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3714)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3718)))->___topRight);
		float L_3720 = L_3719->___x;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3721 = ___1_textInfo;
		NullCheck(L_3721);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3722 = L_3721->___lineInfo;
		int32_t L_3723 = V_39;
		NullCheck(L_3722);
		float L_3724 = ((L_3722)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3723)))->___ascender;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3725;
		memset((&L_3725), 0, sizeof(L_3725));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_3725), L_3720, L_3724, NULL);
		L_3712->___max = L_3725;
	}

IL_6fa2:
	{
		int32_t L_3726 = V_344;
		int32_t L_3727 = __this->___m_CharacterCount;
		V_402 = (bool)((((int32_t)L_3726) == ((int32_t)((int32_t)il2cpp_codegen_subtract(L_3727, 1))))? 1 : 0);
		bool L_3728 = V_402;
		if (!L_3728)
		{
			goto IL_714f;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3729 = ___1_textInfo;
		NullCheck(L_3729);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3730 = L_3729->___lineInfo;
		int32_t L_3731 = V_348;
		NullCheck(L_3730);
		float* L_3732 = (float*)(&((L_3730)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3731)))->___baseline);
		V_308 = L_3732;
		float* L_3733 = V_308;
		float* L_3734 = V_308;
		float L_3735 = *((float*)L_3734);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3736 = V_36;
		float L_3737 = L_3736.___y;
		*((float*)L_3733) = (float)((float)il2cpp_codegen_add(L_3735, L_3737));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3738 = ___1_textInfo;
		NullCheck(L_3738);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3739 = L_3738->___lineInfo;
		int32_t L_3740 = V_348;
		NullCheck(L_3739);
		float* L_3741 = (float*)(&((L_3739)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3740)))->___ascender);
		V_308 = L_3741;
		float* L_3742 = V_308;
		float* L_3743 = V_308;
		float L_3744 = *((float*)L_3743);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3745 = V_36;
		float L_3746 = L_3745.___y;
		*((float*)L_3742) = (float)((float)il2cpp_codegen_add(L_3744, L_3746));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3747 = ___1_textInfo;
		NullCheck(L_3747);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3748 = L_3747->___lineInfo;
		int32_t L_3749 = V_348;
		NullCheck(L_3748);
		float* L_3750 = (float*)(&((L_3748)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3749)))->___descender);
		V_308 = L_3750;
		float* L_3751 = V_308;
		float* L_3752 = V_308;
		float L_3753 = *((float*)L_3752);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3754 = V_36;
		float L_3755 = L_3754.___y;
		*((float*)L_3751) = (float)((float)il2cpp_codegen_add(L_3753, L_3755));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3756 = ___1_textInfo;
		NullCheck(L_3756);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3757 = L_3756->___lineInfo;
		int32_t L_3758 = V_348;
		NullCheck(L_3757);
		float* L_3759 = (float*)(&((L_3757)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3758)))->___maxAdvance);
		V_308 = L_3759;
		float* L_3760 = V_308;
		float* L_3761 = V_308;
		float L_3762 = *((float*)L_3761);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3763 = V_36;
		float L_3764 = L_3763.___x;
		*((float*)L_3760) = (float)((float)il2cpp_codegen_add(L_3762, L_3764));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3765 = ___1_textInfo;
		NullCheck(L_3765);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3766 = L_3765->___lineInfo;
		int32_t L_3767 = V_348;
		NullCheck(L_3766);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3768 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&((L_3766)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3767)))->___lineExtents);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3769 = ___1_textInfo;
		NullCheck(L_3769);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3770 = L_3769->___textElementInfo;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3771 = ___1_textInfo;
		NullCheck(L_3771);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3772 = L_3771->___lineInfo;
		int32_t L_3773 = V_348;
		NullCheck(L_3772);
		int32_t L_3774 = ((L_3772)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3773)))->___firstCharacterIndex;
		NullCheck(L_3770);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3775 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3770)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3774)))->___bottomLeft);
		float L_3776 = L_3775->___x;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3777 = ___1_textInfo;
		NullCheck(L_3777);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3778 = L_3777->___lineInfo;
		int32_t L_3779 = V_348;
		NullCheck(L_3778);
		float L_3780 = ((L_3778)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3779)))->___descender;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3781;
		memset((&L_3781), 0, sizeof(L_3781));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_3781), L_3776, L_3780, NULL);
		L_3768->___min = L_3781;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3782 = ___1_textInfo;
		NullCheck(L_3782);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3783 = L_3782->___lineInfo;
		int32_t L_3784 = V_348;
		NullCheck(L_3783);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3785 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&((L_3783)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3784)))->___lineExtents);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3786 = ___1_textInfo;
		NullCheck(L_3786);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3787 = L_3786->___textElementInfo;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3788 = ___1_textInfo;
		NullCheck(L_3788);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3789 = L_3788->___lineInfo;
		int32_t L_3790 = V_348;
		NullCheck(L_3789);
		int32_t L_3791 = ((L_3789)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3790)))->___lastVisibleCharacterIndex;
		NullCheck(L_3787);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3792 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3787)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3791)))->___topRight);
		float L_3793 = L_3792->___x;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3794 = ___1_textInfo;
		NullCheck(L_3794);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3795 = L_3794->___lineInfo;
		int32_t L_3796 = V_348;
		NullCheck(L_3795);
		float L_3797 = ((L_3795)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3796)))->___ascender;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3798;
		memset((&L_3798), 0, sizeof(L_3798));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_3798), L_3793, L_3797, NULL);
		L_3785->___max = L_3798;
	}

IL_714f:
	{
	}

IL_7150:
	{
		Il2CppChar L_3799 = V_346;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3800;
		L_3800 = Char_IsLetterOrDigit_m14049A362108679FD23E424FD9C5C42057359B72(L_3799, NULL);
		if (L_3800)
		{
			goto IL_7190;
		}
	}
	{
		Il2CppChar L_3801 = V_346;
		if ((((int32_t)L_3801) == ((int32_t)((int32_t)45))))
		{
			goto IL_7190;
		}
	}
	{
		Il2CppChar L_3802 = V_346;
		if ((((int32_t)L_3802) == ((int32_t)((int32_t)173))))
		{
			goto IL_7190;
		}
	}
	{
		Il2CppChar L_3803 = V_346;
		if ((((int32_t)L_3803) == ((int32_t)((int32_t)8208))))
		{
			goto IL_7190;
		}
	}
	{
		Il2CppChar L_3804 = V_346;
		G_B1017_0 = ((((int32_t)L_3804) == ((int32_t)((int32_t)8209)))? 1 : 0);
		goto IL_7191;
	}

IL_7190:
	{
		G_B1017_0 = 1;
	}

IL_7191:
	{
		V_403 = (bool)G_B1017_0;
		bool L_3805 = V_403;
		if (!L_3805)
		{
			goto IL_72e5;
		}
	}
	{
		bool L_3806 = V_41;
		V_404 = (bool)((((int32_t)L_3806) == ((int32_t)0))? 1 : 0);
		bool L_3807 = V_404;
		if (!L_3807)
		{
			goto IL_71c3;
		}
	}
	{
		V_41 = (bool)1;
		int32_t L_3808 = V_344;
		V_42 = L_3808;
	}

IL_71c3:
	{
		bool L_3809 = V_41;
		if (!L_3809)
		{
			goto IL_71d9;
		}
	}
	{
		int32_t L_3810 = V_344;
		int32_t L_3811 = __this->___m_CharacterCount;
		G_B1023_0 = ((((int32_t)L_3810) == ((int32_t)((int32_t)il2cpp_codegen_subtract(L_3811, 1))))? 1 : 0);
		goto IL_71da;
	}

IL_71d9:
	{
		G_B1023_0 = 0;
	}

IL_71da:
	{
		V_405 = (bool)G_B1023_0;
		bool L_3812 = V_405;
		if (!L_3812)
		{
			goto IL_72df;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3813 = ___1_textInfo;
		NullCheck(L_3813);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3814 = L_3813->___wordInfo;
		NullCheck(L_3814);
		V_406 = ((int32_t)(((RuntimeArray*)L_3814)->max_length));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3815 = ___1_textInfo;
		NullCheck(L_3815);
		int32_t L_3816 = L_3815->___wordCount;
		V_407 = L_3816;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3817 = ___1_textInfo;
		NullCheck(L_3817);
		int32_t L_3818 = L_3817->___wordCount;
		int32_t L_3819 = V_406;
		V_408 = (bool)((((int32_t)((int32_t)il2cpp_codegen_add(L_3818, 1))) > ((int32_t)L_3819))? 1 : 0);
		bool L_3820 = V_408;
		if (!L_3820)
		{
			goto IL_7238;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3821 = ___1_textInfo;
		NullCheck(L_3821);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B** L_3822 = (WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B**)(&L_3821->___wordInfo);
		int32_t L_3823 = V_406;
		il2cpp_codegen_runtime_class_init_inline(TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09_il2cpp_TypeInfo_var);
		TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D(L_3822, ((int32_t)il2cpp_codegen_add(L_3823, 1)), TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D_RuntimeMethod_var);
	}

IL_7238:
	{
		int32_t L_3824 = V_344;
		V_43 = L_3824;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3825 = ___1_textInfo;
		NullCheck(L_3825);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3826 = L_3825->___wordInfo;
		int32_t L_3827 = V_407;
		NullCheck(L_3826);
		int32_t L_3828 = V_42;
		((L_3826)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3827)))->___firstCharacterIndex = L_3828;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3829 = ___1_textInfo;
		NullCheck(L_3829);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3830 = L_3829->___wordInfo;
		int32_t L_3831 = V_407;
		NullCheck(L_3830);
		int32_t L_3832 = V_43;
		((L_3830)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3831)))->___lastCharacterIndex = L_3832;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3833 = ___1_textInfo;
		NullCheck(L_3833);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3834 = L_3833->___wordInfo;
		int32_t L_3835 = V_407;
		NullCheck(L_3834);
		int32_t L_3836 = V_43;
		int32_t L_3837 = V_42;
		((L_3834)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3835)))->___characterCount = ((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_subtract(L_3836, L_3837)), 1));
		int32_t L_3838 = V_37;
		V_37 = ((int32_t)il2cpp_codegen_add(L_3838, 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3839 = ___1_textInfo;
		V_263 = L_3839;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3840 = V_263;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3841 = V_263;
		NullCheck(L_3841);
		int32_t L_3842 = L_3841->___wordCount;
		NullCheck(L_3840);
		L_3840->___wordCount = ((int32_t)il2cpp_codegen_add(L_3842, 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3843 = ___1_textInfo;
		NullCheck(L_3843);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3844 = L_3843->___lineInfo;
		int32_t L_3845 = V_348;
		NullCheck(L_3844);
		int32_t* L_3846 = (int32_t*)(&((L_3844)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3845)))->___wordCount);
		V_262 = L_3846;
		int32_t* L_3847 = V_262;
		int32_t* L_3848 = V_262;
		int32_t L_3849 = *((int32_t*)L_3848);
		*((int32_t*)L_3847) = (int32_t)((int32_t)il2cpp_codegen_add(L_3849, 1));
	}

IL_72df:
	{
		goto IL_74e7;
	}

IL_72e5:
	{
		bool L_3850 = V_41;
		if (L_3850)
		{
			goto IL_732d;
		}
	}
	{
		int32_t L_3851 = V_344;
		if (L_3851)
		{
			goto IL_732a;
		}
	}
	{
		Il2CppChar L_3852 = V_346;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3853;
		L_3853 = Char_IsPunctuation_m619E42D942E22C9BA1DDB8E704BECA546C376473(L_3852, NULL);
		bool L_3854 = V_347;
		if (((int32_t)(((((int32_t)L_3853) == ((int32_t)0))? 1 : 0)|(int32_t)L_3854)))
		{
			goto IL_7327;
		}
	}
	{
		Il2CppChar L_3855 = V_346;
		if ((((int32_t)L_3855) == ((int32_t)((int32_t)8203))))
		{
			goto IL_7327;
		}
	}
	{
		int32_t L_3856 = V_344;
		int32_t L_3857 = __this->___m_CharacterCount;
		G_B1034_0 = ((((int32_t)L_3856) == ((int32_t)((int32_t)il2cpp_codegen_subtract(L_3857, 1))))? 1 : 0);
		goto IL_7328;
	}

IL_7327:
	{
		G_B1034_0 = 1;
	}

IL_7328:
	{
		G_B1036_0 = G_B1034_0;
		goto IL_732b;
	}

IL_732a:
	{
		G_B1036_0 = 0;
	}

IL_732b:
	{
		G_B1038_0 = G_B1036_0;
		goto IL_732e;
	}

IL_732d:
	{
		G_B1038_0 = 1;
	}

IL_732e:
	{
		V_409 = (bool)G_B1038_0;
		bool L_3858 = V_409;
		if (!L_3858)
		{
			goto IL_74e7;
		}
	}
	{
		int32_t L_3859 = V_344;
		if ((((int32_t)L_3859) <= ((int32_t)0)))
		{
			goto IL_73b2;
		}
	}
	{
		int32_t L_3860 = V_344;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3861 = V_57;
		NullCheck(L_3861);
		if ((((int32_t)L_3860) >= ((int32_t)((int32_t)il2cpp_codegen_subtract(((int32_t)(((RuntimeArray*)L_3861)->max_length)), 1)))))
		{
			goto IL_73b2;
		}
	}
	{
		int32_t L_3862 = V_344;
		int32_t L_3863 = __this->___m_CharacterCount;
		if ((((int32_t)L_3862) >= ((int32_t)L_3863)))
		{
			goto IL_73b2;
		}
	}
	{
		Il2CppChar L_3864 = V_346;
		if ((((int32_t)L_3864) == ((int32_t)((int32_t)39))))
		{
			goto IL_737c;
		}
	}
	{
		Il2CppChar L_3865 = V_346;
		if ((!(((uint32_t)L_3865) == ((uint32_t)((int32_t)8217)))))
		{
			goto IL_73b2;
		}
	}

IL_737c:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3866 = V_57;
		int32_t L_3867 = V_344;
		NullCheck(L_3866);
		Il2CppChar L_3868 = ((L_3866)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_3867, 1)))))->___character;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3869;
		L_3869 = Char_IsLetterOrDigit_m14049A362108679FD23E424FD9C5C42057359B72(L_3868, NULL);
		if (!L_3869)
		{
			goto IL_73b2;
		}
	}
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3870 = V_57;
		int32_t L_3871 = V_344;
		NullCheck(L_3870);
		Il2CppChar L_3872 = ((L_3870)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_3871, 1)))))->___character;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3873;
		L_3873 = Char_IsLetterOrDigit_m14049A362108679FD23E424FD9C5C42057359B72(L_3872, NULL);
		G_B1047_0 = ((int32_t)(L_3873));
		goto IL_73b3;
	}

IL_73b2:
	{
		G_B1047_0 = 0;
	}

IL_73b3:
	{
		V_410 = (bool)G_B1047_0;
		bool L_3874 = V_410;
		if (!L_3874)
		{
			goto IL_73c8;
		}
	}
	{
		goto IL_74e6;
	}

IL_73c8:
	{
		int32_t L_3875 = V_344;
		int32_t L_3876 = __this->___m_CharacterCount;
		if ((!(((uint32_t)L_3875) == ((uint32_t)((int32_t)il2cpp_codegen_subtract(L_3876, 1))))))
		{
			goto IL_73e6;
		}
	}
	{
		Il2CppChar L_3877 = V_346;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3878;
		L_3878 = Char_IsLetterOrDigit_m14049A362108679FD23E424FD9C5C42057359B72(L_3877, NULL);
		if (L_3878)
		{
			goto IL_73f0;
		}
	}

IL_73e6:
	{
		int32_t L_3879 = V_344;
		G_B1053_0 = ((int32_t)il2cpp_codegen_subtract(L_3879, 1));
		goto IL_73f6;
	}

IL_73f0:
	{
		int32_t L_3880 = V_344;
		G_B1053_0 = L_3880;
	}

IL_73f6:
	{
		V_43 = G_B1053_0;
		V_41 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3881 = ___1_textInfo;
		NullCheck(L_3881);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3882 = L_3881->___wordInfo;
		NullCheck(L_3882);
		V_411 = ((int32_t)(((RuntimeArray*)L_3882)->max_length));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3883 = ___1_textInfo;
		NullCheck(L_3883);
		int32_t L_3884 = L_3883->___wordCount;
		V_412 = L_3884;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3885 = ___1_textInfo;
		NullCheck(L_3885);
		int32_t L_3886 = L_3885->___wordCount;
		int32_t L_3887 = V_411;
		V_413 = (bool)((((int32_t)((int32_t)il2cpp_codegen_add(L_3886, 1))) > ((int32_t)L_3887))? 1 : 0);
		bool L_3888 = V_413;
		if (!L_3888)
		{
			goto IL_7447;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3889 = ___1_textInfo;
		NullCheck(L_3889);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B** L_3890 = (WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B**)(&L_3889->___wordInfo);
		int32_t L_3891 = V_411;
		il2cpp_codegen_runtime_class_init_inline(TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09_il2cpp_TypeInfo_var);
		TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D(L_3890, ((int32_t)il2cpp_codegen_add(L_3891, 1)), TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D_RuntimeMethod_var);
	}

IL_7447:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3892 = ___1_textInfo;
		NullCheck(L_3892);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3893 = L_3892->___wordInfo;
		int32_t L_3894 = V_412;
		NullCheck(L_3893);
		int32_t L_3895 = V_42;
		((L_3893)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3894)))->___firstCharacterIndex = L_3895;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3896 = ___1_textInfo;
		NullCheck(L_3896);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3897 = L_3896->___wordInfo;
		int32_t L_3898 = V_412;
		NullCheck(L_3897);
		int32_t L_3899 = V_43;
		((L_3897)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3898)))->___lastCharacterIndex = L_3899;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3900 = ___1_textInfo;
		NullCheck(L_3900);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3901 = L_3900->___wordInfo;
		int32_t L_3902 = V_412;
		NullCheck(L_3901);
		int32_t L_3903 = V_43;
		int32_t L_3904 = V_42;
		((L_3901)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3902)))->___characterCount = ((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_subtract(L_3903, L_3904)), 1));
		int32_t L_3905 = V_37;
		V_37 = ((int32_t)il2cpp_codegen_add(L_3905, 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3906 = ___1_textInfo;
		V_263 = L_3906;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3907 = V_263;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3908 = V_263;
		NullCheck(L_3908);
		int32_t L_3909 = L_3908->___wordCount;
		NullCheck(L_3907);
		L_3907->___wordCount = ((int32_t)il2cpp_codegen_add(L_3909, 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3910 = ___1_textInfo;
		NullCheck(L_3910);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3911 = L_3910->___lineInfo;
		int32_t L_3912 = V_348;
		NullCheck(L_3911);
		int32_t* L_3913 = (int32_t*)(&((L_3911)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3912)))->___wordCount);
		V_262 = L_3913;
		int32_t* L_3914 = V_262;
		int32_t* L_3915 = V_262;
		int32_t L_3916 = *((int32_t*)L_3915);
		*((int32_t*)L_3914) = (int32_t)((int32_t)il2cpp_codegen_add(L_3916, 1));
	}

IL_74e6:
	{
	}

IL_74e7:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3917 = ___1_textInfo;
		NullCheck(L_3917);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3918 = L_3917->___textElementInfo;
		int32_t L_3919 = V_344;
		NullCheck(L_3918);
		int32_t L_3920 = ((L_3918)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3919)))->___style;
		V_352 = (bool)((((int32_t)((int32_t)((int32_t)L_3920&4))) == ((int32_t)4))? 1 : 0);
		bool L_3921 = V_352;
		V_414 = L_3921;
		bool L_3922 = V_414;
		if (!L_3922)
		{
			goto IL_7aa4;
		}
	}
	{
		V_415 = (bool)1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3923 = ___1_textInfo;
		NullCheck(L_3923);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3924 = L_3923->___textElementInfo;
		int32_t L_3925 = V_344;
		NullCheck(L_3924);
		int32_t L_3926 = ((L_3924)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3925)))->___pageNumber;
		V_416 = L_3926;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3927 = ___1_textInfo;
		NullCheck(L_3927);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3928 = L_3927->___textElementInfo;
		int32_t L_3929 = V_344;
		NullCheck(L_3928);
		MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E* L_3930 = __this->___m_MaterialReferences;
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_3931 = (SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD*)(&__this->___m_Underline);
		int32_t L_3932 = L_3931->___materialIndex;
		NullCheck(L_3930);
		int32_t L_3933 = ((L_3930)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3932)))->___referenceCount;
		((L_3928)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3929)))->___underlineVertexIndex = ((int32_t)il2cpp_codegen_multiply(L_3933, 4));
		int32_t L_3934 = V_344;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3935 = ___0_generationSettings;
		NullCheck(L_3935);
		int32_t L_3936 = L_3935->___maxVisibleCharacters;
		if ((((int32_t)L_3934) > ((int32_t)L_3936)))
		{
			goto IL_75b3;
		}
	}
	{
		int32_t L_3937 = V_348;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3938 = ___0_generationSettings;
		NullCheck(L_3938);
		int32_t L_3939 = L_3938->___maxVisibleLines;
		if ((((int32_t)L_3937) > ((int32_t)L_3939)))
		{
			goto IL_75b3;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3940 = ___0_generationSettings;
		NullCheck(L_3940);
		int32_t L_3941 = L_3940->___overflowMode;
		if ((!(((uint32_t)L_3941) == ((uint32_t)5))))
		{
			goto IL_75b0;
		}
	}
	{
		int32_t L_3942 = V_416;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3943 = ___0_generationSettings;
		NullCheck(L_3943);
		int32_t L_3944 = L_3943->___pageToDisplay;
		G_B1063_0 = ((((int32_t)((((int32_t)((int32_t)il2cpp_codegen_add(L_3942, 1))) == ((int32_t)L_3944))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_75b1;
	}

IL_75b0:
	{
		G_B1063_0 = 0;
	}

IL_75b1:
	{
		G_B1065_0 = G_B1063_0;
		goto IL_75b4;
	}

IL_75b3:
	{
		G_B1065_0 = 1;
	}

IL_75b4:
	{
		V_417 = (bool)G_B1065_0;
		bool L_3945 = V_417;
		if (!L_3945)
		{
			goto IL_75c9;
		}
	}
	{
		V_415 = (bool)0;
	}

IL_75c9:
	{
		bool L_3946 = V_347;
		if (L_3946)
		{
			goto IL_75e3;
		}
	}
	{
		Il2CppChar L_3947 = V_346;
		G_B1070_0 = ((((int32_t)((((int32_t)L_3947) == ((int32_t)((int32_t)8203)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_75e4;
	}

IL_75e3:
	{
		G_B1070_0 = 0;
	}

IL_75e4:
	{
		V_418 = (bool)G_B1070_0;
		bool L_3948 = V_418;
		if (!L_3948)
		{
			goto IL_7676;
		}
	}
	{
		float L_3949 = V_51;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3950 = ___1_textInfo;
		NullCheck(L_3950);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3951 = L_3950->___textElementInfo;
		int32_t L_3952 = V_344;
		NullCheck(L_3951);
		float L_3953 = ((L_3951)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3952)))->___scale;
		float L_3954;
		L_3954 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_3949, L_3953, NULL);
		V_51 = L_3954;
		float L_3955 = V_48;
		float L_3956 = V_47;
		float L_3957;
		L_3957 = fabsf(L_3956);
		float L_3958;
		L_3958 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_3955, L_3957, NULL);
		V_48 = L_3958;
		int32_t L_3959 = V_416;
		int32_t L_3960 = V_53;
		if ((((int32_t)L_3959) == ((int32_t)L_3960)))
		{
			goto IL_7636;
		}
	}
	{
		G_B1074_0 = (32767.0f);
		goto IL_7638;
	}

IL_7636:
	{
		float L_3961 = V_52;
		G_B1074_0 = L_3961;
	}

IL_7638:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3962 = ___1_textInfo;
		NullCheck(L_3962);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3963 = L_3962->___textElementInfo;
		int32_t L_3964 = V_344;
		NullCheck(L_3963);
		float L_3965 = ((L_3963)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3964)))->___baseLine;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_3966 = V_345;
		NullCheck(L_3966);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_3967;
		L_3967 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_3966, NULL);
		V_61 = L_3967;
		float L_3968;
		L_3968 = FaceInfo_get_underlineOffset_mB1CBB29ECFFE69047F35E654E7F90755F95DD251((&V_61), NULL);
		float L_3969 = V_51;
		float L_3970;
		L_3970 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(G_B1074_0, ((float)il2cpp_codegen_add(L_3965, ((float)il2cpp_codegen_multiply(L_3968, L_3969)))), NULL);
		V_52 = L_3970;
		int32_t L_3971 = V_416;
		V_53 = L_3971;
	}

IL_7676:
	{
		bool L_3972 = V_7;
		if (L_3972)
		{
			goto IL_76b8;
		}
	}
	{
		bool L_3973 = V_415;
		if (!L_3973)
		{
			goto IL_76b8;
		}
	}
	{
		int32_t L_3974 = V_344;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3975 = V_349;
		int32_t L_3976 = L_3975.___lastVisibleCharacterIndex;
		if ((((int32_t)L_3974) > ((int32_t)L_3976)))
		{
			goto IL_76b8;
		}
	}
	{
		Il2CppChar L_3977 = V_346;
		if ((((int32_t)L_3977) == ((int32_t)((int32_t)10))))
		{
			goto IL_76b8;
		}
	}
	{
		Il2CppChar L_3978 = V_346;
		if ((((int32_t)L_3978) == ((int32_t)((int32_t)11))))
		{
			goto IL_76b8;
		}
	}
	{
		Il2CppChar L_3979 = V_346;
		G_B1082_0 = ((((int32_t)((((int32_t)L_3979) == ((int32_t)((int32_t)13)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_76b9;
	}

IL_76b8:
	{
		G_B1082_0 = 0;
	}

IL_76b9:
	{
		V_419 = (bool)G_B1082_0;
		bool L_3980 = V_419;
		if (!L_3980)
		{
			goto IL_777e;
		}
	}
	{
		int32_t L_3981 = V_344;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3982 = V_349;
		int32_t L_3983 = L_3982.___lastVisibleCharacterIndex;
		if ((!(((uint32_t)L_3981) == ((uint32_t)L_3983))))
		{
			goto IL_76eb;
		}
	}
	{
		Il2CppChar L_3984 = V_346;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3985;
		L_3985 = Char_IsSeparator_m8DBA05CCFA10131140E40057E6553F7AC7397BF9(L_3984, NULL);
		G_B1086_0 = ((int32_t)(L_3985));
		goto IL_76ec;
	}

IL_76eb:
	{
		G_B1086_0 = 0;
	}

IL_76ec:
	{
		V_420 = (bool)G_B1086_0;
		bool L_3986 = V_420;
		if (!L_3986)
		{
			goto IL_76fe;
		}
	}
	{
		goto IL_777d;
	}

IL_76fe:
	{
		V_7 = (bool)1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3987 = ___1_textInfo;
		NullCheck(L_3987);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3988 = L_3987->___textElementInfo;
		int32_t L_3989 = V_344;
		NullCheck(L_3988);
		float L_3990 = ((L_3988)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3989)))->___scale;
		V_49 = L_3990;
		float L_3991 = V_51;
		V_421 = (bool)((((float)L_3991) == ((float)(0.0f)))? 1 : 0);
		bool L_3992 = V_421;
		if (!L_3992)
		{
			goto IL_773b;
		}
	}
	{
		float L_3993 = V_49;
		V_51 = L_3993;
		float L_3994 = V_47;
		V_48 = L_3994;
	}

IL_773b:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3995 = ___1_textInfo;
		NullCheck(L_3995);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3996 = L_3995->___textElementInfo;
		int32_t L_3997 = V_344;
		NullCheck(L_3996);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3998 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3996)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3997)))->___bottomLeft);
		float L_3999 = L_3998->___x;
		float L_4000 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_8), L_3999, L_4000, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4001 = ___1_textInfo;
		NullCheck(L_4001);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4002 = L_4001->___textElementInfo;
		int32_t L_4003 = V_344;
		NullCheck(L_4002);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4004 = ((L_4002)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4003)))->___underlineColor;
		V_44 = L_4004;
	}

IL_777d:
	{
	}

IL_777e:
	{
		bool L_4005 = V_7;
		if (!L_4005)
		{
			goto IL_778d;
		}
	}
	{
		int32_t L_4006 = __this->___m_CharacterCount;
		G_B1095_0 = ((((int32_t)L_4006) == ((int32_t)1))? 1 : 0);
		goto IL_778e;
	}

IL_778d:
	{
		G_B1095_0 = 0;
	}

IL_778e:
	{
		V_422 = (bool)G_B1095_0;
		bool L_4007 = V_422;
		if (!L_4007)
		{
			goto IL_7813;
		}
	}
	{
		V_7 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4008 = ___1_textInfo;
		NullCheck(L_4008);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4009 = L_4008->___textElementInfo;
		int32_t L_4010 = V_344;
		NullCheck(L_4009);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_4011 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_4009)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4010)))->___topRight);
		float L_4012 = L_4011->___x;
		float L_4013 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_9), L_4012, L_4013, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4014 = ___1_textInfo;
		NullCheck(L_4014);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4015 = L_4014->___textElementInfo;
		int32_t L_4016 = V_344;
		NullCheck(L_4015);
		float L_4017 = ((L_4015)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4016)))->___scale;
		V_50 = L_4017;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4018 = V_8;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4019 = V_9;
		float L_4020 = V_49;
		float L_4021 = V_50;
		float L_4022 = V_51;
		float L_4023 = V_48;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4024 = V_44;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4025 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4026 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m307EA8034106ACD13F89CC7E78C5DE08CCCCEFAE(__this, L_4018, L_4019, L_4020, L_4021, L_4022, L_4023, L_4024, L_4025, L_4026, NULL);
		V_51 = (0.0f);
		V_48 = (0.0f);
		V_52 = (32767.0f);
		goto IL_7a9e;
	}

IL_7813:
	{
		bool L_4027 = V_7;
		if (!L_4027)
		{
			goto IL_7845;
		}
	}
	{
		int32_t L_4028 = V_344;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_4029 = V_349;
		int32_t L_4030 = L_4029.___lastCharacterIndex;
		if ((((int32_t)L_4028) == ((int32_t)L_4030)))
		{
			goto IL_7842;
		}
	}
	{
		int32_t L_4031 = V_344;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_4032 = V_349;
		int32_t L_4033 = L_4032.___lastVisibleCharacterIndex;
		G_B1101_0 = ((((int32_t)((((int32_t)L_4031) < ((int32_t)L_4033))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_7843;
	}

IL_7842:
	{
		G_B1101_0 = 1;
	}

IL_7843:
	{
		G_B1103_0 = G_B1101_0;
		goto IL_7846;
	}

IL_7845:
	{
		G_B1103_0 = 0;
	}

IL_7846:
	{
		V_423 = (bool)G_B1103_0;
		bool L_4034 = V_423;
		if (!L_4034)
		{
			goto IL_794c;
		}
	}
	{
		bool L_4035 = V_347;
		if (L_4035)
		{
			goto IL_786f;
		}
	}
	{
		Il2CppChar L_4036 = V_346;
		G_B1107_0 = ((((int32_t)L_4036) == ((int32_t)((int32_t)8203)))? 1 : 0);
		goto IL_7870;
	}

IL_786f:
	{
		G_B1107_0 = 1;
	}

IL_7870:
	{
		V_424 = (bool)G_B1107_0;
		bool L_4037 = V_424;
		if (!L_4037)
		{
			goto IL_78d4;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_4038 = V_349;
		int32_t L_4039 = L_4038.___lastVisibleCharacterIndex;
		V_425 = L_4039;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4040 = ___1_textInfo;
		NullCheck(L_4040);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4041 = L_4040->___textElementInfo;
		int32_t L_4042 = V_425;
		NullCheck(L_4041);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_4043 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_4041)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4042)))->___topRight);
		float L_4044 = L_4043->___x;
		float L_4045 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_9), L_4044, L_4045, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4046 = ___1_textInfo;
		NullCheck(L_4046);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4047 = L_4046->___textElementInfo;
		int32_t L_4048 = V_425;
		NullCheck(L_4047);
		float L_4049 = ((L_4047)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4048)))->___scale;
		V_50 = L_4049;
		goto IL_7917;
	}

IL_78d4:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4050 = ___1_textInfo;
		NullCheck(L_4050);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4051 = L_4050->___textElementInfo;
		int32_t L_4052 = V_344;
		NullCheck(L_4051);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_4053 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_4051)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4052)))->___topRight);
		float L_4054 = L_4053->___x;
		float L_4055 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_9), L_4054, L_4055, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4056 = ___1_textInfo;
		NullCheck(L_4056);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4057 = L_4056->___textElementInfo;
		int32_t L_4058 = V_344;
		NullCheck(L_4057);
		float L_4059 = ((L_4057)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4058)))->___scale;
		V_50 = L_4059;
	}

IL_7917:
	{
		V_7 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4060 = V_8;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4061 = V_9;
		float L_4062 = V_49;
		float L_4063 = V_50;
		float L_4064 = V_51;
		float L_4065 = V_48;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4066 = V_44;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4067 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4068 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m307EA8034106ACD13F89CC7E78C5DE08CCCCEFAE(__this, L_4060, L_4061, L_4062, L_4063, L_4064, L_4065, L_4066, L_4067, L_4068, NULL);
		V_51 = (0.0f);
		V_48 = (0.0f);
		V_52 = (32767.0f);
		goto IL_7a9e;
	}

IL_794c:
	{
		bool L_4069 = V_7;
		if (!L_4069)
		{
			goto IL_795b;
		}
	}
	{
		bool L_4070 = V_415;
		G_B1114_0 = ((((int32_t)L_4070) == ((int32_t)0))? 1 : 0);
		goto IL_795c;
	}

IL_795b:
	{
		G_B1114_0 = 0;
	}

IL_795c:
	{
		V_426 = (bool)G_B1114_0;
		bool L_4071 = V_426;
		if (!L_4071)
		{
			goto IL_79e5;
		}
	}
	{
		V_7 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4072 = ___1_textInfo;
		NullCheck(L_4072);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4073 = L_4072->___textElementInfo;
		int32_t L_4074 = V_344;
		NullCheck(L_4073);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_4075 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_4073)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_4074, 1)))))->___topRight);
		float L_4076 = L_4075->___x;
		float L_4077 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_9), L_4076, L_4077, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4078 = ___1_textInfo;
		NullCheck(L_4078);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4079 = L_4078->___textElementInfo;
		int32_t L_4080 = V_344;
		NullCheck(L_4079);
		float L_4081 = ((L_4079)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_4080, 1)))))->___scale;
		V_50 = L_4081;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4082 = V_8;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4083 = V_9;
		float L_4084 = V_49;
		float L_4085 = V_50;
		float L_4086 = V_51;
		float L_4087 = V_48;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4088 = V_44;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4089 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4090 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m307EA8034106ACD13F89CC7E78C5DE08CCCCEFAE(__this, L_4082, L_4083, L_4084, L_4085, L_4086, L_4087, L_4088, L_4089, L_4090, NULL);
		V_51 = (0.0f);
		V_48 = (0.0f);
		V_52 = (32767.0f);
		goto IL_7a9e;
	}

IL_79e5:
	{
		bool L_4091 = V_7;
		if (!L_4091)
		{
			goto IL_7a1d;
		}
	}
	{
		int32_t L_4092 = V_344;
		int32_t L_4093 = __this->___m_CharacterCount;
		if ((((int32_t)L_4092) >= ((int32_t)((int32_t)il2cpp_codegen_subtract(L_4093, 1)))))
		{
			goto IL_7a1d;
		}
	}
	{
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4094 = V_44;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4095 = ___1_textInfo;
		NullCheck(L_4095);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4096 = L_4095->___textElementInfo;
		int32_t L_4097 = V_344;
		NullCheck(L_4096);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4098 = ((L_4096)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_4097, 1)))))->___underlineColor;
		bool L_4099;
		L_4099 = ColorUtilities_CompareColors_m0F0F140129DEE889FB8AE3B2921C495E94B5E875(L_4094, L_4098, NULL);
		G_B1120_0 = ((((int32_t)L_4099) == ((int32_t)0))? 1 : 0);
		goto IL_7a1e;
	}

IL_7a1d:
	{
		G_B1120_0 = 0;
	}

IL_7a1e:
	{
		V_427 = (bool)G_B1120_0;
		bool L_4100 = V_427;
		if (!L_4100)
		{
			goto IL_7a9e;
		}
	}
	{
		V_7 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4101 = ___1_textInfo;
		NullCheck(L_4101);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4102 = L_4101->___textElementInfo;
		int32_t L_4103 = V_344;
		NullCheck(L_4102);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_4104 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_4102)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4103)))->___topRight);
		float L_4105 = L_4104->___x;
		float L_4106 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_9), L_4105, L_4106, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4107 = ___1_textInfo;
		NullCheck(L_4107);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4108 = L_4107->___textElementInfo;
		int32_t L_4109 = V_344;
		NullCheck(L_4108);
		float L_4110 = ((L_4108)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4109)))->___scale;
		V_50 = L_4110;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4111 = V_8;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4112 = V_9;
		float L_4113 = V_49;
		float L_4114 = V_50;
		float L_4115 = V_51;
		float L_4116 = V_48;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4117 = V_44;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4118 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4119 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m307EA8034106ACD13F89CC7E78C5DE08CCCCEFAE(__this, L_4111, L_4112, L_4113, L_4114, L_4115, L_4116, L_4117, L_4118, L_4119, NULL);
		V_51 = (0.0f);
		V_48 = (0.0f);
		V_52 = (32767.0f);
	}

IL_7a9e:
	{
		goto IL_7b2c;
	}

IL_7aa4:
	{
		bool L_4120 = V_7;
		V_428 = L_4120;
		bool L_4121 = V_428;
		if (!L_4121)
		{
			goto IL_7b2b;
		}
	}
	{
		V_7 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4122 = ___1_textInfo;
		NullCheck(L_4122);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4123 = L_4122->___textElementInfo;
		int32_t L_4124 = V_344;
		NullCheck(L_4123);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_4125 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_4123)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_4124, 1)))))->___topRight);
		float L_4126 = L_4125->___x;
		float L_4127 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_9), L_4126, L_4127, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4128 = ___1_textInfo;
		NullCheck(L_4128);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4129 = L_4128->___textElementInfo;
		int32_t L_4130 = V_344;
		NullCheck(L_4129);
		float L_4131 = ((L_4129)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_4130, 1)))))->___scale;
		V_50 = L_4131;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4132 = V_8;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4133 = V_9;
		float L_4134 = V_49;
		float L_4135 = V_50;
		float L_4136 = V_51;
		float L_4137 = V_48;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4138 = V_44;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4139 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4140 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m307EA8034106ACD13F89CC7E78C5DE08CCCCEFAE(__this, L_4132, L_4133, L_4134, L_4135, L_4136, L_4137, L_4138, L_4139, L_4140, NULL);
		V_51 = (0.0f);
		V_48 = (0.0f);
		V_52 = (32767.0f);
	}

IL_7b2b:
	{
	}

IL_7b2c:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4141 = ___1_textInfo;
		NullCheck(L_4141);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4142 = L_4141->___textElementInfo;
		int32_t L_4143 = V_344;
		NullCheck(L_4142);
		int32_t L_4144 = ((L_4142)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4143)))->___style;
		V_353 = (bool)((((int32_t)((int32_t)((int32_t)L_4144&((int32_t)64)))) == ((int32_t)((int32_t)64)))? 1 : 0);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_4145 = V_345;
		NullCheck(L_4145);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_4146;
		L_4146 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_4145, NULL);
		V_61 = L_4146;
		float L_4147;
		L_4147 = FaceInfo_get_strikethroughOffset_m7997E4A1512FE358331B3A6543C62C92A0AA5CA5((&V_61), NULL);
		V_354 = L_4147;
		bool L_4148 = V_353;
		V_429 = L_4148;
		bool L_4149 = V_429;
		if (!L_4149)
		{
			goto IL_817e;
		}
	}
	{
		V_430 = (bool)1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4150 = ___1_textInfo;
		NullCheck(L_4150);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4151 = L_4150->___textElementInfo;
		int32_t L_4152 = V_344;
		NullCheck(L_4151);
		MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E* L_4153 = __this->___m_MaterialReferences;
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_4154 = (SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD*)(&__this->___m_Underline);
		int32_t L_4155 = L_4154->___materialIndex;
		NullCheck(L_4153);
		int32_t L_4156 = ((L_4153)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4155)))->___referenceCount;
		((L_4151)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4152)))->___strikethroughVertexIndex = ((int32_t)il2cpp_codegen_multiply(L_4156, 4));
		int32_t L_4157 = V_344;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4158 = ___0_generationSettings;
		NullCheck(L_4158);
		int32_t L_4159 = L_4158->___maxVisibleCharacters;
		if ((((int32_t)L_4157) > ((int32_t)L_4159)))
		{
			goto IL_7c08;
		}
	}
	{
		int32_t L_4160 = V_348;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4161 = ___0_generationSettings;
		NullCheck(L_4161);
		int32_t L_4162 = L_4161->___maxVisibleLines;
		if ((((int32_t)L_4160) > ((int32_t)L_4162)))
		{
			goto IL_7c08;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4163 = ___0_generationSettings;
		NullCheck(L_4163);
		int32_t L_4164 = L_4163->___overflowMode;
		if ((!(((uint32_t)L_4164) == ((uint32_t)5))))
		{
			goto IL_7c05;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4165 = ___1_textInfo;
		NullCheck(L_4165);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4166 = L_4165->___textElementInfo;
		int32_t L_4167 = V_344;
		NullCheck(L_4166);
		int32_t L_4168 = ((L_4166)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4167)))->___pageNumber;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4169 = ___0_generationSettings;
		NullCheck(L_4169);
		int32_t L_4170 = L_4169->___pageToDisplay;
		G_B1132_0 = ((((int32_t)((((int32_t)((int32_t)il2cpp_codegen_add(L_4168, 1))) == ((int32_t)L_4170))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_7c06;
	}

IL_7c05:
	{
		G_B1132_0 = 0;
	}

IL_7c06:
	{
		G_B1134_0 = G_B1132_0;
		goto IL_7c09;
	}

IL_7c08:
	{
		G_B1134_0 = 1;
	}

IL_7c09:
	{
		V_431 = (bool)G_B1134_0;
		bool L_4171 = V_431;
		if (!L_4171)
		{
			goto IL_7c1e;
		}
	}
	{
		V_430 = (bool)0;
	}

IL_7c1e:
	{
		bool L_4172 = V_10;
		bool L_4173 = V_430;
		if (!((int32_t)(((((int32_t)L_4172) == ((int32_t)0))? 1 : 0)&(int32_t)L_4173)))
		{
			goto IL_7c62;
		}
	}
	{
		int32_t L_4174 = V_344;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_4175 = V_349;
		int32_t L_4176 = L_4175.___lastVisibleCharacterIndex;
		if ((((int32_t)L_4174) > ((int32_t)L_4176)))
		{
			goto IL_7c62;
		}
	}
	{
		Il2CppChar L_4177 = V_346;
		if ((((int32_t)L_4177) == ((int32_t)((int32_t)10))))
		{
			goto IL_7c62;
		}
	}
	{
		Il2CppChar L_4178 = V_346;
		if ((((int32_t)L_4178) == ((int32_t)((int32_t)11))))
		{
			goto IL_7c62;
		}
	}
	{
		Il2CppChar L_4179 = V_346;
		G_B1142_0 = ((((int32_t)((((int32_t)L_4179) == ((int32_t)((int32_t)13)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_7c63;
	}

IL_7c62:
	{
		G_B1142_0 = 0;
	}

IL_7c63:
	{
		V_432 = (bool)G_B1142_0;
		bool L_4180 = V_432;
		if (!L_4180)
		{
			goto IL_7d58;
		}
	}
	{
		int32_t L_4181 = V_344;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_4182 = V_349;
		int32_t L_4183 = L_4182.___lastVisibleCharacterIndex;
		if ((!(((uint32_t)L_4181) == ((uint32_t)L_4183))))
		{
			goto IL_7c95;
		}
	}
	{
		Il2CppChar L_4184 = V_346;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_4185;
		L_4185 = Char_IsSeparator_m8DBA05CCFA10131140E40057E6553F7AC7397BF9(L_4184, NULL);
		G_B1146_0 = ((int32_t)(L_4185));
		goto IL_7c96;
	}

IL_7c95:
	{
		G_B1146_0 = 0;
	}

IL_7c96:
	{
		V_433 = (bool)G_B1146_0;
		bool L_4186 = V_433;
		if (!L_4186)
		{
			goto IL_7cab;
		}
	}
	{
		goto IL_7d57;
	}

IL_7cab:
	{
		V_10 = (bool)1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4187 = ___1_textInfo;
		NullCheck(L_4187);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4188 = L_4187->___textElementInfo;
		int32_t L_4189 = V_344;
		NullCheck(L_4188);
		float L_4190 = ((L_4188)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4189)))->___pointSize;
		V_54 = L_4190;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4191 = ___1_textInfo;
		NullCheck(L_4191);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4192 = L_4191->___textElementInfo;
		int32_t L_4193 = V_344;
		NullCheck(L_4192);
		float L_4194 = ((L_4192)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4193)))->___scale;
		V_55 = L_4194;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4195 = ___1_textInfo;
		NullCheck(L_4195);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4196 = L_4195->___textElementInfo;
		int32_t L_4197 = V_344;
		NullCheck(L_4196);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_4198 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_4196)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4197)))->___bottomLeft);
		float L_4199 = L_4198->___x;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4200 = ___1_textInfo;
		NullCheck(L_4200);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4201 = L_4200->___textElementInfo;
		int32_t L_4202 = V_344;
		NullCheck(L_4201);
		float L_4203 = ((L_4201)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4202)))->___baseLine;
		float L_4204 = V_354;
		float L_4205 = V_55;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_11), L_4199, ((float)il2cpp_codegen_add(L_4203, ((float)il2cpp_codegen_multiply(L_4204, L_4205)))), (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4206 = ___1_textInfo;
		NullCheck(L_4206);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4207 = L_4206->___textElementInfo;
		int32_t L_4208 = V_344;
		NullCheck(L_4207);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4209 = ((L_4207)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4208)))->___strikethroughColor;
		V_45 = L_4209;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4210 = ___1_textInfo;
		NullCheck(L_4210);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4211 = L_4210->___textElementInfo;
		int32_t L_4212 = V_344;
		NullCheck(L_4211);
		float L_4213 = ((L_4211)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4212)))->___baseLine;
		V_56 = L_4213;
	}

IL_7d57:
	{
	}

IL_7d58:
	{
		bool L_4214 = V_10;
		if (!L_4214)
		{
			goto IL_7d67;
		}
	}
	{
		int32_t L_4215 = __this->___m_CharacterCount;
		G_B1153_0 = ((((int32_t)L_4215) == ((int32_t)1))? 1 : 0);
		goto IL_7d68;
	}

IL_7d67:
	{
		G_B1153_0 = 0;
	}

IL_7d68:
	{
		V_434 = (bool)G_B1153_0;
		bool L_4216 = V_434;
		if (!L_4216)
		{
			goto IL_7dde;
		}
	}
	{
		V_10 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4217 = ___1_textInfo;
		NullCheck(L_4217);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4218 = L_4217->___textElementInfo;
		int32_t L_4219 = V_344;
		NullCheck(L_4218);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_4220 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_4218)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4219)))->___topRight);
		float L_4221 = L_4220->___x;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4222 = ___1_textInfo;
		NullCheck(L_4222);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4223 = L_4222->___textElementInfo;
		int32_t L_4224 = V_344;
		NullCheck(L_4223);
		float L_4225 = ((L_4223)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4224)))->___baseLine;
		float L_4226 = V_354;
		float L_4227 = V_55;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_12), L_4221, ((float)il2cpp_codegen_add(L_4225, ((float)il2cpp_codegen_multiply(L_4226, L_4227)))), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4228 = V_11;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4229 = V_12;
		float L_4230 = V_55;
		float L_4231 = V_55;
		float L_4232 = V_55;
		float L_4233 = V_47;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4234 = V_45;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4235 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4236 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m307EA8034106ACD13F89CC7E78C5DE08CCCCEFAE(__this, L_4228, L_4229, L_4230, L_4231, L_4232, L_4233, L_4234, L_4235, L_4236, NULL);
		goto IL_817b;
	}

IL_7dde:
	{
		bool L_4237 = V_10;
		if (!L_4237)
		{
			goto IL_7df7;
		}
	}
	{
		int32_t L_4238 = V_344;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_4239 = V_349;
		int32_t L_4240 = L_4239.___lastCharacterIndex;
		G_B1158_0 = ((((int32_t)L_4238) == ((int32_t)L_4240))? 1 : 0);
		goto IL_7df8;
	}

IL_7df7:
	{
		G_B1158_0 = 0;
	}

IL_7df8:
	{
		V_435 = (bool)G_B1158_0;
		bool L_4241 = V_435;
		if (!L_4241)
		{
			goto IL_7ef5;
		}
	}
	{
		bool L_4242 = V_347;
		if (L_4242)
		{
			goto IL_7e21;
		}
	}
	{
		Il2CppChar L_4243 = V_346;
		G_B1162_0 = ((((int32_t)L_4243) == ((int32_t)((int32_t)8203)))? 1 : 0);
		goto IL_7e22;
	}

IL_7e21:
	{
		G_B1162_0 = 1;
	}

IL_7e22:
	{
		V_436 = (bool)G_B1162_0;
		bool L_4244 = V_436;
		if (!L_4244)
		{
			goto IL_7e8c;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_4245 = V_349;
		int32_t L_4246 = L_4245.___lastVisibleCharacterIndex;
		V_437 = L_4246;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4247 = ___1_textInfo;
		NullCheck(L_4247);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4248 = L_4247->___textElementInfo;
		int32_t L_4249 = V_437;
		NullCheck(L_4248);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_4250 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_4248)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4249)))->___topRight);
		float L_4251 = L_4250->___x;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4252 = ___1_textInfo;
		NullCheck(L_4252);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4253 = L_4252->___textElementInfo;
		int32_t L_4254 = V_437;
		NullCheck(L_4253);
		float L_4255 = ((L_4253)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4254)))->___baseLine;
		float L_4256 = V_354;
		float L_4257 = V_55;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_12), L_4251, ((float)il2cpp_codegen_add(L_4255, ((float)il2cpp_codegen_multiply(L_4256, L_4257)))), (0.0f), NULL);
		goto IL_7ed5;
	}

IL_7e8c:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4258 = ___1_textInfo;
		NullCheck(L_4258);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4259 = L_4258->___textElementInfo;
		int32_t L_4260 = V_344;
		NullCheck(L_4259);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_4261 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_4259)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4260)))->___topRight);
		float L_4262 = L_4261->___x;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4263 = ___1_textInfo;
		NullCheck(L_4263);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4264 = L_4263->___textElementInfo;
		int32_t L_4265 = V_344;
		NullCheck(L_4264);
		float L_4266 = ((L_4264)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4265)))->___baseLine;
		float L_4267 = V_354;
		float L_4268 = V_55;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_12), L_4262, ((float)il2cpp_codegen_add(L_4266, ((float)il2cpp_codegen_multiply(L_4267, L_4268)))), (0.0f), NULL);
	}

IL_7ed5:
	{
		V_10 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4269 = V_11;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4270 = V_12;
		float L_4271 = V_55;
		float L_4272 = V_55;
		float L_4273 = V_55;
		float L_4274 = V_47;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4275 = V_45;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4276 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4277 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m307EA8034106ACD13F89CC7E78C5DE08CCCCEFAE(__this, L_4269, L_4270, L_4271, L_4272, L_4273, L_4274, L_4275, L_4276, L_4277, NULL);
		goto IL_817b;
	}

IL_7ef5:
	{
		bool L_4278 = V_10;
		if (!L_4278)
		{
			goto IL_7f52;
		}
	}
	{
		int32_t L_4279 = V_344;
		int32_t L_4280 = __this->___m_CharacterCount;
		if ((((int32_t)L_4279) >= ((int32_t)L_4280)))
		{
			goto IL_7f52;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4281 = ___1_textInfo;
		NullCheck(L_4281);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4282 = L_4281->___textElementInfo;
		int32_t L_4283 = V_344;
		NullCheck(L_4282);
		float L_4284 = ((L_4282)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_4283, 1)))))->___pointSize;
		float L_4285 = V_54;
		if ((!(((float)L_4284) == ((float)L_4285))))
		{
			goto IL_7f4f;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4286 = ___1_textInfo;
		NullCheck(L_4286);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4287 = L_4286->___textElementInfo;
		int32_t L_4288 = V_344;
		NullCheck(L_4287);
		float L_4289 = ((L_4287)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_4288, 1)))))->___baseLine;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4290 = V_36;
		float L_4291 = L_4290.___y;
		float L_4292 = V_56;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		bool L_4293;
		L_4293 = TextGeneratorUtilities_Approximately_m696ABB909732F536F1FF83EA8CE34CF53266794D(((float)il2cpp_codegen_add(L_4289, L_4291)), L_4292, NULL);
		G_B1171_0 = ((((int32_t)L_4293) == ((int32_t)0))? 1 : 0);
		goto IL_7f50;
	}

IL_7f4f:
	{
		G_B1171_0 = 1;
	}

IL_7f50:
	{
		G_B1173_0 = G_B1171_0;
		goto IL_7f53;
	}

IL_7f52:
	{
		G_B1173_0 = 0;
	}

IL_7f53:
	{
		V_438 = (bool)G_B1173_0;
		bool L_4294 = V_438;
		if (!L_4294)
		{
			goto IL_8042;
		}
	}
	{
		V_10 = (bool)0;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_4295 = V_349;
		int32_t L_4296 = L_4295.___lastVisibleCharacterIndex;
		V_439 = L_4296;
		int32_t L_4297 = V_344;
		int32_t L_4298 = V_439;
		V_440 = (bool)((((int32_t)L_4297) > ((int32_t)L_4298))? 1 : 0);
		bool L_4299 = V_440;
		if (!L_4299)
		{
			goto IL_7fde;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4300 = ___1_textInfo;
		NullCheck(L_4300);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4301 = L_4300->___textElementInfo;
		int32_t L_4302 = V_439;
		NullCheck(L_4301);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_4303 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_4301)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4302)))->___topRight);
		float L_4304 = L_4303->___x;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4305 = ___1_textInfo;
		NullCheck(L_4305);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4306 = L_4305->___textElementInfo;
		int32_t L_4307 = V_439;
		NullCheck(L_4306);
		float L_4308 = ((L_4306)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4307)))->___baseLine;
		float L_4309 = V_354;
		float L_4310 = V_55;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_12), L_4304, ((float)il2cpp_codegen_add(L_4308, ((float)il2cpp_codegen_multiply(L_4309, L_4310)))), (0.0f), NULL);
		goto IL_8025;
	}

IL_7fde:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4311 = ___1_textInfo;
		NullCheck(L_4311);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4312 = L_4311->___textElementInfo;
		int32_t L_4313 = V_344;
		NullCheck(L_4312);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_4314 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_4312)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4313)))->___topRight);
		float L_4315 = L_4314->___x;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4316 = ___1_textInfo;
		NullCheck(L_4316);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4317 = L_4316->___textElementInfo;
		int32_t L_4318 = V_344;
		NullCheck(L_4317);
		float L_4319 = ((L_4317)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4318)))->___baseLine;
		float L_4320 = V_354;
		float L_4321 = V_55;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_12), L_4315, ((float)il2cpp_codegen_add(L_4319, ((float)il2cpp_codegen_multiply(L_4320, L_4321)))), (0.0f), NULL);
	}

IL_8025:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4322 = V_11;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4323 = V_12;
		float L_4324 = V_55;
		float L_4325 = V_55;
		float L_4326 = V_55;
		float L_4327 = V_47;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4328 = V_45;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4329 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4330 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m307EA8034106ACD13F89CC7E78C5DE08CCCCEFAE(__this, L_4322, L_4323, L_4324, L_4325, L_4326, L_4327, L_4328, L_4329, L_4330, NULL);
		goto IL_817b;
	}

IL_8042:
	{
		bool L_4331 = V_10;
		if (!L_4331)
		{
			goto IL_807f;
		}
	}
	{
		int32_t L_4332 = V_344;
		int32_t L_4333 = __this->___m_CharacterCount;
		if ((((int32_t)L_4332) >= ((int32_t)L_4333)))
		{
			goto IL_807f;
		}
	}
	{
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_4334 = V_345;
		NullCheck(L_4334);
		int32_t L_4335;
		L_4335 = Object_GetInstanceID_m554FF4073C9465F3835574CC084E68AAEEC6CC6A(L_4334, NULL);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4336 = V_57;
		int32_t L_4337 = V_344;
		NullCheck(L_4336);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_4338 = ((L_4336)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_4337, 1)))))->___fontAsset;
		NullCheck(L_4338);
		int32_t L_4339;
		L_4339 = Object_GetInstanceID_m554FF4073C9465F3835574CC084E68AAEEC6CC6A(L_4338, NULL);
		G_B1182_0 = ((((int32_t)((((int32_t)L_4335) == ((int32_t)L_4339))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_8080;
	}

IL_807f:
	{
		G_B1182_0 = 0;
	}

IL_8080:
	{
		V_441 = (bool)G_B1182_0;
		bool L_4340 = V_441;
		if (!L_4340)
		{
			goto IL_80f6;
		}
	}
	{
		V_10 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4341 = ___1_textInfo;
		NullCheck(L_4341);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4342 = L_4341->___textElementInfo;
		int32_t L_4343 = V_344;
		NullCheck(L_4342);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_4344 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_4342)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4343)))->___topRight);
		float L_4345 = L_4344->___x;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4346 = ___1_textInfo;
		NullCheck(L_4346);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4347 = L_4346->___textElementInfo;
		int32_t L_4348 = V_344;
		NullCheck(L_4347);
		float L_4349 = ((L_4347)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4348)))->___baseLine;
		float L_4350 = V_354;
		float L_4351 = V_55;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_12), L_4345, ((float)il2cpp_codegen_add(L_4349, ((float)il2cpp_codegen_multiply(L_4350, L_4351)))), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4352 = V_11;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4353 = V_12;
		float L_4354 = V_55;
		float L_4355 = V_55;
		float L_4356 = V_55;
		float L_4357 = V_47;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4358 = V_45;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4359 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4360 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m307EA8034106ACD13F89CC7E78C5DE08CCCCEFAE(__this, L_4352, L_4353, L_4354, L_4355, L_4356, L_4357, L_4358, L_4359, L_4360, NULL);
		goto IL_817b;
	}

IL_80f6:
	{
		bool L_4361 = V_10;
		if (!L_4361)
		{
			goto IL_8105;
		}
	}
	{
		bool L_4362 = V_430;
		G_B1187_0 = ((((int32_t)L_4362) == ((int32_t)0))? 1 : 0);
		goto IL_8106;
	}

IL_8105:
	{
		G_B1187_0 = 0;
	}

IL_8106:
	{
		V_442 = (bool)G_B1187_0;
		bool L_4363 = V_442;
		if (!L_4363)
		{
			goto IL_817b;
		}
	}
	{
		V_10 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4364 = ___1_textInfo;
		NullCheck(L_4364);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4365 = L_4364->___textElementInfo;
		int32_t L_4366 = V_344;
		NullCheck(L_4365);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_4367 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_4365)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_4366, 1)))))->___topRight);
		float L_4368 = L_4367->___x;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4369 = ___1_textInfo;
		NullCheck(L_4369);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4370 = L_4369->___textElementInfo;
		int32_t L_4371 = V_344;
		NullCheck(L_4370);
		float L_4372 = ((L_4370)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_4371, 1)))))->___baseLine;
		float L_4373 = V_354;
		float L_4374 = V_55;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_12), L_4368, ((float)il2cpp_codegen_add(L_4372, ((float)il2cpp_codegen_multiply(L_4373, L_4374)))), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4375 = V_11;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4376 = V_12;
		float L_4377 = V_55;
		float L_4378 = V_55;
		float L_4379 = V_55;
		float L_4380 = V_47;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4381 = V_45;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4382 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4383 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m307EA8034106ACD13F89CC7E78C5DE08CCCCEFAE(__this, L_4375, L_4376, L_4377, L_4378, L_4379, L_4380, L_4381, L_4382, L_4383, NULL);
	}

IL_817b:
	{
		goto IL_81f7;
	}

IL_817e:
	{
		bool L_4384 = V_10;
		V_443 = L_4384;
		bool L_4385 = V_443;
		if (!L_4385)
		{
			goto IL_81f6;
		}
	}
	{
		V_10 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4386 = ___1_textInfo;
		NullCheck(L_4386);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4387 = L_4386->___textElementInfo;
		int32_t L_4388 = V_344;
		NullCheck(L_4387);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_4389 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_4387)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_4388, 1)))))->___topRight);
		float L_4390 = L_4389->___x;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4391 = ___1_textInfo;
		NullCheck(L_4391);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4392 = L_4391->___textElementInfo;
		int32_t L_4393 = V_344;
		NullCheck(L_4392);
		float L_4394 = ((L_4392)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_4393, 1)))))->___baseLine;
		float L_4395 = V_354;
		float L_4396 = V_55;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_12), L_4390, ((float)il2cpp_codegen_add(L_4394, ((float)il2cpp_codegen_multiply(L_4395, L_4396)))), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4397 = V_11;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4398 = V_12;
		float L_4399 = V_55;
		float L_4400 = V_55;
		float L_4401 = V_55;
		float L_4402 = V_47;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4403 = V_45;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4404 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4405 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m307EA8034106ACD13F89CC7E78C5DE08CCCCEFAE(__this, L_4397, L_4398, L_4399, L_4400, L_4401, L_4402, L_4403, L_4404, L_4405, NULL);
	}

IL_81f6:
	{
	}

IL_81f7:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4406 = ___1_textInfo;
		NullCheck(L_4406);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4407 = L_4406->___textElementInfo;
		int32_t L_4408 = V_344;
		NullCheck(L_4407);
		int32_t L_4409 = ((L_4407)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4408)))->___style;
		V_355 = (bool)((((int32_t)((int32_t)((int32_t)L_4409&((int32_t)512)))) == ((int32_t)((int32_t)512)))? 1 : 0);
		bool L_4410 = V_355;
		V_444 = L_4410;
		bool L_4411 = V_444;
		if (!L_4411)
		{
			goto IL_878a;
		}
	}
	{
		V_445 = (bool)1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4412 = ___1_textInfo;
		NullCheck(L_4412);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4413 = L_4412->___textElementInfo;
		int32_t L_4414 = V_344;
		NullCheck(L_4413);
		int32_t L_4415 = ((L_4413)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4414)))->___pageNumber;
		V_446 = L_4415;
		int32_t L_4416 = V_344;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4417 = ___0_generationSettings;
		NullCheck(L_4417);
		int32_t L_4418 = L_4417->___maxVisibleCharacters;
		if ((((int32_t)L_4416) > ((int32_t)L_4418)))
		{
			goto IL_8298;
		}
	}
	{
		int32_t L_4419 = V_348;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4420 = ___0_generationSettings;
		NullCheck(L_4420);
		int32_t L_4421 = L_4420->___maxVisibleLines;
		if ((((int32_t)L_4419) > ((int32_t)L_4421)))
		{
			goto IL_8298;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4422 = ___0_generationSettings;
		NullCheck(L_4422);
		int32_t L_4423 = L_4422->___overflowMode;
		if ((!(((uint32_t)L_4423) == ((uint32_t)5))))
		{
			goto IL_8295;
		}
	}
	{
		int32_t L_4424 = V_446;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4425 = ___0_generationSettings;
		NullCheck(L_4425);
		int32_t L_4426 = L_4425->___pageToDisplay;
		G_B1199_0 = ((((int32_t)((((int32_t)((int32_t)il2cpp_codegen_add(L_4424, 1))) == ((int32_t)L_4426))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_8296;
	}

IL_8295:
	{
		G_B1199_0 = 0;
	}

IL_8296:
	{
		G_B1201_0 = G_B1199_0;
		goto IL_8299;
	}

IL_8298:
	{
		G_B1201_0 = 1;
	}

IL_8299:
	{
		V_447 = (bool)G_B1201_0;
		bool L_4427 = V_447;
		if (!L_4427)
		{
			goto IL_82ae;
		}
	}
	{
		V_445 = (bool)0;
	}

IL_82ae:
	{
		bool L_4428 = V_13;
		if (L_4428)
		{
			goto IL_82f0;
		}
	}
	{
		bool L_4429 = V_445;
		if (!L_4429)
		{
			goto IL_82f0;
		}
	}
	{
		int32_t L_4430 = V_344;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_4431 = V_349;
		int32_t L_4432 = L_4431.___lastVisibleCharacterIndex;
		if ((((int32_t)L_4430) > ((int32_t)L_4432)))
		{
			goto IL_82f0;
		}
	}
	{
		Il2CppChar L_4433 = V_346;
		if ((((int32_t)L_4433) == ((int32_t)((int32_t)10))))
		{
			goto IL_82f0;
		}
	}
	{
		Il2CppChar L_4434 = V_346;
		if ((((int32_t)L_4434) == ((int32_t)((int32_t)11))))
		{
			goto IL_82f0;
		}
	}
	{
		Il2CppChar L_4435 = V_346;
		G_B1210_0 = ((((int32_t)((((int32_t)L_4435) == ((int32_t)((int32_t)13)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_82f1;
	}

IL_82f0:
	{
		G_B1210_0 = 0;
	}

IL_82f1:
	{
		V_448 = (bool)G_B1210_0;
		bool L_4436 = V_448;
		if (!L_4436)
		{
			goto IL_8369;
		}
	}
	{
		int32_t L_4437 = V_344;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_4438 = V_349;
		int32_t L_4439 = L_4438.___lastVisibleCharacterIndex;
		if ((!(((uint32_t)L_4437) == ((uint32_t)L_4439))))
		{
			goto IL_8320;
		}
	}
	{
		Il2CppChar L_4440 = V_346;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_4441;
		L_4441 = Char_IsSeparator_m8DBA05CCFA10131140E40057E6553F7AC7397BF9(L_4440, NULL);
		G_B1214_0 = ((int32_t)(L_4441));
		goto IL_8321;
	}

IL_8320:
	{
		G_B1214_0 = 0;
	}

IL_8321:
	{
		V_449 = (bool)G_B1214_0;
		bool L_4442 = V_449;
		if (!L_4442)
		{
			goto IL_8333;
		}
	}
	{
		goto IL_8368;
	}

IL_8333:
	{
		V_13 = (bool)1;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_4443 = ((TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_StaticFields*)il2cpp_codegen_static_fields_for(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var))->___largePositiveVector2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4444;
		L_4444 = Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline(L_4443, NULL);
		V_14 = L_4444;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_4445 = ((TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_StaticFields*)il2cpp_codegen_static_fields_for(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var))->___largeNegativeVector2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4446;
		L_4446 = Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline(L_4445, NULL);
		V_15 = L_4446;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4447 = ___1_textInfo;
		NullCheck(L_4447);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4448 = L_4447->___textElementInfo;
		int32_t L_4449 = V_344;
		NullCheck(L_4448);
		HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 L_4450 = ((L_4448)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4449)))->___highlightState;
		V_46 = L_4450;
	}

IL_8368:
	{
	}

IL_8369:
	{
		bool L_4451 = V_13;
		V_450 = L_4451;
		bool L_4452 = V_450;
		if (!L_4452)
		{
			goto IL_86b8;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4453 = ___1_textInfo;
		NullCheck(L_4453);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_4454 = L_4453->___textElementInfo;
		int32_t L_4455 = V_344;
		NullCheck(L_4454);
		int32_t L_4456 = L_4455;
		TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 L_4457 = (L_4454)->GetAt(static_cast<il2cpp_array_size_t>(L_4456));
		V_451 = L_4457;
		TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 L_4458 = V_451;
		HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 L_4459 = L_4458.___highlightState;
		V_452 = L_4459;
		V_453 = (bool)0;
		HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 L_4460 = V_46;
		HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 L_4461 = V_452;
		bool L_4462;
		L_4462 = HighlightState_op_Inequality_m2DFBCB59E593F72191BFBBD7424A8C6151E68272(L_4460, L_4461, NULL);
		V_454 = L_4462;
		bool L_4463 = V_454;
		if (!L_4463)
		{
			goto IL_8575;
		}
	}
	{
		bool L_4464 = V_347;
		V_455 = L_4464;
		bool L_4465 = V_455;
		if (!L_4465)
		{
			goto IL_840e;
		}
	}
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4466 = V_15;
		float L_4467 = L_4466.___x;
		Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4* L_4468 = (Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4*)(&(&V_46)->___padding);
		il2cpp_codegen_runtime_class_init_inline(Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4_il2cpp_TypeInfo_var);
		float L_4469;
		L_4469 = Offset_get_right_m45AEBB7DE1D42A9A7234FB0DCE4E92420060D3FB(L_4468, NULL);
		TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 L_4470 = V_451;
		float L_4471 = L_4470.___origin;
		(&V_15)->___x = ((float)(((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(L_4467, L_4469)), L_4471))/(2.0f)));
		goto IL_8440;
	}

IL_840e:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4472 = V_15;
		float L_4473 = L_4472.___x;
		Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4* L_4474 = (Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4*)(&(&V_46)->___padding);
		il2cpp_codegen_runtime_class_init_inline(Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4_il2cpp_TypeInfo_var);
		float L_4475;
		L_4475 = Offset_get_right_m45AEBB7DE1D42A9A7234FB0DCE4E92420060D3FB(L_4474, NULL);
		TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 L_4476 = V_451;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4477 = L_4476.___bottomLeft;
		float L_4478 = L_4477.___x;
		(&V_15)->___x = ((float)(((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(L_4473, L_4475)), L_4478))/(2.0f)));
	}

IL_8440:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4479 = V_14;
		float L_4480 = L_4479.___y;
		TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 L_4481 = V_451;
		float L_4482 = L_4481.___descender;
		float L_4483;
		L_4483 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_4480, L_4482, NULL);
		(&V_14)->___y = L_4483;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4484 = V_15;
		float L_4485 = L_4484.___y;
		TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 L_4486 = V_451;
		float L_4487 = L_4486.___ascender;
		float L_4488;
		L_4488 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_4485, L_4487, NULL);
		(&V_15)->___y = L_4488;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4489 = V_14;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4490 = V_15;
		HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 L_4491 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4492 = L_4491.___color;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4493 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4494 = ___1_textInfo;
		TextGenerator_DrawTextHighlight_m4046F4CC59C6DD8FE5B0BD97DB8BFE015B829389(__this, L_4489, L_4490, L_4492, L_4493, L_4494, NULL);
		V_13 = (bool)1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4495 = V_15;
		float L_4496 = L_4495.___x;
		TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 L_4497 = V_451;
		float L_4498 = L_4497.___descender;
		Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4* L_4499 = (Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4*)(&(&V_452)->___padding);
		il2cpp_codegen_runtime_class_init_inline(Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4_il2cpp_TypeInfo_var);
		float L_4500;
		L_4500 = Offset_get_bottom_m3BC4AB202A1B7D7D5A65EF746CDA1A73B5D8866C(L_4499, NULL);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_4501;
		memset((&L_4501), 0, sizeof(L_4501));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_4501), L_4496, ((float)il2cpp_codegen_subtract(L_4498, L_4500)), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4502;
		L_4502 = Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline(L_4501, NULL);
		V_14 = L_4502;
		bool L_4503 = V_347;
		V_456 = L_4503;
		bool L_4504 = V_456;
		if (!L_4504)
		{
			goto IL_851c;
		}
	}
	{
		TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 L_4505 = V_451;
		float L_4506 = L_4505.___xAdvance;
		Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4* L_4507 = (Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4*)(&(&V_452)->___padding);
		il2cpp_codegen_runtime_class_init_inline(Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4_il2cpp_TypeInfo_var);
		float L_4508;
		L_4508 = Offset_get_right_m45AEBB7DE1D42A9A7234FB0DCE4E92420060D3FB(L_4507, NULL);
		TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 L_4509 = V_451;
		float L_4510 = L_4509.___ascender;
		Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4* L_4511 = (Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4*)(&(&V_452)->___padding);
		float L_4512;
		L_4512 = Offset_get_top_mD62FECE7914DF9723A872AAD91BDB07295C6E0F4(L_4511, NULL);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_4513;
		memset((&L_4513), 0, sizeof(L_4513));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_4513), ((float)il2cpp_codegen_add(L_4506, L_4508)), ((float)il2cpp_codegen_add(L_4510, L_4512)), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4514;
		L_4514 = Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline(L_4513, NULL);
		V_15 = L_4514;
		goto IL_8565;
	}

IL_851c:
	{
		TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 L_4515 = V_451;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4516 = L_4515.___topRight;
		float L_4517 = L_4516.___x;
		Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4* L_4518 = (Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4*)(&(&V_452)->___padding);
		il2cpp_codegen_runtime_class_init_inline(Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4_il2cpp_TypeInfo_var);
		float L_4519;
		L_4519 = Offset_get_right_m45AEBB7DE1D42A9A7234FB0DCE4E92420060D3FB(L_4518, NULL);
		TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 L_4520 = V_451;
		float L_4521 = L_4520.___ascender;
		Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4* L_4522 = (Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4*)(&(&V_452)->___padding);
		float L_4523;
		L_4523 = Offset_get_top_mD62FECE7914DF9723A872AAD91BDB07295C6E0F4(L_4522, NULL);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_4524;
		memset((&L_4524), 0, sizeof(L_4524));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_4524), ((float)il2cpp_codegen_add(L_4517, L_4519)), ((float)il2cpp_codegen_add(L_4521, L_4523)), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4525;
		L_4525 = Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline(L_4524, NULL);
		V_15 = L_4525;
	}

IL_8565:
	{
		HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 L_4526 = V_452;
		V_46 = L_4526;
		V_453 = (bool)1;
	}

IL_8575:
	{
		bool L_4527 = V_453;
		V_457 = (bool)((((int32_t)L_4527) == ((int32_t)0))? 1 : 0);
		bool L_4528 = V_457;
		if (!L_4528)
		{
			goto IL_86b7;
		}
	}
	{
		bool L_4529 = V_347;
		V_458 = L_4529;
		bool L_4530 = V_458;
		if (!L_4530)
		{
			goto IL_85fe;
		}
	}
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4531 = V_14;
		float L_4532 = L_4531.___x;
		TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 L_4533 = V_451;
		float L_4534 = L_4533.___origin;
		Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4* L_4535 = (Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4*)(&(&V_46)->___padding);
		il2cpp_codegen_runtime_class_init_inline(Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4_il2cpp_TypeInfo_var);
		float L_4536;
		L_4536 = Offset_get_left_m83657AF289FA1DB8B5D4007B8310573B76AA6D82(L_4535, NULL);
		float L_4537;
		L_4537 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_4532, ((float)il2cpp_codegen_subtract(L_4534, L_4536)), NULL);
		(&V_14)->___x = L_4537;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4538 = V_15;
		float L_4539 = L_4538.___x;
		TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 L_4540 = V_451;
		float L_4541 = L_4540.___xAdvance;
		Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4* L_4542 = (Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4*)(&(&V_46)->___padding);
		float L_4543;
		L_4543 = Offset_get_right_m45AEBB7DE1D42A9A7234FB0DCE4E92420060D3FB(L_4542, NULL);
		float L_4544;
		L_4544 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_4539, ((float)il2cpp_codegen_add(L_4541, L_4543)), NULL);
		(&V_15)->___x = L_4544;
		goto IL_8660;
	}

IL_85fe:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4545 = V_14;
		float L_4546 = L_4545.___x;
		TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 L_4547 = V_451;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4548 = L_4547.___bottomLeft;
		float L_4549 = L_4548.___x;
		Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4* L_4550 = (Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4*)(&(&V_46)->___padding);
		il2cpp_codegen_runtime_class_init_inline(Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4_il2cpp_TypeInfo_var);
		float L_4551;
		L_4551 = Offset_get_left_m83657AF289FA1DB8B5D4007B8310573B76AA6D82(L_4550, NULL);
		float L_4552;
		L_4552 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_4546, ((float)il2cpp_codegen_subtract(L_4549, L_4551)), NULL);
		(&V_14)->___x = L_4552;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4553 = V_15;
		float L_4554 = L_4553.___x;
		TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 L_4555 = V_451;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4556 = L_4555.___topRight;
		float L_4557 = L_4556.___x;
		Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4* L_4558 = (Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4*)(&(&V_46)->___padding);
		float L_4559;
		L_4559 = Offset_get_right_m45AEBB7DE1D42A9A7234FB0DCE4E92420060D3FB(L_4558, NULL);
		float L_4560;
		L_4560 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_4554, ((float)il2cpp_codegen_add(L_4557, L_4559)), NULL);
		(&V_15)->___x = L_4560;
	}

IL_8660:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4561 = V_14;
		float L_4562 = L_4561.___y;
		TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 L_4563 = V_451;
		float L_4564 = L_4563.___descender;
		Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4* L_4565 = (Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4*)(&(&V_46)->___padding);
		il2cpp_codegen_runtime_class_init_inline(Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4_il2cpp_TypeInfo_var);
		float L_4566;
		L_4566 = Offset_get_bottom_m3BC4AB202A1B7D7D5A65EF746CDA1A73B5D8866C(L_4565, NULL);
		float L_4567;
		L_4567 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_4562, ((float)il2cpp_codegen_subtract(L_4564, L_4566)), NULL);
		(&V_14)->___y = L_4567;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4568 = V_15;
		float L_4569 = L_4568.___y;
		TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 L_4570 = V_451;
		float L_4571 = L_4570.___ascender;
		Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4* L_4572 = (Offset_tF4AF8F62C21FD6DCB5255F705A59CC10583E22C4*)(&(&V_46)->___padding);
		float L_4573;
		L_4573 = Offset_get_top_mD62FECE7914DF9723A872AAD91BDB07295C6E0F4(L_4572, NULL);
		float L_4574;
		L_4574 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_4569, ((float)il2cpp_codegen_add(L_4571, L_4573)), NULL);
		(&V_15)->___y = L_4574;
	}

IL_86b7:
	{
	}

IL_86b8:
	{
		bool L_4575 = V_13;
		if (!L_4575)
		{
			goto IL_86c7;
		}
	}
	{
		int32_t L_4576 = __this->___m_CharacterCount;
		G_B1236_0 = ((((int32_t)L_4576) == ((int32_t)1))? 1 : 0);
		goto IL_86c8;
	}

IL_86c7:
	{
		G_B1236_0 = 0;
	}

IL_86c8:
	{
		V_459 = (bool)G_B1236_0;
		bool L_4577 = V_459;
		if (!L_4577)
		{
			goto IL_86f4;
		}
	}
	{
		V_13 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4578 = V_14;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4579 = V_15;
		HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 L_4580 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4581 = L_4580.___color;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4582 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4583 = ___1_textInfo;
		TextGenerator_DrawTextHighlight_m4046F4CC59C6DD8FE5B0BD97DB8BFE015B829389(__this, L_4578, L_4579, L_4581, L_4582, L_4583, NULL);
		goto IL_8787;
	}

IL_86f4:
	{
		bool L_4584 = V_13;
		if (!L_4584)
		{
			goto IL_8726;
		}
	}
	{
		int32_t L_4585 = V_344;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_4586 = V_349;
		int32_t L_4587 = L_4586.___lastCharacterIndex;
		if ((((int32_t)L_4585) == ((int32_t)L_4587)))
		{
			goto IL_8723;
		}
	}
	{
		int32_t L_4588 = V_344;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_4589 = V_349;
		int32_t L_4590 = L_4589.___lastVisibleCharacterIndex;
		G_B1242_0 = ((((int32_t)((((int32_t)L_4588) < ((int32_t)L_4590))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_8724;
	}

IL_8723:
	{
		G_B1242_0 = 1;
	}

IL_8724:
	{
		G_B1244_0 = G_B1242_0;
		goto IL_8727;
	}

IL_8726:
	{
		G_B1244_0 = 0;
	}

IL_8727:
	{
		V_460 = (bool)G_B1244_0;
		bool L_4591 = V_460;
		if (!L_4591)
		{
			goto IL_8750;
		}
	}
	{
		V_13 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4592 = V_14;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4593 = V_15;
		HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 L_4594 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4595 = L_4594.___color;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4596 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4597 = ___1_textInfo;
		TextGenerator_DrawTextHighlight_m4046F4CC59C6DD8FE5B0BD97DB8BFE015B829389(__this, L_4592, L_4593, L_4595, L_4596, L_4597, NULL);
		goto IL_8787;
	}

IL_8750:
	{
		bool L_4598 = V_13;
		if (!L_4598)
		{
			goto IL_875f;
		}
	}
	{
		bool L_4599 = V_445;
		G_B1249_0 = ((((int32_t)L_4599) == ((int32_t)0))? 1 : 0);
		goto IL_8760;
	}

IL_875f:
	{
		G_B1249_0 = 0;
	}

IL_8760:
	{
		V_461 = (bool)G_B1249_0;
		bool L_4600 = V_461;
		if (!L_4600)
		{
			goto IL_8787;
		}
	}
	{
		V_13 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4601 = V_14;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4602 = V_15;
		HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 L_4603 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4604 = L_4603.___color;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4605 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4606 = ___1_textInfo;
		TextGenerator_DrawTextHighlight_m4046F4CC59C6DD8FE5B0BD97DB8BFE015B829389(__this, L_4601, L_4602, L_4604, L_4605, L_4606, NULL);
	}

IL_8787:
	{
		goto IL_87b5;
	}

IL_878a:
	{
		bool L_4607 = V_13;
		V_462 = L_4607;
		bool L_4608 = V_462;
		if (!L_4608)
		{
			goto IL_87b4;
		}
	}
	{
		V_13 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4609 = V_14;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4610 = V_15;
		HighlightState_tFF5FE9065990F04A37FEC545A0024047F0ABD740 L_4611 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4612 = L_4611.___color;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4613 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4614 = ___1_textInfo;
		TextGenerator_DrawTextHighlight_m4046F4CC59C6DD8FE5B0BD97DB8BFE015B829389(__this, L_4609, L_4610, L_4612, L_4613, L_4614, NULL);
	}

IL_87b4:
	{
	}

IL_87b5:
	{
		int32_t L_4615 = V_348;
		V_39 = L_4615;
		int32_t L_4616 = V_344;
		V_158 = L_4616;
		int32_t L_4617 = V_158;
		V_344 = ((int32_t)il2cpp_codegen_add(L_4617, 1));
	}

IL_87d0:
	{
		int32_t L_4618 = V_344;
		int32_t L_4619 = __this->___m_CharacterCount;
		V_463 = (bool)((((int32_t)L_4618) < ((int32_t)L_4619))? 1 : 0);
		bool L_4620 = V_463;
		if (L_4620)
		{
			goto IL_4ce4;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4621 = ___1_textInfo;
		int32_t L_4622 = __this->___m_CharacterCount;
		NullCheck(L_4621);
		L_4621->___characterCount = L_4622;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4623 = ___1_textInfo;
		int32_t L_4624 = __this->___m_SpriteCount;
		NullCheck(L_4623);
		L_4623->___spriteCount = L_4624;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4625 = ___1_textInfo;
		int32_t L_4626 = V_38;
		NullCheck(L_4625);
		L_4625->___lineCount = L_4626;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4627 = ___1_textInfo;
		int32_t L_4628 = V_37;
		if (!L_4628)
		{
			G_B1259_0 = L_4627;
			goto IL_881d;
		}
		G_B1258_0 = L_4627;
	}
	{
		int32_t L_4629 = __this->___m_CharacterCount;
		if ((((int32_t)L_4629) > ((int32_t)0)))
		{
			G_B1260_0 = G_B1258_0;
			goto IL_8820;
		}
		G_B1259_0 = G_B1258_0;
	}

IL_881d:
	{
		G_B1261_0 = 1;
		G_B1261_1 = G_B1259_0;
		goto IL_8822;
	}

IL_8820:
	{
		int32_t L_4630 = V_37;
		G_B1261_0 = L_4630;
		G_B1261_1 = G_B1260_0;
	}

IL_8822:
	{
		NullCheck(G_B1261_1);
		G_B1261_1->___wordCount = G_B1261_0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4631 = ___1_textInfo;
		int32_t L_4632 = __this->___m_PageNumber;
		NullCheck(L_4631);
		L_4631->___pageCount = ((int32_t)il2cpp_codegen_add(L_4632, 1));
		V_464 = 1;
		goto IL_8898;
	}

IL_883e:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4633 = ___1_textInfo;
		NullCheck(L_4633);
		MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6* L_4634 = L_4633->___meshInfo;
		int32_t L_4635 = V_464;
		NullCheck(L_4634);
		il2cpp_codegen_runtime_class_init_inline(MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F_il2cpp_TypeInfo_var);
		MeshInfo_ClearUnusedVertices_m7B6003EF4CA72C0ABBA4D25DEA8B0BF3934B2830(((L_4634)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4635))), NULL);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4636 = ___0_generationSettings;
		NullCheck(L_4636);
		int32_t L_4637 = L_4636->___geometrySortingOrder;
		V_465 = (bool)((!(((uint32_t)L_4637) <= ((uint32_t)0)))? 1 : 0);
		bool L_4638 = V_465;
		if (!L_4638)
		{
			goto IL_8885;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4639 = ___1_textInfo;
		NullCheck(L_4639);
		MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6* L_4640 = L_4639->___meshInfo;
		int32_t L_4641 = V_464;
		NullCheck(L_4640);
		il2cpp_codegen_runtime_class_init_inline(MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F_il2cpp_TypeInfo_var);
		MeshInfo_SortGeometry_m92046C53AA6AE75EE3627CE73846296AB3E99DD1(((L_4640)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4641))), 1, NULL);
	}

IL_8885:
	{
		int32_t L_4642 = V_464;
		V_158 = L_4642;
		int32_t L_4643 = V_158;
		V_464 = ((int32_t)il2cpp_codegen_add(L_4643, 1));
	}

IL_8898:
	{
		int32_t L_4644 = V_464;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4645 = ___1_textInfo;
		NullCheck(L_4645);
		int32_t L_4646 = L_4645->___materialCount;
		V_466 = (bool)((((int32_t)L_4644) < ((int32_t)L_4646))? 1 : 0);
		bool L_4647 = V_466;
		if (L_4647)
		{
			goto IL_883e;
		}
	}

IL_88b4:
	{
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline (const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ((Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_StaticFields*)il2cpp_codegen_static_fields_for(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_il2cpp_TypeInfo_var))->___zeroVector;
		V_0 = L_0;
		goto IL_0009;
	}

IL_0009:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1 = V_0;
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B Color32_op_Implicit_m79AF5E0BDE9CE041CAC4D89CBFA66E71C6DD1B70_inline (Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___0_c, const RuntimeMethod* method) 
{
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_0 = ___0_c;
		float L_1 = L_0.___r;
		float L_2;
		L_2 = Mathf_Clamp01_mA7E048DBDA832D399A581BE4D6DED9FA44CE0F14_inline(L_1, NULL);
		float L_3;
		L_3 = bankers_roundf(((float)il2cpp_codegen_multiply(L_2, (255.0f))));
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_4 = ___0_c;
		float L_5 = L_4.___g;
		float L_6;
		L_6 = Mathf_Clamp01_mA7E048DBDA832D399A581BE4D6DED9FA44CE0F14_inline(L_5, NULL);
		float L_7;
		L_7 = bankers_roundf(((float)il2cpp_codegen_multiply(L_6, (255.0f))));
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_8 = ___0_c;
		float L_9 = L_8.___b;
		float L_10;
		L_10 = Mathf_Clamp01_mA7E048DBDA832D399A581BE4D6DED9FA44CE0F14_inline(L_9, NULL);
		float L_11;
		L_11 = bankers_roundf(((float)il2cpp_codegen_multiply(L_10, (255.0f))));
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_12 = ___0_c;
		float L_13 = L_12.___a;
		float L_14;
		L_14 = Mathf_Clamp01_mA7E048DBDA832D399A581BE4D6DED9FA44CE0F14_inline(L_13, NULL);
		float L_15;
		L_15 = bankers_roundf(((float)il2cpp_codegen_multiply(L_14, (255.0f))));
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_16;
		memset((&L_16), 0, sizeof(L_16));
		Color32__ctor_mC9C6B443F0C7CA3F8B174158B2AF6F05E18EAC4E_inline((&L_16), (uint8_t)il2cpp_codegen_cast_floating_point<uint8_t, int32_t, float>(L_3), (uint8_t)il2cpp_codegen_cast_floating_point<uint8_t, int32_t, float>(L_7), (uint8_t)il2cpp_codegen_cast_floating_point<uint8_t, int32_t, float>(L_11), (uint8_t)il2cpp_codegen_cast_floating_point<uint8_t, int32_t, float>(L_15), NULL);
		V_0 = L_16;
		goto IL_0065;
	}

IL_0065:
	{
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_17 = V_0;
		return L_17;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_get_one_mC9B289F1E15C42C597180C9FE6FB492495B51D02_inline (const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ((Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_StaticFields*)il2cpp_codegen_static_fields_for(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_il2cpp_TypeInfo_var))->___oneVector;
		V_0 = L_0;
		goto IL_0009;
	}

IL_0009:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1 = V_0;
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 Quaternion_get_identity_m7E701AE095ED10FD5EA0B50ABCFDE2EEFF2173A5_inline (const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_0 = ((Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974_StaticFields*)il2cpp_codegen_static_fields_for(Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974_il2cpp_TypeInfo_var))->___identityQuaternion;
		V_0 = L_0;
		goto IL_0009;
	}

IL_0009:
	{
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_1 = V_0;
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Mathf_Clamp_m4DC36EEFDBE5F07C16249DA568023C5ECCFF0E7B_inline (int32_t ___0_value, int32_t ___1_min, int32_t ___2_max, const RuntimeMethod* method) 
{
	bool V_0 = false;
	bool V_1 = false;
	int32_t V_2 = 0;
	{
		int32_t L_0 = ___0_value;
		int32_t L_1 = ___1_min;
		V_0 = (bool)((((int32_t)L_0) < ((int32_t)L_1))? 1 : 0);
		bool L_2 = V_0;
		if (!L_2)
		{
			goto IL_000e;
		}
	}
	{
		int32_t L_3 = ___1_min;
		___0_value = L_3;
		goto IL_0019;
	}

IL_000e:
	{
		int32_t L_4 = ___0_value;
		int32_t L_5 = ___2_max;
		V_1 = (bool)((((int32_t)L_4) > ((int32_t)L_5))? 1 : 0);
		bool L_6 = V_1;
		if (!L_6)
		{
			goto IL_0019;
		}
	}
	{
		int32_t L_7 = ___2_max;
		___0_value = L_7;
	}

IL_0019:
	{
		int32_t L_8 = ___0_value;
		V_2 = L_8;
		goto IL_001d;
	}

IL_001d:
	{
		int32_t L_9 = V_2;
		return L_9;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Color_tD001788D726C3A7F1379BEED0260B9591F440C1F Color_get_white_m068F5AF879B0FCA584E3693F762EA41BB65532C6_inline (const RuntimeMethod* method) 
{
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_0;
		memset((&L_0), 0, sizeof(L_0));
		Color__ctor_m3786F0D6E510D9CFA544523A955870BD2A514C8C_inline((&L_0), (1.0f), (1.0f), (1.0f), (1.0f), NULL);
		V_0 = L_0;
		goto IL_001d;
	}

IL_001d:
	{
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_1 = V_0;
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* __this, float ___0_x, float ___1_y, float ___2_z, const RuntimeMethod* method) 
{
	{
		float L_0 = ___0_x;
		__this->___x = L_0;
		float L_1 = ___1_y;
		__this->___y = L_1;
		float L_2 = ___2_z;
		__this->___z = L_2;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_b, const RuntimeMethod* method) 
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ___0_a;
		float L_1 = L_0.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2 = ___1_b;
		float L_3 = L_2.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4 = ___0_a;
		float L_5 = L_4.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_6 = ___1_b;
		float L_7 = L_6.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_8 = ___0_a;
		float L_9 = L_8.___z;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_10 = ___1_b;
		float L_11 = L_10.___z;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_12;
		memset((&L_12), 0, sizeof(L_12));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_12), ((float)il2cpp_codegen_add(L_1, L_3)), ((float)il2cpp_codegen_add(L_5, L_7)), ((float)il2cpp_codegen_add(L_9, L_11)), NULL);
		V_0 = L_12;
		goto IL_0030;
	}

IL_0030:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_13 = V_0;
		return L_13;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Quaternion_op_Inequality_m4EC1EF263D0E42432A301F85CB52028D2973F5DA_inline (Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___0_lhs, Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___1_rhs, const RuntimeMethod* method) 
{
	bool V_0 = false;
	{
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_0 = ___0_lhs;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_1 = ___1_rhs;
		bool L_2;
		L_2 = Quaternion_op_Equality_mE6F6B56FCED8478552BE02BBAF18C70B969217F9_inline(L_0, L_1, NULL);
		V_0 = (bool)((((int32_t)L_2) == ((int32_t)0))? 1 : 0);
		goto IL_000e;
	}

IL_000e:
	{
		bool L_3 = V_0;
		return L_3;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, float ___1_d, const RuntimeMethod* method) 
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ___0_a;
		float L_1 = L_0.___x;
		float L_2 = ___1_d;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3 = ___0_a;
		float L_4 = L_3.___y;
		float L_5 = ___1_d;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_6 = ___0_a;
		float L_7 = L_6.___z;
		float L_8 = ___1_d;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_9;
		memset((&L_9), 0, sizeof(L_9));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_9), ((float)(L_1/L_2)), ((float)(L_4/L_5)), ((float)(L_7/L_8)), NULL);
		V_0 = L_9;
		goto IL_0021;
	}

IL_0021:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_10 = V_0;
		return L_10;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_b, const RuntimeMethod* method) 
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ___0_a;
		float L_1 = L_0.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2 = ___1_b;
		float L_3 = L_2.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4 = ___0_a;
		float L_5 = L_4.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_6 = ___1_b;
		float L_7 = L_6.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_8 = ___0_a;
		float L_9 = L_8.___z;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_10 = ___1_b;
		float L_11 = L_10.___z;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_12;
		memset((&L_12), 0, sizeof(L_12));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_12), ((float)il2cpp_codegen_subtract(L_1, L_3)), ((float)il2cpp_codegen_subtract(L_5, L_7)), ((float)il2cpp_codegen_subtract(L_9, L_11)), NULL);
		V_0 = L_12;
		goto IL_0030;
	}

IL_0030:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_13 = V_0;
		return L_13;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline (float ___0_a, float ___1_b, const RuntimeMethod* method) 
{
	float V_0 = 0.0f;
	float G_B3_0 = 0.0f;
	{
		float L_0 = ___0_a;
		float L_1 = ___1_b;
		if ((((float)L_0) > ((float)L_1)))
		{
			goto IL_0008;
		}
	}
	{
		float L_2 = ___1_b;
		G_B3_0 = L_2;
		goto IL_0009;
	}

IL_0008:
	{
		float L_3 = ___0_a;
		G_B3_0 = L_3;
	}

IL_0009:
	{
		V_0 = G_B3_0;
		goto IL_000c;
	}

IL_000c:
	{
		float L_4 = V_0;
		return L_4;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline (float ___0_a, float ___1_b, const RuntimeMethod* method) 
{
	float V_0 = 0.0f;
	float G_B3_0 = 0.0f;
	{
		float L_0 = ___0_a;
		float L_1 = ___1_b;
		if ((((float)L_0) < ((float)L_1)))
		{
			goto IL_0008;
		}
	}
	{
		float L_2 = ___1_b;
		G_B3_0 = L_2;
		goto IL_0009;
	}

IL_0008:
	{
		float L_3 = ___0_a;
		G_B3_0 = L_3;
	}

IL_0009:
	{
		V_0 = G_B3_0;
		goto IL_000c;
	}

IL_000c:
	{
		float L_4 = V_0;
		return L_4;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* __this, float ___0_x, float ___1_y, const RuntimeMethod* method) 
{
	{
		float L_0 = ___0_x;
		__this->___x = L_0;
		float L_1 = ___1_y;
		__this->___y = L_1;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool UnicodeLineBreakingRules_get_useModernHangulLineBreakingRules_mD86D283CE7BA23A0174B9227A7BD915D3D9FD464_inline (UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* __this, const RuntimeMethod* method) 
{
	{
		bool L_0 = __this->___m_UseModernHangulLineBreakingRules;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Color32__ctor_mC9C6B443F0C7CA3F8B174158B2AF6F05E18EAC4E_inline (Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B* __this, uint8_t ___0_r, uint8_t ___1_g, uint8_t ___2_b, uint8_t ___3_a, const RuntimeMethod* method) 
{
	{
		__this->___rgba = 0;
		uint8_t L_0 = ___0_r;
		__this->___r = L_0;
		uint8_t L_1 = ___1_g;
		__this->___g = L_1;
		uint8_t L_2 = ___2_b;
		__this->___b = L_2;
		uint8_t L_3 = ___3_a;
		__this->___a = L_3;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___0_v, const RuntimeMethod* method) 
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_0 = ___0_v;
		float L_1 = L_0.___x;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2 = ___0_v;
		float L_3 = L_2.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4;
		memset((&L_4), 0, sizeof(L_4));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_4), L_1, L_3, (0.0f), NULL);
		V_0 = L_4;
		goto IL_001a;
	}

IL_001a:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_5 = V_0;
		return L_5;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Mathf_Clamp01_mA7E048DBDA832D399A581BE4D6DED9FA44CE0F14_inline (float ___0_value, const RuntimeMethod* method) 
{
	bool V_0 = false;
	float V_1 = 0.0f;
	bool V_2 = false;
	{
		float L_0 = ___0_value;
		V_0 = (bool)((((float)L_0) < ((float)(0.0f)))? 1 : 0);
		bool L_1 = V_0;
		if (!L_1)
		{
			goto IL_0015;
		}
	}
	{
		V_1 = (0.0f);
		goto IL_002d;
	}

IL_0015:
	{
		float L_2 = ___0_value;
		V_2 = (bool)((((float)L_2) > ((float)(1.0f)))? 1 : 0);
		bool L_3 = V_2;
		if (!L_3)
		{
			goto IL_0029;
		}
	}
	{
		V_1 = (1.0f);
		goto IL_002d;
	}

IL_0029:
	{
		float L_4 = ___0_value;
		V_1 = L_4;
		goto IL_002d;
	}

IL_002d:
	{
		float L_5 = V_1;
		return L_5;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Color__ctor_m3786F0D6E510D9CFA544523A955870BD2A514C8C_inline (Color_tD001788D726C3A7F1379BEED0260B9591F440C1F* __this, float ___0_r, float ___1_g, float ___2_b, float ___3_a, const RuntimeMethod* method) 
{
	{
		float L_0 = ___0_r;
		__this->___r = L_0;
		float L_1 = ___1_g;
		__this->___g = L_1;
		float L_2 = ___2_b;
		__this->___b = L_2;
		float L_3 = ___3_a;
		__this->___a = L_3;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Quaternion_op_Equality_mE6F6B56FCED8478552BE02BBAF18C70B969217F9_inline (Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___0_lhs, Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___1_rhs, const RuntimeMethod* method) 
{
	bool V_0 = false;
	{
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_0 = ___0_lhs;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_1 = ___1_rhs;
		float L_2;
		L_2 = Quaternion_Dot_mF9D3BE33940A47979DADA7E81650AEB356D5D12B_inline(L_0, L_1, NULL);
		bool L_3;
		L_3 = Quaternion_IsEqualUsingDot_m9C672201C918C2D1E739F559DBE4406F95997CBD_inline(L_2, NULL);
		V_0 = L_3;
		goto IL_0010;
	}

IL_0010:
	{
		bool L_4 = V_0;
		return L_4;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Quaternion_Dot_mF9D3BE33940A47979DADA7E81650AEB356D5D12B_inline (Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___0_a, Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___1_b, const RuntimeMethod* method) 
{
	float V_0 = 0.0f;
	{
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_0 = ___0_a;
		float L_1 = L_0.___x;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_2 = ___1_b;
		float L_3 = L_2.___x;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_4 = ___0_a;
		float L_5 = L_4.___y;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_6 = ___1_b;
		float L_7 = L_6.___y;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_8 = ___0_a;
		float L_9 = L_8.___z;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_10 = ___1_b;
		float L_11 = L_10.___z;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_12 = ___0_a;
		float L_13 = L_12.___w;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_14 = ___1_b;
		float L_15 = L_14.___w;
		V_0 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_1, L_3)), ((float)il2cpp_codegen_multiply(L_5, L_7)))), ((float)il2cpp_codegen_multiply(L_9, L_11)))), ((float)il2cpp_codegen_multiply(L_13, L_15))));
		goto IL_003b;
	}

IL_003b:
	{
		float L_16 = V_0;
		return L_16;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Quaternion_IsEqualUsingDot_m9C672201C918C2D1E739F559DBE4406F95997CBD_inline (float ___0_dot, const RuntimeMethod* method) 
{
	bool V_0 = false;
	{
		float L_0 = ___0_dot;
		V_0 = (bool)((((float)L_0) > ((float)(0.999998987f)))? 1 : 0);
		goto IL_000c;
	}

IL_000c:
	{
		bool L_1 = V_0;
		return L_1;
	}
}
